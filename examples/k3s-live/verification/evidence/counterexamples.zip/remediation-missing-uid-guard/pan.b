	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM remediation_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Remediation */

	case 5: // STATE 1
		;
		now.remediation_enabled = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 2
		;
		now.remediation_enabled = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 6
		;
		now.evidence_valid = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 7
		;
		now.evidence_valid = trpt->bup.oval;
		;
		goto R999;

	case 9: // STATE 11
		;
		now.proposal_allowed = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 12
		;
		now.proposal_allowed = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 16
		;
		now.namespace_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 12: // STATE 17
		;
		now.namespace_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 13: // STATE 21
		;
		now.observed_target_present = trpt->bup.oval;
		;
		goto R999;

	case 14: // STATE 22
		;
		now.observed_target_present = trpt->bup.oval;
		;
		goto R999;

	case 15: // STATE 26
		;
		now.observed_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 27
		;
		now.observed_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 31
		;
		now.template_matches = trpt->bup.oval;
		;
		goto R999;

	case 18: // STATE 32
		;
		now.template_matches = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 36
		;
		now.probe_matches = trpt->bup.oval;
		;
		goto R999;

	case 20: // STATE 37
		;
		now.probe_matches = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 22: // STATE 42
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 24: // STATE 44
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 26: // STATE 46
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 29: // STATE 49
		;
		now.patch_target_present = trpt->bup.oval;
		;
		goto R999;

	case 30: // STATE 50
		;
		now.patch_target_present = trpt->bup.oval;
		;
		goto R999;

	case 31: // STATE 54
		;
		now.patch_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 32: // STATE 55
		;
		now.patch_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 33: // STATE 59
		;
		now.resource_version_matches = trpt->bup.oval;
		;
		goto R999;

	case 34: // STATE 60
		;
		now.resource_version_matches = trpt->bup.oval;
		;
		goto R999;

	case 35: // STATE 64
		;
		now.api_accepts = trpt->bup.oval;
		;
		goto R999;

	case 36: // STATE 65
		;
		now.api_accepts = trpt->bup.oval;
		;
		goto R999;

	case 37: // STATE 75
		;
		now.patch_applied = trpt->bup.ovals[1];
		now.effects = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 38: // STATE 79
		goto R999;

	case 39: // STATE 77
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 41: // STATE 82
		;
		now.patch_acknowledged = trpt->bup.oval;
		;
		goto R999;

	case 42: // STATE 83
		;
		now.patch_acknowledged = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 44: // STATE 88
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 46: // STATE 90
		;
		now.recovery_identity_matches = trpt->bup.oval;
		;
		goto R999;

	case 47: // STATE 91
		;
		now.recovery_identity_matches = trpt->bup.oval;
		;
		goto R999;

	case 48: // STATE 95
		;
		now.generation_observed = trpt->bup.oval;
		;
		goto R999;

	case 49: // STATE 96
		;
		now.generation_observed = trpt->bup.oval;
		;
		goto R999;

	case 50: // STATE 100
		;
		now.rollout_ready = trpt->bup.oval;
		;
		goto R999;

	case 51: // STATE 101
		;
		now.rollout_ready = trpt->bup.oval;
		;
		goto R999;

	case 52: // STATE 105
		;
		now.replacement_pod_ready = trpt->bup.oval;
		;
		goto R999;

	case 53: // STATE 106
		;
		now.replacement_pod_ready = trpt->bup.oval;
		;
		goto R999;

	case 54: // STATE 110
		;
		now.endpoint_200_body = trpt->bup.oval;
		;
		goto R999;

	case 55: // STATE 111
		;
		now.endpoint_200_body = trpt->bup.oval;
		;
		goto R999;

	case 56: // STATE 115
		;
		now.fresh_metrics = trpt->bup.oval;
		;
		goto R999;

	case 57: // STATE 116
		;
		now.fresh_metrics = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 59: // STATE 121
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 61: // STATE 123
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		
	case 66: // STATE 135
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		
	case 71: // STATE 144
		;
		now.report_authenticated = trpt->bup.oval;
		;
		goto R999;

	case 72: // STATE 145
		;
		now.report_authenticated = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 74: // STATE 150
		;
		now.report_published = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 77: // STATE 156
		;
		now.done = trpt->bup.oval;
		;
		goto R999;

	case 78: // STATE 157
		;
		p_restor(II);
		;
		;
		goto R999;
	}

