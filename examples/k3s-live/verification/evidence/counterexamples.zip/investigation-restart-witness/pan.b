	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM investigation_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Investigation */

	case 5: // STATE 1
		;
		((P1 *)_this)->i = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 4
		;
		((P1 *)_this)->i = trpt->bup.ovals[1];
		now.tool[ Index(((P1 *)_this)->i, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 8: // STATE 15
		;
		now.done = trpt->bup.ovals[1];
		now.phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 9: // STATE 18
		;
		now.restarts = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 20
		;
		now.recorded_restart = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 26
		;
		now.frozen_restart = trpt->bup.oval;
		;
		goto R999;

	case 12: // STATE 33
		;
		now.has_unknown = trpt->bup.ovals[1];
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 13: // STATE 37
		goto R999;
;
		
	case 14: // STATE 35
		goto R999;

	case 15: // STATE 41
		;
		now.tool[ Index(now.slot, 4) ] = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 47
		;
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[1];
		now.calls[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 18: // STATE 51
		;
		now.results = trpt->bup.ovals[1];
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 19: // STATE 52
		goto R999;
;
		
	case 20: // STATE 55
		goto R999;

	case 21: // STATE 53
		;
		now.all_trusted = trpt->bup.oval;
		;
		goto R999;
;
		
	case 22: // STATE 59
		goto R999;

	case 23: // STATE 57
		;
		now.has_unknown = trpt->bup.ovals[1];
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 25: // STATE 62
		;
		now.phase = trpt->bup.oval;
		;
		goto R999;
;
		
	case 26: // STATE 66
		goto R999;

	case 27: // STATE 64
		;
		now.slot = trpt->bup.oval;
		;
		goto R999;

	case 28: // STATE 70
		;
		now.done = trpt->bup.ovals[1];
		now.phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 29: // STATE 72
		goto R999;

	case 30: // STATE 79
		;
		now.phase = trpt->bup.ovals[1];
		now.frozen_version = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 31: // STATE 84
		goto R999;

	case 32: // STATE 82
		;
		now.done = trpt->bup.ovals[1];
		now.phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 33: // STATE 91
		;
		now.phase = trpt->bup.ovals[1];
		now.assessment_starts = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 34: // STATE 95
		;
		now.done = trpt->bup.ovals[1];
		now.phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		;
		;
		
	case 38: // STATE 103
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Cancellation */

	case 39: // STATE 1
		;
		now.cancelled = trpt->bup.oval;
		;
		goto R999;

	case 40: // STATE 5
		;
		p_restor(II);
		;
		;
		goto R999;
	}

