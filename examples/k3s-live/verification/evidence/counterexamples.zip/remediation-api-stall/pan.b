	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM remediation_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Remediation */

	case 5: // STATE 1
		;
		now.remediation_enabled = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 2
		;
		now.remediation_enabled = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 6
		;
		now.evidence_valid = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 7
		;
		now.evidence_valid = trpt->bup.oval;
		;
		goto R999;

	case 9: // STATE 11
		;
		now.proposal_allowed = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 12
		;
		now.proposal_allowed = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 16
		;
		now.namespace_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 12: // STATE 17
		;
		now.namespace_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 13: // STATE 21
		;
		now.observed_target_present = trpt->bup.oval;
		;
		goto R999;

	case 14: // STATE 22
		;
		now.observed_target_present = trpt->bup.oval;
		;
		goto R999;

	case 15: // STATE 26
		;
		now.observed_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 27
		;
		now.observed_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 31
		;
		now.template_matches = trpt->bup.oval;
		;
		goto R999;

	case 18: // STATE 32
		;
		now.template_matches = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 36
		;
		now.probe_matches = trpt->bup.oval;
		;
		goto R999;

	case 20: // STATE 37
		;
		now.probe_matches = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 22: // STATE 42
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 24: // STATE 44
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 26: // STATE 46
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 29: // STATE 49
		;
		now.patch_target_present = trpt->bup.oval;
		;
		goto R999;

	case 30: // STATE 50
		;
		now.patch_target_present = trpt->bup.oval;
		;
		goto R999;

	case 31: // STATE 54
		;
		now.patch_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 32: // STATE 55
		;
		now.patch_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 33: // STATE 59
		;
		now.resource_version_matches = trpt->bup.oval;
		;
		goto R999;

	case 34: // STATE 60
		;
		now.resource_version_matches = trpt->bup.oval;
		;
		goto R999;

	case 35: // STATE 64
		;
		now.api_accepts = trpt->bup.oval;
		;
		goto R999;

	case 36: // STATE 65
		;
		now.api_accepts = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 38: // STATE 81
		;
		now.patch_applied = trpt->bup.ovals[1];
		now.effects = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 39: // STATE 85
		goto R999;

	case 40: // STATE 83
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 42: // STATE 88
		;
		now.patch_acknowledged = trpt->bup.oval;
		;
		goto R999;

	case 43: // STATE 89
		;
		now.patch_acknowledged = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 45: // STATE 94
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 47: // STATE 96
		;
		now.recovery_identity_matches = trpt->bup.oval;
		;
		goto R999;

	case 48: // STATE 97
		;
		now.recovery_identity_matches = trpt->bup.oval;
		;
		goto R999;

	case 49: // STATE 101
		;
		now.generation_observed = trpt->bup.oval;
		;
		goto R999;

	case 50: // STATE 102
		;
		now.generation_observed = trpt->bup.oval;
		;
		goto R999;

	case 51: // STATE 106
		;
		now.rollout_ready = trpt->bup.oval;
		;
		goto R999;

	case 52: // STATE 107
		;
		now.rollout_ready = trpt->bup.oval;
		;
		goto R999;

	case 53: // STATE 111
		;
		now.replacement_pod_ready = trpt->bup.oval;
		;
		goto R999;

	case 54: // STATE 112
		;
		now.replacement_pod_ready = trpt->bup.oval;
		;
		goto R999;

	case 55: // STATE 116
		;
		now.endpoint_200_body = trpt->bup.oval;
		;
		goto R999;

	case 56: // STATE 117
		;
		now.endpoint_200_body = trpt->bup.oval;
		;
		goto R999;

	case 57: // STATE 121
		;
		now.fresh_metrics = trpt->bup.oval;
		;
		goto R999;

	case 58: // STATE 122
		;
		now.fresh_metrics = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 60: // STATE 127
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 62: // STATE 129
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		
	case 67: // STATE 141
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		
	case 72: // STATE 150
		;
		now.report_authenticated = trpt->bup.oval;
		;
		goto R999;

	case 73: // STATE 151
		;
		now.report_authenticated = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 75: // STATE 156
		;
		now.report_published = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 78: // STATE 162
		;
		now.done = trpt->bup.oval;
		;
		goto R999;

	case 79: // STATE 163
		;
		p_restor(II);
		;
		;
		goto R999;
	}

