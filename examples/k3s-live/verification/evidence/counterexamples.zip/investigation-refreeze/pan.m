#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM investigation_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(done))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[2][1] = 1;
		if (!( !(((int)now.done))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[2][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Investigation */
	case 5: // STATE 1 - investigation.pml:44 - [i = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[1][1] = 1;
		(trpt+1)->bup.oval = ((int)((P1 *)_this)->i);
		((P1 *)_this)->i = 0;
#ifdef VAR_RANGES
		logval("Investigation:i", ((int)((P1 *)_this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - investigation.pml:45 - [((i<4))] (7:0:2 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!((((int)((P1 *)_this)->i)<4)))
			continue;
		/* merge: tool[i] = Unused(7, 3, 7) */
		reached[1][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)((P1 *)_this)->i), 4) ];
		now.tool[ Index(((P1 *)_this)->i, 4) ] = 5;
#ifdef VAR_RANGES
		logval("tool[Investigation:i]", now.tool[ Index(((int)((P1 *)_this)->i), 4) ]);
#endif
		;
		/* merge: i = (i+1)(7, 4, 7) */
		reached[1][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->i);
		((P1 *)_this)->i = (((int)((P1 *)_this)->i)+1);
#ifdef VAR_RANGES
		logval("Investigation:i", ((int)((P1 *)_this)->i));
#endif
		;
		/* merge: .(goto)(0, 8, 7) */
		reached[1][8] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 7: // STATE 11 - investigation.pml:48 - [(done)] (0:0:0 - 1)
		IfNotBlocked
		reached[1][11] = 1;
		if (!(((int)now.done)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 13 - investigation.pml:49 - [((!(done)&&cancelled))] (103:0:2 - 1)
		IfNotBlocked
		reached[1][13] = 1;
		if (!(( !(((int)now.done))&&((int)now.cancelled))))
			continue;
		/* merge: phase = Cancelled(103, 14, 103) */
		reached[1][14] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 6;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(103, 15, 103) */
		reached[1][15] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 9: // STATE 17 - investigation.pml:51 - [(((!(done)&&!(cancelled))&&(restarts<2)))] (23:0:1 - 1)
		IfNotBlocked
		reached[1][17] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(((int)now.restarts)<2))))
			continue;
		/* merge: restarts = (restarts+1)(0, 18, 23) */
		reached[1][18] = 1;
		(trpt+1)->bup.oval = ((int)now.restarts);
		now.restarts = (((int)now.restarts)+1);
#ifdef VAR_RANGES
		logval("restarts", ((int)now.restarts));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 10: // STATE 19 - investigation.pml:53 - [(((phase==Acquiring)&&(tool[slot]==Recorded)))] (29:0:1 - 1)
		IfNotBlocked
		reached[1][19] = 1;
		if (!(((now.phase==12)&&(now.tool[ Index(((int)now.slot), 4) ]==2))))
			continue;
		/* merge: recorded_restart = 1(0, 20, 29) */
		reached[1][20] = 1;
		(trpt+1)->bup.oval = ((int)recorded_restart);
		recorded_restart = 1;
#ifdef VAR_RANGES
		logval("recorded_restart", ((int)recorded_restart));
#endif
		;
		/* merge: .(goto)(0, 24, 29) */
		reached[1][24] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 11: // STATE 25 - investigation.pml:55 - [((phase==Frozen))] (36:0:1 - 1)
		IfNotBlocked
		reached[1][25] = 1;
		if (!((now.phase==10)))
			continue;
		/* merge: frozen_restart = 1(0, 26, 36) */
		reached[1][26] = 1;
		(trpt+1)->bup.oval = ((int)frozen_restart);
		frozen_restart = 1;
#ifdef VAR_RANGES
		logval("frozen_restart", ((int)frozen_restart));
#endif
		;
		/* merge: .(goto)(0, 30, 36) */
		reached[1][30] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 12: // STATE 31 - investigation.pml:58 - [(((phase==Acquiring)&&((tool[slot]==Reserved)||(tool[slot]==Invoked))))] (42:0:2 - 1)
		IfNotBlocked
		reached[1][31] = 1;
		if (!(((now.phase==12)&&((now.tool[ Index(((int)now.slot), 4) ]==4)||(now.tool[ Index(((int)now.slot), 4) ]==3)))))
			continue;
		/* merge: tool[slot] = Uncertain(42, 32, 42) */
		reached[1][32] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 1;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: has_unknown = 1(42, 33, 42) */
		reached[1][33] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.has_unknown);
		now.has_unknown = 1;
#ifdef VAR_RANGES
		logval("has_unknown", ((int)now.has_unknown));
#endif
		;
		/* merge: .(goto)(0, 37, 42) */
		reached[1][37] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 13: // STATE 38 - investigation.pml:70 - [((phase==Frozen))] (103:0:1 - 1)
		IfNotBlocked
		reached[1][38] = 1;
		if (!((now.phase==10)))
			continue;
		/* merge: frozen_version = (frozen_version+1)(103, 39, 103) */
		reached[1][39] = 1;
		(trpt+1)->bup.oval = ((int)now.frozen_version);
		now.frozen_version = (((int)now.frozen_version)+1);
#ifdef VAR_RANGES
		logval("frozen_version", ((int)now.frozen_version));
#endif
		;
		/* merge: .(goto)(103, 43, 103) */
		reached[1][43] = 1;
		;
		/* merge: assert((frozen_version<=1))(103, 44, 103) */
		reached[1][44] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 14: // STATE 43 - investigation.pml:72 - [.(goto)] (0:103:0 - 2)
		IfNotBlocked
		reached[1][43] = 1;
		;
		/* merge: assert((frozen_version<=1))(103, 44, 103) */
		reached[1][44] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 15: // STATE 41 - investigation.pml:70 - [(1)] (103:0:0 - 1)
		IfNotBlocked
		reached[1][41] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(103, 43, 103) */
		reached[1][43] = 1;
		;
		/* merge: assert((frozen_version<=1))(103, 44, 103) */
		reached[1][44] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 16: // STATE 46 - investigation.pml:75 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Unused)))] (103:0:1 - 1)
		IfNotBlocked
		reached[1][46] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==5))))
			continue;
		/* merge: tool[slot] = Reserved(0, 47, 103) */
		reached[1][47] = 1;
		(trpt+1)->bup.oval = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 4;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 17: // STATE 49 - investigation.pml:79 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Reserved)))] (103:0:2 - 1)
		IfNotBlocked
		reached[1][49] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==4))))
			continue;
		/* merge: assert(!(cancelled))(103, 50, 103) */
		reached[1][50] = 1;
		spin_assert( !(((int)now.cancelled)), " !(cancelled)", II, tt, t);
		/* merge: calls[slot] = (calls[slot]+1)(103, 51, 103) */
		reached[1][51] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.calls[ Index(((int)now.slot), 4) ]);
		now.calls[ Index(now.slot, 4) ] = (((int)now.calls[ Index(((int)now.slot), 4) ])+1);
#ifdef VAR_RANGES
		logval("calls[slot]", ((int)now.calls[ Index(((int)now.slot), 4) ]));
#endif
		;
		/* merge: assert((calls[slot]<=1))(103, 52, 103) */
		reached[1][52] = 1;
		spin_assert((((int)now.calls[ Index(((int)now.slot), 4) ])<=1), "(calls[slot]<=1)", II, tt, t);
		/* merge: tool[slot] = Invoked(103, 53, 103) */
		reached[1][53] = 1;
		(trpt+1)->bup.ovals[1] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 3;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 18: // STATE 55 - investigation.pml:87 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Invoked)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][55] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==3))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 56 - investigation.pml:89 - [tool[slot] = Recorded] (0:60:2 - 1)
		IfNotBlocked
		reached[1][56] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 2;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: results = (results+1)(60, 57, 60) */
		reached[1][57] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.results);
		now.results = (((int)now.results)+1);
#ifdef VAR_RANGES
		logval("results", ((int)now.results));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 20: // STATE 58 - investigation.pml:92 - [(1)] (103:0:0 - 1)
		IfNotBlocked
		reached[1][58] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(103, 61, 103) */
		reached[1][61] = 1;
		;
		/* merge: .(goto)(103, 65, 103) */
		reached[1][65] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 21: // STATE 61 - investigation.pml:93 - [.(goto)] (0:103:0 - 2)
		IfNotBlocked
		reached[1][61] = 1;
		;
		/* merge: .(goto)(103, 65, 103) */
		reached[1][65] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 22: // STATE 59 - investigation.pml:92 - [all_trusted = 0] (0:103:1 - 1)
		IfNotBlocked
		reached[1][59] = 1;
		(trpt+1)->bup.oval = ((int)now.all_trusted);
		now.all_trusted = 0;
#ifdef VAR_RANGES
		logval("all_trusted", ((int)now.all_trusted));
#endif
		;
		/* merge: .(goto)(103, 61, 103) */
		reached[1][61] = 1;
		;
		/* merge: .(goto)(103, 65, 103) */
		reached[1][65] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 23: // STATE 65 - investigation.pml:95 - [.(goto)] (0:103:0 - 2)
		IfNotBlocked
		reached[1][65] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 24: // STATE 62 - investigation.pml:93 - [tool[slot] = Uncertain] (0:103:2 - 1)
		IfNotBlocked
		reached[1][62] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 1;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: has_unknown = 1(103, 63, 103) */
		reached[1][63] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.has_unknown);
		now.has_unknown = 1;
#ifdef VAR_RANGES
		logval("has_unknown", ((int)now.has_unknown));
#endif
		;
		/* merge: .(goto)(103, 65, 103) */
		reached[1][65] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 25: // STATE 67 - investigation.pml:97 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Recorded)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][67] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==2))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 26: // STATE 68 - investigation.pml:99 - [phase = Acquired] (0:103:1 - 1)
		IfNotBlocked
		reached[1][68] = 1;
		(trpt+1)->bup.oval = now.phase;
		now.phase = 11;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: .(goto)(103, 72, 103) */
		reached[1][72] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 27: // STATE 72 - investigation.pml:102 - [.(goto)] (0:103:0 - 2)
		IfNotBlocked
		reached[1][72] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 28: // STATE 69 - investigation.pml:100 - [((slot<(4-1)))] (103:0:1 - 1)
		IfNotBlocked
		reached[1][69] = 1;
		if (!((((int)now.slot)<(4-1))))
			continue;
		/* merge: slot = (slot+1)(103, 70, 103) */
		reached[1][70] = 1;
		(trpt+1)->bup.oval = ((int)now.slot);
		now.slot = (((int)now.slot)+1);
#ifdef VAR_RANGES
		logval("slot", ((int)now.slot));
#endif
		;
		/* merge: .(goto)(103, 72, 103) */
		reached[1][72] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 29: // STATE 74 - investigation.pml:104 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Uncertain)))] (103:0:2 - 1)
		IfNotBlocked
		reached[1][74] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==1))))
			continue;
		/* merge: phase = Blocked(103, 75, 103) */
		reached[1][75] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 7;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(103, 76, 103) */
		reached[1][76] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 30: // STATE 78 - investigation.pml:112 - [(((!(done)&&!(cancelled))&&(phase==Acquired)))] (89:0:0 - 1)
		IfNotBlocked
		reached[1][78] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==11))))
			continue;
		/* merge: assert(!(has_unknown))(0, 79, 89) */
		reached[1][79] = 1;
		spin_assert( !(((int)now.has_unknown)), " !(has_unknown)", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 31: // STATE 80 - investigation.pml:117 - [(((all_trusted&&!(has_unknown))&&(results>0)))] (103:0:2 - 1)
		IfNotBlocked
		reached[1][80] = 1;
		if (!(((((int)now.all_trusted)&& !(((int)now.has_unknown)))&&(((int)now.results)>0))))
			continue;
		/* merge: assert(all_trusted)(103, 81, 103) */
		reached[1][81] = 1;
		spin_assert(((int)now.all_trusted), "all_trusted", II, tt, t);
		/* merge: assert(!(has_unknown))(103, 82, 103) */
		reached[1][82] = 1;
		spin_assert( !(((int)now.has_unknown)), " !(has_unknown)", II, tt, t);
		/* merge: frozen_version = (frozen_version+1)(103, 83, 103) */
		reached[1][83] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.frozen_version);
		now.frozen_version = (((int)now.frozen_version)+1);
#ifdef VAR_RANGES
		logval("frozen_version", ((int)now.frozen_version));
#endif
		;
		/* merge: assert((frozen_version==1))(103, 84, 103) */
		reached[1][84] = 1;
		spin_assert((((int)now.frozen_version)==1), "(frozen_version==1)", II, tt, t);
		/* merge: phase = Frozen(103, 85, 103) */
		reached[1][85] = 1;
		(trpt+1)->bup.ovals[1] = now.phase;
		now.phase = 10;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: .(goto)(103, 90, 103) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 32: // STATE 90 - investigation.pml:126 - [.(goto)] (0:103:0 - 2)
		IfNotBlocked
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 33: // STATE 87 - investigation.pml:124 - [phase = Blocked] (0:103:2 - 1)
		IfNotBlocked
		reached[1][87] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 7;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(103, 88, 103) */
		reached[1][88] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(103, 90, 103) */
		reached[1][90] = 1;
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 34: // STATE 92 - investigation.pml:137 - [(((!(done)&&!(cancelled))&&(phase==Frozen)))] (103:0:2 - 1)
		IfNotBlocked
		reached[1][92] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==10))))
			continue;
		/* merge: assert(!(cancelled))(103, 93, 103) */
		reached[1][93] = 1;
		spin_assert( !(((int)now.cancelled)), " !(cancelled)", II, tt, t);
		/* merge: assert((((frozen_version==1)&&all_trusted)&&!(has_unknown)))(103, 94, 103) */
		reached[1][94] = 1;
		spin_assert((((((int)now.frozen_version)==1)&&((int)now.all_trusted))&& !(((int)now.has_unknown))), "(((frozen_version==1)&&all_trusted)&& !(has_unknown))", II, tt, t);
		/* merge: assessment_starts = (assessment_starts+1)(103, 95, 103) */
		reached[1][95] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.assessment_starts);
		now.assessment_starts = (((int)now.assessment_starts)+1);
#ifdef VAR_RANGES
		logval("assessment_starts", ((int)now.assessment_starts));
#endif
		;
		/* merge: assert((assessment_starts==1))(103, 96, 103) */
		reached[1][96] = 1;
		spin_assert((((int)now.assessment_starts)==1), "(assessment_starts==1)", II, tt, t);
		/* merge: phase = Assessing(103, 97, 103) */
		reached[1][97] = 1;
		(trpt+1)->bup.ovals[1] = now.phase;
		now.phase = 9;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 35: // STATE 99 - investigation.pml:147 - [(((!(done)&&!(cancelled))&&(phase==Assessing)))] (103:0:2 - 1)
		IfNotBlocked
		reached[1][99] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==9))))
			continue;
		/* merge: phase = Completed(103, 100, 103) */
		reached[1][100] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 8;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(103, 101, 103) */
		reached[1][101] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(0, 104, 103) */
		reached[1][104] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 36: // STATE 106 - investigation.pml:155 - [assert((results<=4))] (0:0:0 - 3)
		IfNotBlocked
		reached[1][106] = 1;
		spin_assert((((int)now.results)<=4), "(results<=4)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 37: // STATE 107 - investigation.pml:156 - [assert((frozen_version<=1))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][107] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 38: // STATE 108 - investigation.pml:166 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[1][108] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Cancellation */
	case 39: // STATE 1 - investigation.pml:38 - [cancelled = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)now.cancelled);
		now.cancelled = 1;
#ifdef VAR_RANGES
		logval("cancelled", ((int)now.cancelled));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 5 - investigation.pml:39 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[0][5] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

