#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM investigation_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(done))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[2][1] = 1;
		if (!( !(((int)now.done))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[2][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Investigation */
	case 5: // STATE 1 - investigation.pml:44 - [i = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[1][1] = 1;
		(trpt+1)->bup.oval = ((int)((P1 *)_this)->i);
		((P1 *)_this)->i = 0;
#ifdef VAR_RANGES
		logval("Investigation:i", ((int)((P1 *)_this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - investigation.pml:45 - [((i<4))] (7:0:2 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!((((int)((P1 *)_this)->i)<4)))
			continue;
		/* merge: tool[i] = Unused(7, 3, 7) */
		reached[1][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)((P1 *)_this)->i), 4) ];
		now.tool[ Index(((P1 *)_this)->i, 4) ] = 5;
#ifdef VAR_RANGES
		logval("tool[Investigation:i]", now.tool[ Index(((int)((P1 *)_this)->i), 4) ]);
#endif
		;
		/* merge: i = (i+1)(7, 4, 7) */
		reached[1][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->i);
		((P1 *)_this)->i = (((int)((P1 *)_this)->i)+1);
#ifdef VAR_RANGES
		logval("Investigation:i", ((int)((P1 *)_this)->i));
#endif
		;
		/* merge: .(goto)(0, 8, 7) */
		reached[1][8] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 7: // STATE 11 - investigation.pml:48 - [(done)] (0:0:0 - 1)
		IfNotBlocked
		reached[1][11] = 1;
		if (!(((int)now.done)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 13 - investigation.pml:49 - [((!(done)&&cancelled))] (97:0:2 - 1)
		IfNotBlocked
		reached[1][13] = 1;
		if (!(( !(((int)now.done))&&((int)now.cancelled))))
			continue;
		/* merge: phase = Cancelled(97, 14, 97) */
		reached[1][14] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 6;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(97, 15, 97) */
		reached[1][15] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 9: // STATE 17 - investigation.pml:51 - [(((!(done)&&!(cancelled))&&(restarts<2)))] (23:0:1 - 1)
		IfNotBlocked
		reached[1][17] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(((int)now.restarts)<2))))
			continue;
		/* merge: restarts = (restarts+1)(0, 18, 23) */
		reached[1][18] = 1;
		(trpt+1)->bup.oval = ((int)now.restarts);
		now.restarts = (((int)now.restarts)+1);
#ifdef VAR_RANGES
		logval("restarts", ((int)now.restarts));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 10: // STATE 19 - investigation.pml:53 - [(((phase==Acquiring)&&(tool[slot]==Recorded)))] (29:0:1 - 1)
		IfNotBlocked
		reached[1][19] = 1;
		if (!(((now.phase==12)&&(now.tool[ Index(((int)now.slot), 4) ]==2))))
			continue;
		/* merge: recorded_restart = 1(0, 20, 29) */
		reached[1][20] = 1;
		(trpt+1)->bup.oval = ((int)recorded_restart);
		recorded_restart = 1;
#ifdef VAR_RANGES
		logval("recorded_restart", ((int)recorded_restart));
#endif
		;
		/* merge: .(goto)(0, 24, 29) */
		reached[1][24] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 11: // STATE 25 - investigation.pml:55 - [((phase==Frozen))] (36:0:1 - 1)
		IfNotBlocked
		reached[1][25] = 1;
		if (!((now.phase==10)))
			continue;
		/* merge: frozen_restart = 1(0, 26, 36) */
		reached[1][26] = 1;
		(trpt+1)->bup.oval = ((int)frozen_restart);
		frozen_restart = 1;
#ifdef VAR_RANGES
		logval("frozen_restart", ((int)frozen_restart));
#endif
		;
		/* merge: .(goto)(0, 30, 36) */
		reached[1][30] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 12: // STATE 31 - investigation.pml:58 - [(((phase==Acquiring)&&((tool[slot]==Reserved)||(tool[slot]==Invoked))))] (97:0:2 - 1)
		IfNotBlocked
		reached[1][31] = 1;
		if (!(((now.phase==12)&&((now.tool[ Index(((int)now.slot), 4) ]==4)||(now.tool[ Index(((int)now.slot), 4) ]==3)))))
			continue;
		/* merge: tool[slot] = Uncertain(97, 32, 97) */
		reached[1][32] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 1;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: has_unknown = 1(97, 33, 97) */
		reached[1][33] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.has_unknown);
		now.has_unknown = 1;
#ifdef VAR_RANGES
		logval("has_unknown", ((int)now.has_unknown));
#endif
		;
		/* merge: .(goto)(97, 37, 97) */
		reached[1][37] = 1;
		;
		/* merge: assert((frozen_version<=1))(97, 38, 97) */
		reached[1][38] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 13: // STATE 37 - investigation.pml:72 - [.(goto)] (0:97:0 - 2)
		IfNotBlocked
		reached[1][37] = 1;
		;
		/* merge: assert((frozen_version<=1))(97, 38, 97) */
		reached[1][38] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 14: // STATE 35 - investigation.pml:60 - [(1)] (97:0:0 - 1)
		IfNotBlocked
		reached[1][35] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(97, 37, 97) */
		reached[1][37] = 1;
		;
		/* merge: assert((frozen_version<=1))(97, 38, 97) */
		reached[1][38] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 15: // STATE 40 - investigation.pml:75 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Unused)))] (97:0:1 - 1)
		IfNotBlocked
		reached[1][40] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==5))))
			continue;
		/* merge: tool[slot] = Reserved(0, 41, 97) */
		reached[1][41] = 1;
		(trpt+1)->bup.oval = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 4;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 16: // STATE 43 - investigation.pml:79 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Reserved)))] (97:0:2 - 1)
		IfNotBlocked
		reached[1][43] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==4))))
			continue;
		/* merge: assert(!(cancelled))(97, 44, 97) */
		reached[1][44] = 1;
		spin_assert( !(((int)now.cancelled)), " !(cancelled)", II, tt, t);
		/* merge: calls[slot] = (calls[slot]+1)(97, 45, 97) */
		reached[1][45] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.calls[ Index(((int)now.slot), 4) ]);
		now.calls[ Index(now.slot, 4) ] = (((int)now.calls[ Index(((int)now.slot), 4) ])+1);
#ifdef VAR_RANGES
		logval("calls[slot]", ((int)now.calls[ Index(((int)now.slot), 4) ]));
#endif
		;
		/* merge: assert((calls[slot]<=1))(97, 46, 97) */
		reached[1][46] = 1;
		spin_assert((((int)now.calls[ Index(((int)now.slot), 4) ])<=1), "(calls[slot]<=1)", II, tt, t);
		/* merge: tool[slot] = Invoked(97, 47, 97) */
		reached[1][47] = 1;
		(trpt+1)->bup.ovals[1] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 3;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 17: // STATE 49 - investigation.pml:87 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Invoked)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][49] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==3))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 50 - investigation.pml:89 - [tool[slot] = Recorded] (0:54:2 - 1)
		IfNotBlocked
		reached[1][50] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 2;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: results = (results+1)(54, 51, 54) */
		reached[1][51] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.results);
		now.results = (((int)now.results)+1);
#ifdef VAR_RANGES
		logval("results", ((int)now.results));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 19: // STATE 52 - investigation.pml:92 - [(1)] (97:0:0 - 1)
		IfNotBlocked
		reached[1][52] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(97, 55, 97) */
		reached[1][55] = 1;
		;
		/* merge: .(goto)(97, 59, 97) */
		reached[1][59] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 20: // STATE 55 - investigation.pml:93 - [.(goto)] (0:97:0 - 2)
		IfNotBlocked
		reached[1][55] = 1;
		;
		/* merge: .(goto)(97, 59, 97) */
		reached[1][59] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 21: // STATE 53 - investigation.pml:92 - [all_trusted = 0] (0:97:1 - 1)
		IfNotBlocked
		reached[1][53] = 1;
		(trpt+1)->bup.oval = ((int)now.all_trusted);
		now.all_trusted = 0;
#ifdef VAR_RANGES
		logval("all_trusted", ((int)now.all_trusted));
#endif
		;
		/* merge: .(goto)(97, 55, 97) */
		reached[1][55] = 1;
		;
		/* merge: .(goto)(97, 59, 97) */
		reached[1][59] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 22: // STATE 59 - investigation.pml:95 - [.(goto)] (0:97:0 - 2)
		IfNotBlocked
		reached[1][59] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 23: // STATE 56 - investigation.pml:93 - [tool[slot] = Uncertain] (0:97:2 - 1)
		IfNotBlocked
		reached[1][56] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 1;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: has_unknown = 1(97, 57, 97) */
		reached[1][57] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.has_unknown);
		now.has_unknown = 1;
#ifdef VAR_RANGES
		logval("has_unknown", ((int)now.has_unknown));
#endif
		;
		/* merge: .(goto)(97, 59, 97) */
		reached[1][59] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 24: // STATE 61 - investigation.pml:97 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Recorded)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][61] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==2))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 62 - investigation.pml:99 - [phase = Acquired] (0:97:1 - 1)
		IfNotBlocked
		reached[1][62] = 1;
		(trpt+1)->bup.oval = now.phase;
		now.phase = 11;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: .(goto)(97, 66, 97) */
		reached[1][66] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 26: // STATE 66 - investigation.pml:102 - [.(goto)] (0:97:0 - 2)
		IfNotBlocked
		reached[1][66] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 27: // STATE 63 - investigation.pml:100 - [((slot<(4-1)))] (97:0:1 - 1)
		IfNotBlocked
		reached[1][63] = 1;
		if (!((((int)now.slot)<(4-1))))
			continue;
		/* merge: slot = (slot+1)(97, 64, 97) */
		reached[1][64] = 1;
		(trpt+1)->bup.oval = ((int)now.slot);
		now.slot = (((int)now.slot)+1);
#ifdef VAR_RANGES
		logval("slot", ((int)now.slot));
#endif
		;
		/* merge: .(goto)(97, 66, 97) */
		reached[1][66] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 28: // STATE 68 - investigation.pml:104 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Uncertain)))] (97:0:2 - 1)
		IfNotBlocked
		reached[1][68] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==1))))
			continue;
		/* merge: phase = Blocked(97, 69, 97) */
		reached[1][69] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 7;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(97, 70, 97) */
		reached[1][70] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 29: // STATE 72 - investigation.pml:112 - [(((!(done)&&!(cancelled))&&(phase==Acquired)))] (83:0:0 - 1)
		IfNotBlocked
		reached[1][72] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==11))))
			continue;
		/* merge: assert(!(has_unknown))(0, 73, 83) */
		reached[1][73] = 1;
		spin_assert( !(((int)now.has_unknown)), " !(has_unknown)", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 30: // STATE 74 - investigation.pml:117 - [(((all_trusted&&!(has_unknown))&&(results>0)))] (97:0:2 - 1)
		IfNotBlocked
		reached[1][74] = 1;
		if (!(((((int)now.all_trusted)&& !(((int)now.has_unknown)))&&(((int)now.results)>0))))
			continue;
		/* merge: assert(all_trusted)(97, 75, 97) */
		reached[1][75] = 1;
		spin_assert(((int)now.all_trusted), "all_trusted", II, tt, t);
		/* merge: assert(!(has_unknown))(97, 76, 97) */
		reached[1][76] = 1;
		spin_assert( !(((int)now.has_unknown)), " !(has_unknown)", II, tt, t);
		/* merge: frozen_version = (frozen_version+1)(97, 77, 97) */
		reached[1][77] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.frozen_version);
		now.frozen_version = (((int)now.frozen_version)+1);
#ifdef VAR_RANGES
		logval("frozen_version", ((int)now.frozen_version));
#endif
		;
		/* merge: assert((frozen_version==1))(97, 78, 97) */
		reached[1][78] = 1;
		spin_assert((((int)now.frozen_version)==1), "(frozen_version==1)", II, tt, t);
		/* merge: phase = Frozen(97, 79, 97) */
		reached[1][79] = 1;
		(trpt+1)->bup.ovals[1] = now.phase;
		now.phase = 10;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: .(goto)(97, 84, 97) */
		reached[1][84] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 31: // STATE 84 - investigation.pml:126 - [.(goto)] (0:97:0 - 2)
		IfNotBlocked
		reached[1][84] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 32: // STATE 81 - investigation.pml:124 - [phase = Blocked] (0:97:2 - 1)
		IfNotBlocked
		reached[1][81] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 7;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(97, 82, 97) */
		reached[1][82] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(97, 84, 97) */
		reached[1][84] = 1;
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 33: // STATE 86 - investigation.pml:137 - [(((!(done)&&!(cancelled))&&(phase==Frozen)))] (97:0:2 - 1)
		IfNotBlocked
		reached[1][86] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==10))))
			continue;
		/* merge: assert(!(cancelled))(97, 87, 97) */
		reached[1][87] = 1;
		spin_assert( !(((int)now.cancelled)), " !(cancelled)", II, tt, t);
		/* merge: assert((((frozen_version==1)&&all_trusted)&&!(has_unknown)))(97, 88, 97) */
		reached[1][88] = 1;
		spin_assert((((((int)now.frozen_version)==1)&&((int)now.all_trusted))&& !(((int)now.has_unknown))), "(((frozen_version==1)&&all_trusted)&& !(has_unknown))", II, tt, t);
		/* merge: assessment_starts = (assessment_starts+1)(97, 89, 97) */
		reached[1][89] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.assessment_starts);
		now.assessment_starts = (((int)now.assessment_starts)+1);
#ifdef VAR_RANGES
		logval("assessment_starts", ((int)now.assessment_starts));
#endif
		;
		/* merge: assert((assessment_starts==1))(97, 90, 97) */
		reached[1][90] = 1;
		spin_assert((((int)now.assessment_starts)==1), "(assessment_starts==1)", II, tt, t);
		/* merge: phase = Assessing(97, 91, 97) */
		reached[1][91] = 1;
		(trpt+1)->bup.ovals[1] = now.phase;
		now.phase = 9;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 34: // STATE 93 - investigation.pml:147 - [(((!(done)&&!(cancelled))&&(phase==Assessing)))] (97:0:2 - 1)
		IfNotBlocked
		reached[1][93] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==9))))
			continue;
		/* merge: phase = Completed(97, 94, 97) */
		reached[1][94] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 8;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(97, 95, 97) */
		reached[1][95] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(0, 98, 97) */
		reached[1][98] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 35: // STATE 100 - investigation.pml:155 - [assert((results<=4))] (0:0:0 - 3)
		IfNotBlocked
		reached[1][100] = 1;
		spin_assert((((int)now.results)<=4), "(results<=4)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 36: // STATE 101 - investigation.pml:156 - [assert((frozen_version<=1))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][101] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 37: // STATE 102 - investigation.pml:158 - [assert(!(((phase==Completed)&&(results==4))))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][102] = 1;
		spin_assert( !(((now.phase==8)&&(((int)now.results)==4))), " !(((phase==8)&&(results==4)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 38: // STATE 103 - investigation.pml:166 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[1][103] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Cancellation */
	case 39: // STATE 1 - investigation.pml:38 - [cancelled = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)now.cancelled);
		now.cancelled = 1;
#ifdef VAR_RANGES
		logval("cancelled", ((int)now.cancelled));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 5 - investigation.pml:39 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[0][5] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

