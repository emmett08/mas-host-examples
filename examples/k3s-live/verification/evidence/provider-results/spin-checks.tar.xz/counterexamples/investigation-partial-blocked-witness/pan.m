#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM investigation_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(done))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[2][1] = 1;
		if (!( !(((int)now.done))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[2][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Investigation */
	case 5: // STATE 1 - investigation.pml:50 - [i = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[1][1] = 1;
		(trpt+1)->bup.oval = ((int)((P1 *)_this)->i);
		((P1 *)_this)->i = 0;
#ifdef VAR_RANGES
		logval("Investigation:i", ((int)((P1 *)_this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - investigation.pml:51 - [((i<4))] (7:0:2 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!((((int)((P1 *)_this)->i)<4)))
			continue;
		/* merge: tool[i] = Unused(7, 3, 7) */
		reached[1][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)((P1 *)_this)->i), 4) ];
		now.tool[ Index(((P1 *)_this)->i, 4) ] = 5;
#ifdef VAR_RANGES
		logval("tool[Investigation:i]", now.tool[ Index(((int)((P1 *)_this)->i), 4) ]);
#endif
		;
		/* merge: i = (i+1)(7, 4, 7) */
		reached[1][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->i);
		((P1 *)_this)->i = (((int)((P1 *)_this)->i)+1);
#ifdef VAR_RANGES
		logval("Investigation:i", ((int)((P1 *)_this)->i));
#endif
		;
		/* merge: .(goto)(0, 8, 7) */
		reached[1][8] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 7: // STATE 11 - investigation.pml:54 - [(done)] (0:0:0 - 1)
		IfNotBlocked
		reached[1][11] = 1;
		if (!(((int)now.done)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 13 - investigation.pml:55 - [((!(done)&&cancelled))] (111:0:2 - 1)
		IfNotBlocked
		reached[1][13] = 1;
		if (!(( !(((int)now.done))&&((int)now.cancelled))))
			continue;
		/* merge: phase = Cancelled(111, 14, 111) */
		reached[1][14] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 6;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(111, 15, 111) */
		reached[1][15] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 9: // STATE 17 - investigation.pml:57 - [(((!(done)&&!(cancelled))&&(restarts<2)))] (23:0:1 - 1)
		IfNotBlocked
		reached[1][17] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(((int)now.restarts)<2))))
			continue;
		/* merge: restarts = (restarts+1)(0, 18, 23) */
		reached[1][18] = 1;
		(trpt+1)->bup.oval = ((int)now.restarts);
		now.restarts = (((int)now.restarts)+1);
#ifdef VAR_RANGES
		logval("restarts", ((int)now.restarts));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 10: // STATE 19 - investigation.pml:59 - [(((phase==Acquiring)&&(tool[slot]==Recorded)))] (29:0:1 - 1)
		IfNotBlocked
		reached[1][19] = 1;
		if (!(((now.phase==12)&&(now.tool[ Index(((int)now.slot), 4) ]==2))))
			continue;
		/* merge: recorded_restart = 1(0, 20, 29) */
		reached[1][20] = 1;
		(trpt+1)->bup.oval = ((int)recorded_restart);
		recorded_restart = 1;
#ifdef VAR_RANGES
		logval("recorded_restart", ((int)recorded_restart));
#endif
		;
		/* merge: .(goto)(0, 24, 29) */
		reached[1][24] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 11: // STATE 25 - investigation.pml:61 - [((phase==Frozen))] (36:0:1 - 1)
		IfNotBlocked
		reached[1][25] = 1;
		if (!((now.phase==10)))
			continue;
		/* merge: frozen_restart = 1(0, 26, 36) */
		reached[1][26] = 1;
		(trpt+1)->bup.oval = ((int)frozen_restart);
		frozen_restart = 1;
#ifdef VAR_RANGES
		logval("frozen_restart", ((int)frozen_restart));
#endif
		;
		/* merge: .(goto)(0, 30, 36) */
		reached[1][30] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 12: // STATE 31 - investigation.pml:64 - [(((phase==Acquiring)&&((tool[slot]==Reserved)||(tool[slot]==Invoked))))] (111:0:2 - 1)
		IfNotBlocked
		reached[1][31] = 1;
		if (!(((now.phase==12)&&((now.tool[ Index(((int)now.slot), 4) ]==4)||(now.tool[ Index(((int)now.slot), 4) ]==3)))))
			continue;
		/* merge: tool[slot] = Uncertain(111, 32, 111) */
		reached[1][32] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 1;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: has_unknown = 1(111, 33, 111) */
		reached[1][33] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.has_unknown);
		now.has_unknown = 1;
#ifdef VAR_RANGES
		logval("has_unknown", ((int)now.has_unknown));
#endif
		;
		/* merge: .(goto)(111, 37, 111) */
		reached[1][37] = 1;
		;
		/* merge: assert((frozen_version<=1))(111, 38, 111) */
		reached[1][38] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 13: // STATE 37 - investigation.pml:78 - [.(goto)] (0:111:0 - 2)
		IfNotBlocked
		reached[1][37] = 1;
		;
		/* merge: assert((frozen_version<=1))(111, 38, 111) */
		reached[1][38] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 14: // STATE 35 - investigation.pml:66 - [(1)] (111:0:0 - 1)
		IfNotBlocked
		reached[1][35] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(111, 37, 111) */
		reached[1][37] = 1;
		;
		/* merge: assert((frozen_version<=1))(111, 38, 111) */
		reached[1][38] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 15: // STATE 40 - investigation.pml:81 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Unused)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][40] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 41 - investigation.pml:84 - [actor[slot] = 0] (0:111:2 - 1)
		IfNotBlocked
		reached[1][41] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.actor[ Index(((int)now.slot), 4) ]);
		now.actor[ Index(now.slot, 4) ] = 0;
#ifdef VAR_RANGES
		logval("actor[slot]", ((int)now.actor[ Index(((int)now.slot), 4) ]));
#endif
		;
		/* merge: .(goto)(111, 46, 111) */
		reached[1][46] = 1;
		;
		/* merge: tool[slot] = Reserved(111, 47, 111) */
		reached[1][47] = 1;
		(trpt+1)->bup.ovals[1] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 4;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 17: // STATE 46 - investigation.pml:86 - [.(goto)] (0:111:1 - 4)
		IfNotBlocked
		reached[1][46] = 1;
		;
		/* merge: tool[slot] = Reserved(111, 47, 111) */
		reached[1][47] = 1;
		(trpt+1)->bup.oval = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 4;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 18: // STATE 42 - investigation.pml:84 - [actor[slot] = 1] (0:111:2 - 1)
		IfNotBlocked
		reached[1][42] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.actor[ Index(((int)now.slot), 4) ]);
		now.actor[ Index(now.slot, 4) ] = 1;
#ifdef VAR_RANGES
		logval("actor[slot]", ((int)now.actor[ Index(((int)now.slot), 4) ]));
#endif
		;
		/* merge: .(goto)(111, 46, 111) */
		reached[1][46] = 1;
		;
		/* merge: tool[slot] = Reserved(111, 47, 111) */
		reached[1][47] = 1;
		(trpt+1)->bup.ovals[1] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 4;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 19: // STATE 43 - investigation.pml:85 - [actor[slot] = 2] (0:111:2 - 1)
		IfNotBlocked
		reached[1][43] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.actor[ Index(((int)now.slot), 4) ]);
		now.actor[ Index(now.slot, 4) ] = 2;
#ifdef VAR_RANGES
		logval("actor[slot]", ((int)now.actor[ Index(((int)now.slot), 4) ]));
#endif
		;
		/* merge: .(goto)(111, 46, 111) */
		reached[1][46] = 1;
		;
		/* merge: tool[slot] = Reserved(111, 47, 111) */
		reached[1][47] = 1;
		(trpt+1)->bup.ovals[1] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 4;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 20: // STATE 44 - investigation.pml:85 - [actor[slot] = 3] (0:111:2 - 1)
		IfNotBlocked
		reached[1][44] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.actor[ Index(((int)now.slot), 4) ]);
		now.actor[ Index(now.slot, 4) ] = 3;
#ifdef VAR_RANGES
		logval("actor[slot]", ((int)now.actor[ Index(((int)now.slot), 4) ]));
#endif
		;
		/* merge: .(goto)(111, 46, 111) */
		reached[1][46] = 1;
		;
		/* merge: tool[slot] = Reserved(111, 47, 111) */
		reached[1][47] = 1;
		(trpt+1)->bup.ovals[1] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 4;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 21: // STATE 49 - investigation.pml:89 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Reserved)))] (111:0:2 - 1)
		IfNotBlocked
		reached[1][49] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==4))))
			continue;
		/* merge: assert(!(cancelled))(111, 50, 111) */
		reached[1][50] = 1;
		spin_assert( !(((int)now.cancelled)), " !(cancelled)", II, tt, t);
		/* merge: calls[slot] = (calls[slot]+1)(111, 51, 111) */
		reached[1][51] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.calls[ Index(((int)now.slot), 4) ]);
		now.calls[ Index(now.slot, 4) ] = (((int)now.calls[ Index(((int)now.slot), 4) ])+1);
#ifdef VAR_RANGES
		logval("calls[slot]", ((int)now.calls[ Index(((int)now.slot), 4) ]));
#endif
		;
		/* merge: assert((calls[slot]<=1))(111, 52, 111) */
		reached[1][52] = 1;
		spin_assert((((int)now.calls[ Index(((int)now.slot), 4) ])<=1), "(calls[slot]<=1)", II, tt, t);
		/* merge: tool[slot] = Invoked(111, 53, 111) */
		reached[1][53] = 1;
		(trpt+1)->bup.ovals[1] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 3;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 22: // STATE 55 - investigation.pml:97 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Invoked)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][55] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==3))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 56 - investigation.pml:99 - [tool[slot] = Recorded] (0:62:4 - 1)
		IfNotBlocked
		reached[1][56] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 2;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: results = (results+1)(62, 57, 62) */
		reached[1][57] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.results);
		now.results = (((int)now.results)+1);
#ifdef VAR_RANGES
		logval("results", ((int)now.results));
#endif
		;
		/* merge: covered = (covered|(1<<actor[slot]))(62, 58, 62) */
		reached[1][58] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.covered);
		now.covered = (((int)now.covered)|(1<<((int)now.actor[ Index(((int)now.slot), 4) ])));
#ifdef VAR_RANGES
		logval("covered", ((int)now.covered));
#endif
		;
		/* merge: order_code = ((order_code*4)+actor[slot])(62, 59, 62) */
		reached[1][59] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.order_code);
		now.order_code = ((((int)now.order_code)*4)+((int)now.actor[ Index(((int)now.slot), 4) ]));
#ifdef VAR_RANGES
		logval("order_code", ((int)now.order_code));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 24: // STATE 61 - investigation.pml:104 - [unavailable_observation = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[1][61] = 1;
		(trpt+1)->bup.oval = ((int)unavailable_observation);
		unavailable_observation = 1;
#ifdef VAR_RANGES
		logval("unavailable_observation", ((int)unavailable_observation));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 64 - investigation.pml:107 - [(1)] (111:0:0 - 1)
		IfNotBlocked
		reached[1][64] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(111, 67, 111) */
		reached[1][67] = 1;
		;
		/* merge: .(goto)(111, 71, 111) */
		reached[1][71] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 26: // STATE 67 - investigation.pml:108 - [.(goto)] (0:111:0 - 2)
		IfNotBlocked
		reached[1][67] = 1;
		;
		/* merge: .(goto)(111, 71, 111) */
		reached[1][71] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 27: // STATE 65 - investigation.pml:107 - [all_trusted = 0] (0:111:1 - 1)
		IfNotBlocked
		reached[1][65] = 1;
		(trpt+1)->bup.oval = ((int)now.all_trusted);
		now.all_trusted = 0;
#ifdef VAR_RANGES
		logval("all_trusted", ((int)now.all_trusted));
#endif
		;
		/* merge: .(goto)(111, 67, 111) */
		reached[1][67] = 1;
		;
		/* merge: .(goto)(111, 71, 111) */
		reached[1][71] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 28: // STATE 71 - investigation.pml:110 - [.(goto)] (0:111:0 - 2)
		IfNotBlocked
		reached[1][71] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 29: // STATE 68 - investigation.pml:108 - [tool[slot] = Uncertain] (0:111:2 - 1)
		IfNotBlocked
		reached[1][68] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.tool[ Index(((int)now.slot), 4) ];
		now.tool[ Index(now.slot, 4) ] = 1;
#ifdef VAR_RANGES
		logval("tool[slot]", now.tool[ Index(((int)now.slot), 4) ]);
#endif
		;
		/* merge: has_unknown = 1(111, 69, 111) */
		reached[1][69] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.has_unknown);
		now.has_unknown = 1;
#ifdef VAR_RANGES
		logval("has_unknown", ((int)now.has_unknown));
#endif
		;
		/* merge: .(goto)(111, 71, 111) */
		reached[1][71] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 30: // STATE 73 - investigation.pml:112 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Recorded)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][73] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==2))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 74 - investigation.pml:114 - [phase = Acquired] (0:111:1 - 1)
		IfNotBlocked
		reached[1][74] = 1;
		(trpt+1)->bup.oval = now.phase;
		now.phase = 11;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: .(goto)(111, 78, 111) */
		reached[1][78] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 32: // STATE 78 - investigation.pml:117 - [.(goto)] (0:111:0 - 2)
		IfNotBlocked
		reached[1][78] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 33: // STATE 75 - investigation.pml:115 - [((slot<(4-1)))] (111:0:1 - 1)
		IfNotBlocked
		reached[1][75] = 1;
		if (!((((int)now.slot)<(4-1))))
			continue;
		/* merge: slot = (slot+1)(111, 76, 111) */
		reached[1][76] = 1;
		(trpt+1)->bup.oval = ((int)now.slot);
		now.slot = (((int)now.slot)+1);
#ifdef VAR_RANGES
		logval("slot", ((int)now.slot));
#endif
		;
		/* merge: .(goto)(111, 78, 111) */
		reached[1][78] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 34: // STATE 80 - investigation.pml:119 - [((((!(done)&&!(cancelled))&&(phase==Acquiring))&&(tool[slot]==Uncertain)))] (111:0:2 - 1)
		IfNotBlocked
		reached[1][80] = 1;
		if (!(((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==12))&&(now.tool[ Index(((int)now.slot), 4) ]==1))))
			continue;
		/* merge: phase = Blocked(111, 81, 111) */
		reached[1][81] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 7;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(111, 82, 111) */
		reached[1][82] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 35: // STATE 84 - investigation.pml:127 - [(((!(done)&&!(cancelled))&&(phase==Acquired)))] (96:0:0 - 1)
		IfNotBlocked
		reached[1][84] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==11))))
			continue;
		/* merge: assert(!(has_unknown))(0, 85, 96) */
		reached[1][85] = 1;
		spin_assert( !(((int)now.has_unknown)), " !(has_unknown)", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 36: // STATE 86 - investigation.pml:138 - [(((all_trusted&&!(has_unknown))&&(covered==15)))] (111:0:2 - 1)
		IfNotBlocked
		reached[1][86] = 1;
		if (!(((((int)now.all_trusted)&& !(((int)now.has_unknown)))&&(((int)now.covered)==15))))
			continue;
		/* merge: assert((covered==15))(111, 87, 111) */
		reached[1][87] = 1;
		spin_assert((((int)now.covered)==15), "(covered==15)", II, tt, t);
		/* merge: assert(all_trusted)(111, 88, 111) */
		reached[1][88] = 1;
		spin_assert(((int)now.all_trusted), "all_trusted", II, tt, t);
		/* merge: assert(!(has_unknown))(111, 89, 111) */
		reached[1][89] = 1;
		spin_assert( !(((int)now.has_unknown)), " !(has_unknown)", II, tt, t);
		/* merge: frozen_version = (frozen_version+1)(111, 90, 111) */
		reached[1][90] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.frozen_version);
		now.frozen_version = (((int)now.frozen_version)+1);
#ifdef VAR_RANGES
		logval("frozen_version", ((int)now.frozen_version));
#endif
		;
		/* merge: assert((frozen_version==1))(111, 91, 111) */
		reached[1][91] = 1;
		spin_assert((((int)now.frozen_version)==1), "(frozen_version==1)", II, tt, t);
		/* merge: phase = Frozen(111, 92, 111) */
		reached[1][92] = 1;
		(trpt+1)->bup.ovals[1] = now.phase;
		now.phase = 10;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: .(goto)(111, 97, 111) */
		reached[1][97] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 37: // STATE 97 - investigation.pml:150 - [.(goto)] (0:111:0 - 2)
		IfNotBlocked
		reached[1][97] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 38: // STATE 94 - investigation.pml:148 - [phase = Blocked] (0:111:2 - 1)
		IfNotBlocked
		reached[1][94] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 7;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(111, 95, 111) */
		reached[1][95] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(111, 97, 111) */
		reached[1][97] = 1;
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 39: // STATE 99 - investigation.pml:161 - [(((!(done)&&!(cancelled))&&(phase==Frozen)))] (111:0:2 - 1)
		IfNotBlocked
		reached[1][99] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==10))))
			continue;
		/* merge: assert(!(cancelled))(111, 100, 111) */
		reached[1][100] = 1;
		spin_assert( !(((int)now.cancelled)), " !(cancelled)", II, tt, t);
		/* merge: assert((((frozen_version==1)&&all_trusted)&&!(has_unknown)))(111, 101, 111) */
		reached[1][101] = 1;
		spin_assert((((((int)now.frozen_version)==1)&&((int)now.all_trusted))&& !(((int)now.has_unknown))), "(((frozen_version==1)&&all_trusted)&& !(has_unknown))", II, tt, t);
		/* merge: assert((covered==15))(111, 102, 111) */
		reached[1][102] = 1;
		spin_assert((((int)now.covered)==15), "(covered==15)", II, tt, t);
		/* merge: assessment_starts = (assessment_starts+1)(111, 103, 111) */
		reached[1][103] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.assessment_starts);
		now.assessment_starts = (((int)now.assessment_starts)+1);
#ifdef VAR_RANGES
		logval("assessment_starts", ((int)now.assessment_starts));
#endif
		;
		/* merge: assert((assessment_starts==1))(111, 104, 111) */
		reached[1][104] = 1;
		spin_assert((((int)now.assessment_starts)==1), "(assessment_starts==1)", II, tt, t);
		/* merge: phase = Assessing(111, 105, 111) */
		reached[1][105] = 1;
		(trpt+1)->bup.ovals[1] = now.phase;
		now.phase = 9;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 40: // STATE 107 - investigation.pml:172 - [(((!(done)&&!(cancelled))&&(phase==Assessing)))] (111:0:2 - 1)
		IfNotBlocked
		reached[1][107] = 1;
		if (!((( !(((int)now.done))&& !(((int)now.cancelled)))&&(now.phase==9))))
			continue;
		/* merge: phase = Completed(111, 108, 111) */
		reached[1][108] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.phase;
		now.phase = 8;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: done = 1(111, 109, 111) */
		reached[1][109] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: .(goto)(0, 112, 111) */
		reached[1][112] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 41: // STATE 114 - investigation.pml:180 - [assert((results<=4))] (0:0:0 - 3)
		IfNotBlocked
		reached[1][114] = 1;
		spin_assert((((int)now.results)<=4), "(results<=4)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 42: // STATE 115 - investigation.pml:181 - [assert((frozen_version<=1))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][115] = 1;
		spin_assert((((int)now.frozen_version)<=1), "(frozen_version<=1)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 43: // STATE 116 - investigation.pml:192 - [assert(!(((((phase==Blocked)&&all_trusted)&&!(has_unknown))&&(results==1))))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][116] = 1;
		spin_assert( !(((((now.phase==7)&&((int)now.all_trusted))&& !(((int)now.has_unknown)))&&(((int)now.results)==1))), " !(((((phase==7)&&all_trusted)&& !(has_unknown))&&(results==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 44: // STATE 117 - investigation.pml:203 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[1][117] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Cancellation */
	case 45: // STATE 1 - investigation.pml:44 - [cancelled = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)now.cancelled);
		now.cancelled = 1;
#ifdef VAR_RANGES
		logval("cancelled", ((int)now.cancelled));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 46: // STATE 5 - investigation.pml:45 - [-end-] (0:0:0 - 3)
		IfNotBlocked
		reached[0][5] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

