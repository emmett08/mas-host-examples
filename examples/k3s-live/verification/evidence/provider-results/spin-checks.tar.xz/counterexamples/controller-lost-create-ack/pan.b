	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM controller_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 5: // STATE 16
		;
		now.source_uid[0] = trpt->bup.ovals[1];
		((P3 *)_this)->rejection_class = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 6: // STATE 16
		;
		now.source_uid[0] = trpt->bup.ovals[2];
		now.controller_enabled = trpt->bup.ovals[1];
		((P3 *)_this)->rejection_class = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 7: // STATE 16
		;
		now.source_uid[0] = trpt->bup.ovals[2];
		now.source_bound = trpt->bup.ovals[1];
		((P3 *)_this)->rejection_class = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 8: // STATE 16
		;
		now.source_uid[0] = trpt->bup.ovals[2];
		now.evidence_fresh = trpt->bup.ovals[1];
		((P3 *)_this)->rejection_class = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 9: // STATE 16
		;
		now.source_uid[0] = trpt->bup.ovals[2];
		now.evidence_valid = trpt->bup.ovals[1];
		((P3 *)_this)->rejection_class = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 10: // STATE 16
		;
		now.source_uid[0] = trpt->bup.ovals[2];
		now.policy_allowed = trpt->bup.ovals[1];
		((P3 *)_this)->rejection_class = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 11: // STATE 16
		;
		now.source_uid[0] = trpt->bup.ovals[2];
		now.target_identity_matches = trpt->bup.ovals[1];
		((P3 *)_this)->rejection_class = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 12: // STATE 16
		;
		now.source_uid[0] = trpt->bup.oval;
		;
		goto R999;

	case 13: // STATE 17
		;
		now.source_uid[1] = trpt->bup.oval;
		;
		goto R999;

	case 14: // STATE 18
		;
		now.source_uid[1] = trpt->bup.oval;
		;
		goto R999;

	case 15: // STATE 21
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 16: // STATE 22
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 17: // STATE 23
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 18: // STATE 24
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		
	case 23: // STATE 30
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Outbox */
;
		;
		;
		;
		
	case 26: // STATE 9
		;
		((P2 *)_this)->attempt = trpt->bup.oval;
		;
		goto R999;

	case 27: // STATE 10
		;
		((P2 *)_this)->authenticated = trpt->bup.oval;
		;
		goto R999;

	case 28: // STATE 11
		;
		((P2 *)_this)->authenticated = trpt->bup.oval;
		;
		goto R999;

	case 29: // STATE 15
		;
		((P2 *)_this)->response_ack = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 30: // STATE 16
		;
		((P2 *)_this)->response_ack = trpt->bup.oval;
		;
		goto R999;

	case 31: // STATE 20
		;
	/* 0 */	((P2 *)_this)->authenticated = trpt->bup.oval;
		;
		;
		goto R999;
;
		
	case 32: // STATE 21
		goto R999;

	case 33: // STATE 30
		;
		now.publications = trpt->bup.ovals[2];
		now.first_published_source = trpt->bup.ovals[1];
		now.first_published_report = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 3);
		goto R999;

	case 34: // STATE 30
		;
		now.publications = trpt->bup.oval;
		;
		goto R999;

	case 35: // STATE 30
		;
		now.publications = trpt->bup.oval;
		;
		goto R999;
;
		
	case 36: // STATE 31
		goto R999;
;
		
	case 37: // STATE 37
		goto R999;
;
		
	case 38: // STATE 35
		goto R999;

	case 39: // STATE 39
		;
	/* 0 */	((P2 *)_this)->authenticated = trpt->bup.oval;
		;
		;
		goto R999;

	case 40: // STATE 43
		;
	/* 0 */	((P2 *)_this)->attempt = trpt->bup.oval;
		;
		;
		goto R999;

	case 41: // STATE 48
		;
		now.publisher_done = trpt->bup.oval;
		;
		goto R999;

	case 42: // STATE 49
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Expiry */
;
		;
		
	case 44: // STATE 3
		;
		now.expired = trpt->bup.oval;
		;
		goto R999;

	case 45: // STATE 8
		;
		now.resource_version = trpt->bup.ovals[3];
		now.phase = trpt->bup.ovals[2];
		now.first_report = trpt->bup.ovals[1];
		now.durable_report = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;
;
		
	case 46: // STATE 13
		goto R999;
;
		
	case 47: // STATE 11
		goto R999;
;
		;
		;
		;
		
	case 50: // STATE 23
		;
		now.expiry_done = trpt->bup.oval;
		;
		goto R999;

	case 51: // STATE 24
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Worker */
;
		;
		;
		;
		
	case 54: // STATE 8
		;
		((P0 *)_this)->seen_version = trpt->bup.ovals[1];
		((P0 *)_this)->seen_phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 55: // STATE 10
		;
	/* 0 */	((P0 *)_this)->seen_phase = trpt->bup.oval;
		;
		;
		goto R999;

	case 56: // STATE 15
		;
		((P0 *)_this)->create_ok = trpt->bup.ovals[4];
		now.resource_version = trpt->bup.ovals[3];
		now.journal_source = trpt->bup.ovals[2];
		now.phase = trpt->bup.ovals[1];
	/* 0 */	((P0 *)_this)->seen_version = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 5);
		goto R999;
;
		
	case 57: // STATE 19
		goto R999;

	case 58: // STATE 17
		;
		((P0 *)_this)->create_ok = trpt->bup.oval;
		;
		goto R999;

	case 59: // STATE 21
		;
	/* 0 */	((P0 *)_this)->create_ok = trpt->bup.oval;
		;
		;
		goto R999;

	case 60: // STATE 23
		;
	/* 0 */	((P0 *)_this)->create_ok = trpt->bup.oval;
		;
		;
		goto R999;

	case 61: // STATE 24
		;
		((P0 *)_this)->create_ack = trpt->bup.oval;
		;
		goto R999;

	case 62: // STATE 25
		;
		((P0 *)_this)->create_ack = trpt->bup.oval;
		;
		goto R999;

	case 63: // STATE 29
		;
		now.lost_create_ack[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.oval;
		;
		goto R999;

	case 64: // STATE 32
		;
		((P0 *)_this)->seen_version = trpt->bup.ovals[1];
		((P0 *)_this)->seen_phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 66: // STATE 42
		;
	/* 0 */	((P0 *)_this)->id = trpt->bup.oval;
		;
		;
		goto R999;
;
		;
		
	case 68: // STATE 48
		;
	/* 0 */	((P0 *)_this)->seen_phase = trpt->bup.oval;
		;
		;
		goto R999;

	case 69: // STATE 52
		;
		now.resource_version = trpt->bup.ovals[3];
		now.owner = trpt->bup.ovals[2];
		now.phase = trpt->bup.ovals[1];
	/* 0 */	((P0 *)_this)->seen_version = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 70: // STATE 58
		;
		((P0 *)_this)->reserved = trpt->bup.ovals[1];
		now.original_claim_ack[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 71: // STATE 58
		;
		((P0 *)_this)->reserved = trpt->bup.ovals[1];
		now.original_claim_ack[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 72: // STATE 58
		;
		((P0 *)_this)->reserved = trpt->bup.oval;
		;
		goto R999;
;
		
	case 73: // STATE 62
		goto R999;

	case 74: // STATE 60
		;
		((P0 *)_this)->reserved = trpt->bup.oval;
		;
		goto R999;

	case 75: // STATE 65
		;
		((P0 *)_this)->reserved = trpt->bup.ovals[1];
	/* 0 */	((P0 *)_this)->seen_phase = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 76: // STATE 67
		;
		((P0 *)_this)->reserved = trpt->bup.oval;
		;
		goto R999;

	case 77: // STATE 70
		;
	/* 0 */	((P0 *)_this)->reserved = trpt->bup.oval;
		;
		;
		goto R999;

	case 78: // STATE 72
		;
	/* 0 */	((P0 *)_this)->reserved = trpt->bup.oval;
		;
		;
		goto R999;

	case 79: // STATE 76
		;
		((P0 *)_this)->fresh_after_claim = trpt->bup.oval;
		;
		goto R999;

	case 80: // STATE 77
		;
		((P0 *)_this)->fresh_after_claim = trpt->bup.oval;
		;
		goto R999;

	case 81: // STATE 81
		;
	/* 0 */	((P0 *)_this)->fresh_after_claim = trpt->bup.oval;
		;
		;
		goto R999;
;
		;
		
	case 83: // STATE 87
		;
		((P0 *)_this)->crashed = trpt->bup.oval;
		;
		goto R999;

	case 84: // STATE 88
		;
		((P0 *)_this)->crashed = trpt->bup.oval;
		;
		goto R999;

	case 85: // STATE 92
		;
	/* 0 */	((P0 *)_this)->crashed = trpt->bup.oval;
		;
		;
		goto R999;

	case 86: // STATE 94
		;
	/* 0 */	((P0 *)_this)->crashed = trpt->bup.oval;
		;
		;
		goto R999;

	case 87: // STATE 98
		;
		((P0 *)_this)->api_accepts = trpt->bup.oval;
		;
		goto R999;

	case 88: // STATE 99
		;
		((P0 *)_this)->api_accepts = trpt->bup.oval;
		;
		goto R999;

	case 89: // STATE 103
		;
		((P0 *)_this)->patch_tests = trpt->bup.oval;
		;
		goto R999;

	case 90: // STATE 104
		;
		((P0 *)_this)->patch_tests = trpt->bup.oval;
		;
		goto R999;
;
		
	case 91: // STATE 108
		goto R999;

	case 92: // STATE 116
		;
		now.effect_by[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.ovals[3];
		now.effects = trpt->bup.ovals[2];
	/* 1 */	((P0 *)_this)->patch_tests = trpt->bup.ovals[1];
	/* 0 */	((P0 *)_this)->api_accepts = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;
;
		
	case 93: // STATE 121
		goto R999;

	case 94: // STATE 118
		;
	/* 1 */	((P0 *)_this)->patch_tests = trpt->bup.ovals[1];
	/* 0 */	((P0 *)_this)->api_accepts = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 95: // STATE 119
		goto R999;

	case 96: // STATE 123
		;
		((P0 *)_this)->crashed = trpt->bup.oval;
		;
		goto R999;

	case 97: // STATE 124
		;
		((P0 *)_this)->crashed = trpt->bup.oval;
		;
		goto R999;

	case 98: // STATE 128
		;
	/* 0 */	((P0 *)_this)->crashed = trpt->bup.oval;
		;
		;
		goto R999;

	case 99: // STATE 130
		;
	/* 0 */	((P0 *)_this)->crashed = trpt->bup.oval;
		;
		;
		goto R999;

	case 100: // STATE 134
		;
		((P0 *)_this)->patch_response = trpt->bup.oval;
		;
		goto R999;

	case 101: // STATE 135
		;
		((P0 *)_this)->patch_response = trpt->bup.oval;
		;
		goto R999;

	case 102: // STATE 139
		;
		now.patch_ack[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.oval;
		;
		goto R999;

	case 103: // STATE 140
		;
		((P0 *)_this)->crashed = trpt->bup.oval;
		;
		goto R999;

	case 104: // STATE 141
		;
		((P0 *)_this)->crashed = trpt->bup.oval;
		;
		goto R999;

	case 105: // STATE 145
		;
	/* 0 */	((P0 *)_this)->crashed = trpt->bup.oval;
		;
		;
		goto R999;

	case 106: // STATE 147
		;
	/* 0 */	((P0 *)_this)->crashed = trpt->bup.oval;
		;
		;
		goto R999;

	case 107: // STATE 151
		;
		((P0 *)_this)->all_recovery = trpt->bup.oval;
		;
		goto R999;

	case 108: // STATE 152
		;
		((P0 *)_this)->all_recovery = trpt->bup.oval;
		;
		goto R999;

	case 109: // STATE 156
		;
		now.recovery_complete[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.oval;
		;
		goto R999;

	case 110: // STATE 157
		;
		((P0 *)_this)->crashed = trpt->bup.oval;
		;
		goto R999;

	case 111: // STATE 158
		;
		((P0 *)_this)->crashed = trpt->bup.oval;
		;
		goto R999;

	case 112: // STATE 162
		;
	/* 0 */	((P0 *)_this)->crashed = trpt->bup.oval;
		;
		;
		goto R999;

	case 113: // STATE 164
		;
	/* 0 */	((P0 *)_this)->crashed = trpt->bup.oval;
		;
		;
		goto R999;
;
		;
		;
		;
		
	case 116: // STATE 174
		;
		now.resource_version = trpt->bup.ovals[3];
		now.phase = trpt->bup.ovals[2];
		now.first_report = trpt->bup.ovals[1];
		now.durable_report = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;
;
		;
		
	case 118: // STATE 181
		;
		now.resource_version = trpt->bup.ovals[3];
		now.phase = trpt->bup.ovals[2];
		now.first_report = trpt->bup.ovals[1];
		now.durable_report = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;
;
		
	case 119: // STATE 185
		goto R999;

	case 120: // STATE 186
		;
		((P0 *)_this)->finish_ack = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 121: // STATE 189
		goto R999;

	case 122: // STATE 187
		;
		((P0 *)_this)->finish_ack = trpt->bup.oval;
		;
		goto R999;
;
		
	case 123: // STATE 194
		goto R999;
;
		
	case 124: // STATE 192
		goto R999;

	case 125: // STATE 196
		;
		now.workers_done = trpt->bup.oval;
		;
		goto R999;

	case 126: // STATE 198
		;
		p_restor(II);
		;
		;
		goto R999;
	}

