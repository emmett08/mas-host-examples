	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM dual_repair_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC :init: */

	case 5: // STATE 1
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;

	case 6: // STATE 2
		;
		;
		delproc(0, now._nr_pr-1);
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		
	case 11: // STATE 8
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Incident */

	case 12: // STATE 1
		;
		now.phase[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.oval;
		;
		goto R999;

	case 13: // STATE 3
		;
		((P0 *)_this)->snapshot_run = trpt->bup.oval;
		;
		goto R999;

	case 14: // STATE 4
		;
		((P0 *)_this)->snapshot_event = trpt->bup.oval;
		;
		goto R999;

	case 15: // STATE 5
		;
		((P0 *)_this)->snapshot_seed = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 6
		;
		((P0 *)_this)->evidence_subject = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 7
		;
		((P0 *)_this)->snapshot_approach = trpt->bup.oval;
		;
		goto R999;

	case 18: // STATE 9
		;
		((P0 *)_this)->frozen_trusted = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 11
		;
		((P0 *)_this)->proposal_target = trpt->bup.ovals[1];
		((P0 *)_this)->evidence_target = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 20: // STATE 12
		;
		((P0 *)_this)->proposal_target = trpt->bup.oval;
		;
		goto R999;

	case 21: // STATE 15
		;
		now.phase[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.oval;
		;
		goto R999;

	case 22: // STATE 16
		;
	/* 9 */	((P0 *)_this)->proposal_target = trpt->bup.ovals[9];
	/* 8 */	((P0 *)_this)->evidence_target = trpt->bup.ovals[8];
	/* 7 */	((P0 *)_this)->frozen_trusted = trpt->bup.ovals[7];
	/* 6 */	((P0 *)_this)->evidence_subject = trpt->bup.ovals[6];
	/* 5 */	((P0 *)_this)->source_seed = trpt->bup.ovals[5];
	/* 4 */	((P0 *)_this)->snapshot_seed = trpt->bup.ovals[4];
	/* 3 */	((P0 *)_this)->source_event = trpt->bup.ovals[3];
	/* 2 */	((P0 *)_this)->snapshot_event = trpt->bup.ovals[2];
	/* 1 */	((P0 *)_this)->source_run = trpt->bup.ovals[1];
	/* 0 */	((P0 *)_this)->snapshot_run = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 10);
		goto R999;

	case 23: // STATE 17
		;
		now.phase[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 24: // STATE 18
		goto R999;

	case 25: // STATE 27
		;
		now.phase[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.ovals[1];
		now.journal_source[ Index(((P0 *)_this)->journal_key, 2) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 26: // STATE 29
		;
		((P0 *)_this)->patch_acknowledged = trpt->bup.oval;
		;
		goto R999;

	case 27: // STATE 30
		;
		((P0 *)_this)->patch_acknowledged = trpt->bup.oval;
		;
		goto R999;

	case 28: // STATE 34
		;
		now.phase[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.ovals[1];
		now.effects[ Index((((P0 *)_this)->evidence_target-1), 2) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 29: // STATE 38
		;
		((P0 *)_this)->recovery_complete = trpt->bup.oval;
		;
		goto R999;

	case 30: // STATE 39
		;
		((P0 *)_this)->recovery_complete = trpt->bup.oval;
		;
		goto R999;

	case 31: // STATE 42
		;
	/* 1 */	((P0 *)_this)->recovery_complete = trpt->bup.ovals[1];
	/* 0 */	((P0 *)_this)->patch_acknowledged = trpt->bup.ovals[0];
		;
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 32: // STATE 43
		;
		now.phase[ Index(((P0 *)_this)->id, 2) ] = trpt->bup.oval;
		;
		goto R999;

	case 33: // STATE 50
		;
		now.finished = trpt->bup.oval;
		;
		goto R999;

	case 34: // STATE 52
		;
		p_restor(II);
		;
		;
		goto R999;
	}

