#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM dual_repair_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!((finished==2)))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[2][1] = 1;
		if (!( !((((int)now.finished)==2))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[2][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - dual-repair.pml:127 - [(run Incident(0))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][1] = 1;
		if (!(addproc(II, 1, 0, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - dual-repair.pml:127 - [(run Incident(1))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!(addproc(II, 1, 0, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 4 - dual-repair.pml:128 - [((finished==2))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][4] = 1;
		if (!((((int)now.finished)==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 5 - dual-repair.pml:129 - [assert(((effects[0]<=1)&&(effects[1]<=1)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][5] = 1;
		spin_assert(((((int)now.effects[0])<=1)&&(((int)now.effects[1])<=1)), "((effects[0]<=1)&&(effects[1]<=1))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 6 - dual-repair.pml:130 - [assert(((phase[0]!=Verified)||((effects[0]==1)&&(journal_source[0]==1))))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][6] = 1;
		spin_assert(((now.phase[0]!=1)||((((int)now.effects[0])==1)&&(((int)now.journal_source[0])==1))), "((phase[0]!=1)||((effects[0]==1)&&(journal_source[0]==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 10: // STATE 7 - dual-repair.pml:131 - [assert(((phase[1]!=Verified)||((effects[1]==1)&&(journal_source[1]==2))))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][7] = 1;
		spin_assert(((now.phase[1]!=1)||((((int)now.effects[1])==1)&&(((int)now.journal_source[1])==2))), "((phase[1]!=1)||((effects[1]==1)&&(journal_source[1]==2)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 8 - dual-repair.pml:135 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[1][8] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Incident */
	case 12: // STATE 1 - dual-repair.pml:63 - [phase[id] = Detected] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = now.phase[ Index(((int)((P0 *)_this)->id), 2) ];
		now.phase[ Index(((P0 *)_this)->id, 2) ] = 6;
#ifdef VAR_RANGES
		logval("phase[Incident:id]", now.phase[ Index(((int)((P0 *)_this)->id), 2) ]);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 3 - dual-repair.pml:72 - [snapshot_run = (3-source_run)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->snapshot_run);
		((P0 *)_this)->snapshot_run = (3-((int)((P0 *)_this)->source_run));
#ifdef VAR_RANGES
		logval("Incident:snapshot_run", ((int)((P0 *)_this)->snapshot_run));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 4 - dual-repair.pml:73 - [snapshot_event = (3-source_event)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][4] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->snapshot_event);
		((P0 *)_this)->snapshot_event = (3-((int)((P0 *)_this)->source_event));
#ifdef VAR_RANGES
		logval("Incident:snapshot_event", ((int)((P0 *)_this)->snapshot_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 15: // STATE 5 - dual-repair.pml:74 - [snapshot_seed = (3-source_seed)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][5] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->snapshot_seed);
		((P0 *)_this)->snapshot_seed = (3-((int)((P0 *)_this)->source_seed));
#ifdef VAR_RANGES
		logval("Incident:snapshot_seed", ((int)((P0 *)_this)->snapshot_seed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 6 - dual-repair.pml:75 - [evidence_subject = (3-source_seed)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][6] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->evidence_subject);
		((P0 *)_this)->evidence_subject = (3-((int)((P0 *)_this)->source_seed));
#ifdef VAR_RANGES
		logval("Incident:evidence_subject", ((int)((P0 *)_this)->evidence_subject));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 7 - dual-repair.pml:76 - [snapshot_approach = (1-id)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][7] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->snapshot_approach);
		((P0 *)_this)->snapshot_approach = (1-((int)((P0 *)_this)->id));
#ifdef VAR_RANGES
		logval("Incident:snapshot_approach", ((int)((P0 *)_this)->snapshot_approach));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 8 - dual-repair.pml:77 - [((id==1))] (15:0:1 - 1)
		IfNotBlocked
		reached[0][8] = 1;
		if (!((((int)((P0 *)_this)->id)==1)))
			continue;
		/* merge: frozen_trusted = 0(0, 9, 15) */
		reached[0][9] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->frozen_trusted);
		((P0 *)_this)->frozen_trusted = 0;
#ifdef VAR_RANGES
		logval("Incident:frozen_trusted", ((int)((P0 *)_this)->frozen_trusted));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 19: // STATE 10 - dual-repair.pml:78 - [evidence_target = (3-source_run)] (0:15:2 - 1)
		IfNotBlocked
		reached[0][10] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P0 *)_this)->evidence_target);
		((P0 *)_this)->evidence_target = (3-((int)((P0 *)_this)->source_run));
#ifdef VAR_RANGES
		logval("Incident:evidence_target", ((int)((P0 *)_this)->evidence_target));
#endif
		;
		/* merge: proposal_target = evidence_target(15, 11, 15) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->proposal_target);
		((P0 *)_this)->proposal_target = ((int)((P0 *)_this)->evidence_target);
#ifdef VAR_RANGES
		logval("Incident:proposal_target", ((int)((P0 *)_this)->proposal_target));
#endif
		;
		/* merge: .(goto)(0, 14, 15) */
		reached[0][14] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 20: // STATE 12 - dual-repair.pml:79 - [proposal_target = (3-source_run)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][12] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->proposal_target);
		((P0 *)_this)->proposal_target = (3-((int)((P0 *)_this)->source_run));
#ifdef VAR_RANGES
		logval("Incident:proposal_target", ((int)((P0 *)_this)->proposal_target));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 15 - dual-repair.pml:83 - [phase[id] = Assessed] (0:0:1 - 10)
		IfNotBlocked
		reached[0][15] = 1;
		(trpt+1)->bup.oval = now.phase[ Index(((int)((P0 *)_this)->id), 2) ];
		now.phase[ Index(((P0 *)_this)->id, 2) ] = 5;
#ifdef VAR_RANGES
		logval("phase[Incident:id]", now.phase[ Index(((int)((P0 *)_this)->id), 2) ]);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 16 - dual-repair.pml:85 - [(!(((((((snapshot_run==source_run)&&(snapshot_event==source_event))&&((snapshot_seed==source_seed)&&(evidence_subject==source_seed)))&&1)&&((id==0)||frozen_trusted))&&((evidence_target==source_run)&&(proposal_target==evidence_target)))))] (0:0:10 - 1)
		IfNotBlocked
		reached[0][16] = 1;
		if (!( !(((((((((int)((P0 *)_this)->snapshot_run)==((int)((P0 *)_this)->source_run))&&(((int)((P0 *)_this)->snapshot_event)==((int)((P0 *)_this)->source_event)))&&((((int)((P0 *)_this)->snapshot_seed)==((int)((P0 *)_this)->source_seed))&&(((int)((P0 *)_this)->evidence_subject)==((int)((P0 *)_this)->source_seed))))&&1)&&((((int)((P0 *)_this)->id)==0)||((int)((P0 *)_this)->frozen_trusted)))&&((((int)((P0 *)_this)->evidence_target)==((int)((P0 *)_this)->source_run))&&(((int)((P0 *)_this)->proposal_target)==((int)((P0 *)_this)->evidence_target)))))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: snapshot_run */  (trpt+1)->bup.ovals = grab_ints(10);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->snapshot_run;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->snapshot_run = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: source_run */  (trpt+1)->bup.ovals[1] = ((P0 *)_this)->source_run;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->source_run = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: snapshot_event */  (trpt+1)->bup.ovals[2] = ((P0 *)_this)->snapshot_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->snapshot_event = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: source_event */  (trpt+1)->bup.ovals[3] = ((P0 *)_this)->source_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->source_event = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: snapshot_seed */  (trpt+1)->bup.ovals[4] = ((P0 *)_this)->snapshot_seed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->snapshot_seed = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: source_seed */  (trpt+1)->bup.ovals[5] = ((P0 *)_this)->source_seed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->source_seed = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: evidence_subject */  (trpt+1)->bup.ovals[6] = ((P0 *)_this)->evidence_subject;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->evidence_subject = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: frozen_trusted */  (trpt+1)->bup.ovals[7] = ((P0 *)_this)->frozen_trusted;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->frozen_trusted = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: evidence_target */  (trpt+1)->bup.ovals[8] = ((P0 *)_this)->evidence_target;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->evidence_target = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: proposal_target */  (trpt+1)->bup.ovals[9] = ((P0 *)_this)->proposal_target;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->proposal_target = 0;
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 17 - dual-repair.pml:85 - [phase[id] = Rejected] (0:0:1 - 1)
		IfNotBlocked
		reached[0][17] = 1;
		(trpt+1)->bup.oval = now.phase[ Index(((int)((P0 *)_this)->id), 2) ];
		now.phase[ Index(((P0 *)_this)->id, 2) ] = 4;
#ifdef VAR_RANGES
		logval("phase[Incident:id]", now.phase[ Index(((int)((P0 *)_this)->id), 2) ]);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 18 - dual-repair.pml:86 - [(((((((snapshot_run==source_run)&&(snapshot_event==source_event))&&((snapshot_seed==source_seed)&&(evidence_subject==source_seed)))&&1)&&((id==0)||frozen_trusted))&&((evidence_target==source_run)&&(proposal_target==evidence_target))))] (28:0:0 - 1)
		IfNotBlocked
		reached[0][18] = 1;
		if (!(((((((((int)((P0 *)_this)->snapshot_run)==((int)((P0 *)_this)->source_run))&&(((int)((P0 *)_this)->snapshot_event)==((int)((P0 *)_this)->source_event)))&&((((int)((P0 *)_this)->snapshot_seed)==((int)((P0 *)_this)->source_seed))&&(((int)((P0 *)_this)->evidence_subject)==((int)((P0 *)_this)->source_seed))))&&1)&&((((int)((P0 *)_this)->id)==0)||((int)((P0 *)_this)->frozen_trusted)))&&((((int)((P0 *)_this)->evidence_target)==((int)((P0 *)_this)->source_run))&&(((int)((P0 *)_this)->proposal_target)==((int)((P0 *)_this)->evidence_target))))))
			continue;
		/* merge: assert(((snapshot_run==source_run)&&(snapshot_event==source_event)))(28, 19, 28) */
		reached[0][19] = 1;
		spin_assert(((((int)((P0 *)_this)->snapshot_run)==((int)((P0 *)_this)->source_run))&&(((int)((P0 *)_this)->snapshot_event)==((int)((P0 *)_this)->source_event))), "((snapshot_run==source_run)&&(snapshot_event==source_event))", II, tt, t);
		/* merge: assert(((snapshot_seed==source_seed)&&(evidence_subject==source_seed)))(28, 20, 28) */
		reached[0][20] = 1;
		spin_assert(((((int)((P0 *)_this)->snapshot_seed)==((int)((P0 *)_this)->source_seed))&&(((int)((P0 *)_this)->evidence_subject)==((int)((P0 *)_this)->source_seed))), "((snapshot_seed==source_seed)&&(evidence_subject==source_seed))", II, tt, t);
		/* merge: assert((snapshot_approach==id))(28, 21, 28) */
		reached[0][21] = 1;
		spin_assert((((int)((P0 *)_this)->snapshot_approach)==((int)((P0 *)_this)->id)), "(snapshot_approach==id)", II, tt, t);
		/* merge: assert(((id==0)||frozen_trusted))(28, 22, 28) */
		reached[0][22] = 1;
		spin_assert(((((int)((P0 *)_this)->id)==0)||((int)((P0 *)_this)->frozen_trusted)), "((id==0)||frozen_trusted)", II, tt, t);
		/* merge: assert(((evidence_target==source_run)&&(proposal_target==evidence_target)))(28, 23, 28) */
		reached[0][23] = 1;
		spin_assert(((((int)((P0 *)_this)->evidence_target)==((int)((P0 *)_this)->source_run))&&(((int)((P0 *)_this)->proposal_target)==((int)((P0 *)_this)->evidence_target))), "((evidence_target==source_run)&&(proposal_target==evidence_target))", II, tt, t);
		/* merge: assert((journal_key==(evidence_target-1)))(28, 24, 28) */
		reached[0][24] = 1;
		spin_assert((((int)((P0 *)_this)->journal_key)==(((int)((P0 *)_this)->evidence_target)-1)), "(journal_key==(evidence_target-1))", II, tt, t);
		_m = 3; goto P999; /* 6 */
	case 25: // STATE 25 - dual-repair.pml:101 - [assert((journal_source[journal_key]==0))] (0:36:2 - 1)
		IfNotBlocked
		reached[0][25] = 1;
		spin_assert((((int)now.journal_source[ Index(((int)((P0 *)_this)->journal_key), 2) ])==0), "(journal_source[journal_key]==0)", II, tt, t);
		/* merge: journal_source[journal_key] = source_run(36, 26, 36) */
		reached[0][26] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.journal_source[ Index(((int)((P0 *)_this)->journal_key), 2) ]);
		now.journal_source[ Index(((P0 *)_this)->journal_key, 2) ] = ((int)((P0 *)_this)->source_run);
#ifdef VAR_RANGES
		logval("journal_source[Incident:journal_key]", ((int)now.journal_source[ Index(((int)((P0 *)_this)->journal_key), 2) ]));
#endif
		;
		/* merge: phase[id] = Reserved(36, 27, 36) */
		reached[0][27] = 1;
		(trpt+1)->bup.ovals[1] = now.phase[ Index(((int)((P0 *)_this)->id), 2) ];
		now.phase[ Index(((P0 *)_this)->id, 2) ] = 3;
#ifdef VAR_RANGES
		logval("phase[Incident:id]", now.phase[ Index(((int)((P0 *)_this)->id), 2) ]);
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 26: // STATE 29 - dual-repair.pml:106 - [patch_acknowledged = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][29] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->patch_acknowledged);
		((P0 *)_this)->patch_acknowledged = 0;
#ifdef VAR_RANGES
		logval("Incident:patch_acknowledged", ((int)((P0 *)_this)->patch_acknowledged));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 27: // STATE 30 - dual-repair.pml:107 - [patch_acknowledged = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][30] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->patch_acknowledged);
		((P0 *)_this)->patch_acknowledged = 1;
#ifdef VAR_RANGES
		logval("Incident:patch_acknowledged", ((int)((P0 *)_this)->patch_acknowledged));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 28: // STATE 31 - dual-repair.pml:111 - [assert((journal_source[journal_key]==source_run))] (0:40:2 - 1)
		IfNotBlocked
		reached[0][31] = 1;
		spin_assert((((int)now.journal_source[ Index(((int)((P0 *)_this)->journal_key), 2) ])==((int)((P0 *)_this)->source_run)), "(journal_source[journal_key]==source_run)", II, tt, t);
		/* merge: effects[(evidence_target-1)] = (effects[(evidence_target-1)]+1)(40, 32, 40) */
		reached[0][32] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.effects[ Index((((int)((P0 *)_this)->evidence_target)-1), 2) ]);
		now.effects[ Index((((P0 *)_this)->evidence_target-1), 2) ] = (((int)now.effects[ Index((((int)((P0 *)_this)->evidence_target)-1), 2) ])+1);
#ifdef VAR_RANGES
		logval("effects[(Incident:evidence_target-1)]", ((int)now.effects[ Index((((int)((P0 *)_this)->evidence_target)-1), 2) ]));
#endif
		;
		/* merge: assert((effects[(evidence_target-1)]<=1))(40, 33, 40) */
		reached[0][33] = 1;
		spin_assert((((int)now.effects[ Index((((int)((P0 *)_this)->evidence_target)-1), 2) ])<=1), "(effects[(evidence_target-1)]<=1)", II, tt, t);
		/* merge: phase[id] = Applied(40, 34, 40) */
		reached[0][34] = 1;
		(trpt+1)->bup.ovals[1] = now.phase[ Index(((int)((P0 *)_this)->id), 2) ];
		now.phase[ Index(((P0 *)_this)->id, 2) ] = 2;
#ifdef VAR_RANGES
		logval("phase[Incident:id]", now.phase[ Index(((int)((P0 *)_this)->id), 2) ]);
#endif
		;
		/* merge: .(goto)(0, 37, 40) */
		reached[0][37] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 29: // STATE 38 - dual-repair.pml:117 - [recovery_complete = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][38] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->recovery_complete);
		((P0 *)_this)->recovery_complete = 0;
#ifdef VAR_RANGES
		logval("Incident:recovery_complete", ((int)((P0 *)_this)->recovery_complete));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 30: // STATE 39 - dual-repair.pml:117 - [recovery_complete = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][39] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->recovery_complete);
		((P0 *)_this)->recovery_complete = 1;
#ifdef VAR_RANGES
		logval("Incident:recovery_complete", ((int)((P0 *)_this)->recovery_complete));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 42 - dual-repair.pml:119 - [((patch_acknowledged&&recovery_complete))] (0:0:2 - 1)
		IfNotBlocked
		reached[0][42] = 1;
		if (!((((int)((P0 *)_this)->patch_acknowledged)&&((int)((P0 *)_this)->recovery_complete))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: patch_acknowledged */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->patch_acknowledged;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->patch_acknowledged = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: recovery_complete */  (trpt+1)->bup.ovals[1] = ((P0 *)_this)->recovery_complete;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->recovery_complete = 0;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 43 - dual-repair.pml:119 - [phase[id] = Verified] (0:0:1 - 1)
		IfNotBlocked
		reached[0][43] = 1;
		(trpt+1)->bup.oval = now.phase[ Index(((int)((P0 *)_this)->id), 2) ];
		now.phase[ Index(((P0 *)_this)->id, 2) ] = 1;
#ifdef VAR_RANGES
		logval("phase[Incident:id]", now.phase[ Index(((int)((P0 *)_this)->id), 2) ]);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 50 - dual-repair.pml:123 - [finished = (finished+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][50] = 1;
		(trpt+1)->bup.oval = ((int)now.finished);
		now.finished = (((int)now.finished)+1);
#ifdef VAR_RANGES
		logval("finished", ((int)now.finished));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 34: // STATE 52 - dual-repair.pml:124 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][52] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

