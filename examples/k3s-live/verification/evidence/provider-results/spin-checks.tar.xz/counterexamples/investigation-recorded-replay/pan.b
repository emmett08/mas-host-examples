	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM investigation_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Investigation */

	case 5: // STATE 1
		;
		((P1 *)_this)->i = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 4
		;
		((P1 *)_this)->i = trpt->bup.ovals[1];
		now.tool[ Index(((P1 *)_this)->i, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 8: // STATE 15
		;
		now.done = trpt->bup.ovals[1];
		now.phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 9: // STATE 18
		;
		now.restarts = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 20
		;
		recorded_restart = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 26
		;
		frozen_restart = trpt->bup.oval;
		;
		goto R999;

	case 12: // STATE 33
		;
		now.has_unknown = trpt->bup.ovals[1];
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 13: // STATE 39
		;
		now.tool[ Index(now.slot, 4) ] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 14: // STATE 43
		goto R999;
;
		
	case 15: // STATE 41
		goto R999;
;
		;
		
	case 17: // STATE 53
		;
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[1];
		now.actor[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 18: // STATE 53
		;
		now.tool[ Index(now.slot, 4) ] = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 53
		;
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[1];
		now.actor[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 20: // STATE 53
		;
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[1];
		now.actor[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 21: // STATE 53
		;
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[1];
		now.actor[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 22: // STATE 59
		;
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[1];
		now.calls[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 24: // STATE 65
		;
		now.order_code = trpt->bup.ovals[3];
		now.covered = trpt->bup.ovals[2];
		now.results = trpt->bup.ovals[1];
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 4);
		goto R999;

	case 25: // STATE 67
		;
		unavailable_observation = trpt->bup.oval;
		;
		goto R999;
;
		
	case 26: // STATE 70
		goto R999;
;
		
	case 27: // STATE 73
		goto R999;

	case 28: // STATE 71
		;
		now.all_trusted = trpt->bup.oval;
		;
		goto R999;
;
		
	case 29: // STATE 77
		goto R999;

	case 30: // STATE 75
		;
		now.has_unknown = trpt->bup.ovals[1];
		now.tool[ Index(now.slot, 4) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 32: // STATE 80
		;
		now.phase = trpt->bup.oval;
		;
		goto R999;
;
		
	case 33: // STATE 84
		goto R999;

	case 34: // STATE 82
		;
		now.slot = trpt->bup.oval;
		;
		goto R999;

	case 35: // STATE 88
		;
		now.done = trpt->bup.ovals[1];
		now.phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 36: // STATE 90
		goto R999;

	case 37: // STATE 98
		;
		now.phase = trpt->bup.ovals[1];
		now.frozen_version = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 38: // STATE 103
		goto R999;

	case 39: // STATE 101
		;
		now.done = trpt->bup.ovals[1];
		now.phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 40: // STATE 111
		;
		now.phase = trpt->bup.ovals[1];
		now.assessment_starts = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 41: // STATE 115
		;
		now.done = trpt->bup.ovals[1];
		now.phase = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 44: // STATE 122
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Cancellation */

	case 45: // STATE 1
		;
		now.cancelled = trpt->bup.oval;
		;
		goto R999;

	case 46: // STATE 5
		;
		p_restor(II);
		;
		;
		goto R999;
	}

