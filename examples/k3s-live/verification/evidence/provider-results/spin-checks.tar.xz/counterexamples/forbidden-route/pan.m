#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM choreography_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(done))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][1] = 1;
		if (!( !(((int)now.done))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Choreography */
	case 5: // STATE 1 - hybrid.pml:68 - [i = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->i);
		((P0 *)_this)->i = 0;
#ifdef VAR_RANGES
		logval("Choreography:i", ((int)((P0 *)_this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - hybrid.pml:69 - [((i<8))] (7:0:2 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		if (!((((int)((P0 *)_this)->i)<8)))
			continue;
		/* merge: state[i] = Absent(7, 3, 7) */
		reached[0][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[ Index(((int)((P0 *)_this)->i), 8) ];
		now.state[ Index(((P0 *)_this)->i, 8) ] = 5;
#ifdef VAR_RANGES
		logval("state[Choreography:i]", now.state[ Index(((int)((P0 *)_this)->i), 8) ]);
#endif
		;
		/* merge: i = (i+1)(7, 4, 7) */
		reached[0][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->i);
		((P0 *)_this)->i = (((int)((P0 *)_this)->i)+1);
#ifdef VAR_RANGES
		logval("Choreography:i", ((int)((P0 *)_this)->i));
#endif
		;
		/* merge: .(goto)(0, 8, 7) */
		reached[0][8] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 7: // STATE 10 - hybrid.pml:70 - [sender[0] = 0] (0:43:16 - 3)
		IfNotBlocked
		reached[0][10] = 1;
		(trpt+1)->bup.ovals = grab_ints(16);
		(trpt+1)->bup.ovals[0] = ((int)now.sender[0]);
		now.sender[0] = 0;
#ifdef VAR_RANGES
		logval("sender[0]", ((int)now.sender[0]));
#endif
		;
		/* merge: recipient[0] = 1(43, 11, 43) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.recipient[0]);
		now.recipient[0] = 1;
#ifdef VAR_RANGES
		logval("recipient[0]", ((int)now.recipient[0]));
#endif
		;
		/* merge: sender[1] = 1(43, 12, 43) */
		reached[0][12] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sender[1]);
		now.sender[1] = 1;
#ifdef VAR_RANGES
		logval("sender[1]", ((int)now.sender[1]));
#endif
		;
		/* merge: recipient[1] = 2(43, 13, 43) */
		reached[0][13] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.recipient[1]);
		now.recipient[1] = 2;
#ifdef VAR_RANGES
		logval("recipient[1]", ((int)now.recipient[1]));
#endif
		;
		/* merge: sender[2] = 1(43, 14, 43) */
		reached[0][14] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.sender[2]);
		now.sender[2] = 1;
#ifdef VAR_RANGES
		logval("sender[2]", ((int)now.sender[2]));
#endif
		;
		/* merge: recipient[2] = 4(43, 15, 43) */
		reached[0][15] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.recipient[2]);
		now.recipient[2] = 4;
#ifdef VAR_RANGES
		logval("recipient[2]", ((int)now.recipient[2]));
#endif
		;
		/* merge: sender[3] = 2(43, 16, 43) */
		reached[0][16] = 1;
		(trpt+1)->bup.ovals[6] = ((int)now.sender[3]);
		now.sender[3] = 2;
#ifdef VAR_RANGES
		logval("sender[3]", ((int)now.sender[3]));
#endif
		;
		/* merge: recipient[3] = 3(43, 17, 43) */
		reached[0][17] = 1;
		(trpt+1)->bup.ovals[7] = ((int)now.recipient[3]);
		now.recipient[3] = 3;
#ifdef VAR_RANGES
		logval("recipient[3]", ((int)now.recipient[3]));
#endif
		;
		/* merge: sender[4] = 2(43, 18, 43) */
		reached[0][18] = 1;
		(trpt+1)->bup.ovals[8] = ((int)now.sender[4]);
		now.sender[4] = 2;
#ifdef VAR_RANGES
		logval("sender[4]", ((int)now.sender[4]));
#endif
		;
		/* merge: recipient[4] = 4(43, 19, 43) */
		reached[0][19] = 1;
		(trpt+1)->bup.ovals[9] = ((int)now.recipient[4]);
		now.recipient[4] = 4;
#ifdef VAR_RANGES
		logval("recipient[4]", ((int)now.recipient[4]));
#endif
		;
		/* merge: sender[5] = 4(43, 20, 43) */
		reached[0][20] = 1;
		(trpt+1)->bup.ovals[10] = ((int)now.sender[5]);
		now.sender[5] = 4;
#ifdef VAR_RANGES
		logval("sender[5]", ((int)now.sender[5]));
#endif
		;
		/* merge: recipient[5] = 5(43, 21, 43) */
		reached[0][21] = 1;
		(trpt+1)->bup.ovals[11] = ((int)now.recipient[5]);
		now.recipient[5] = 5;
#ifdef VAR_RANGES
		logval("recipient[5]", ((int)now.recipient[5]));
#endif
		;
		/* merge: sender[6] = 4(43, 22, 43) */
		reached[0][22] = 1;
		(trpt+1)->bup.ovals[12] = ((int)now.sender[6]);
		now.sender[6] = 4;
#ifdef VAR_RANGES
		logval("sender[6]", ((int)now.sender[6]));
#endif
		;
		/* merge: recipient[6] = 5(43, 23, 43) */
		reached[0][23] = 1;
		(trpt+1)->bup.ovals[13] = ((int)now.recipient[6]);
		now.recipient[6] = 5;
#ifdef VAR_RANGES
		logval("recipient[6]", ((int)now.recipient[6]));
#endif
		;
		/* merge: sender[7] = 1(43, 24, 43) */
		reached[0][24] = 1;
		(trpt+1)->bup.ovals[14] = ((int)now.sender[7]);
		now.sender[7] = 1;
#ifdef VAR_RANGES
		logval("sender[7]", ((int)now.sender[7]));
#endif
		;
		/* merge: recipient[7] = 6(43, 25, 43) */
		reached[0][25] = 1;
		(trpt+1)->bup.ovals[15] = ((int)now.recipient[7]);
		now.recipient[7] = 6;
#ifdef VAR_RANGES
		logval("recipient[7]", ((int)now.recipient[7]));
#endif
		;
		_m = 3; goto P999; /* 15 */
	case 8: // STATE 26 - hybrid.pml:33 - [assert((state[0]==Absent))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][26] = 1;
		spin_assert((now.state[0]==5), "(state[0]==5)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 27 - hybrid.pml:35 - [((0==4))] (38:0:1 - 1)
		IfNotBlocked
		reached[0][27] = 1;
		if (!((0==4)))
			continue;
		/* merge: recipient[0] = 6(38, 28, 38) */
		reached[0][28] = 1;
		(trpt+1)->bup.oval = ((int)now.recipient[0]);
		now.recipient[0] = 6;
#ifdef VAR_RANGES
		logval("recipient[0]", ((int)now.recipient[0]));
#endif
		;
		/* merge: .(goto)(38, 32, 38) */
		reached[0][32] = 1;
		;
		/* merge: assert((((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1))))(38, 33, 38) */
		reached[0][33] = 1;
		spin_assert((((((((((((((((((int)now.sender[0])==0)&&(((int)now.recipient[0])==1))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==0)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==1)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==1)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==3)))||((((int)now.sender[0])==3)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==5)))||((((int)now.sender[0])==5)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==6)))||((((int)now.sender[0])==6)&&(((int)now.recipient[0])==1))), "(((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1)))", II, tt, t);
		_m = 3; goto P999; /* 3 */
	case 10: // STATE 30 - hybrid.pml:35 - [(1)] (38:0:0 - 1)
		IfNotBlocked
		reached[0][30] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(38, 32, 38) */
		reached[0][32] = 1;
		;
		/* merge: assert((((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1))))(38, 33, 38) */
		reached[0][33] = 1;
		spin_assert((((((((((((((((((int)now.sender[0])==0)&&(((int)now.recipient[0])==1))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==0)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==1)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==1)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==3)))||((((int)now.sender[0])==3)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==5)))||((((int)now.sender[0])==5)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==6)))||((((int)now.sender[0])==6)&&(((int)now.recipient[0])==1))), "(((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 11: // STATE 33 - hybrid.pml:37 - [assert((((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1))))] (0:38:0 - 3)
		IfNotBlocked
		reached[0][33] = 1;
		spin_assert((((((((((((((((((int)now.sender[0])==0)&&(((int)now.recipient[0])==1))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==0)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==1)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==1)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==3)))||((((int)now.sender[0])==3)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==5)))||((((int)now.sender[0])==5)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==6)))||((((int)now.sender[0])==6)&&(((int)now.recipient[0])==1))), "(((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 34 - hybrid.pml:39 - [((0==7))] (375:0:2 - 1)
		IfNotBlocked
		reached[0][34] = 1;
		if (!((0==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(375, 35, 375) */
		reached[0][35] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(375, 39, 375) */
		reached[0][39] = 1;
		;
		/* merge: state[0] = Sent(375, 40, 375) */
		reached[0][40] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[0];
		now.state[0] = 4;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 41, 375) */
		reached[0][41] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 42, 375) */
		reached[0][42] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 13: // STATE 37 - hybrid.pml:40 - [(1)] (375:0:2 - 1)
		IfNotBlocked
		reached[0][37] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(375, 39, 375) */
		reached[0][39] = 1;
		;
		/* merge: state[0] = Sent(375, 40, 375) */
		reached[0][40] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[0];
		now.state[0] = 4;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 41, 375) */
		reached[0][41] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 42, 375) */
		reached[0][42] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 14: // STATE 40 - hybrid.pml:42 - [state[0] = Sent] (0:375:2 - 3)
		IfNotBlocked
		reached[0][40] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[0];
		now.state[0] = 4;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 41, 375) */
		reached[0][41] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 42, 375) */
		reached[0][42] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 15: // STATE 45 - hybrid.pml:83 - [((state[0]==Sent))] (375:0:1 - 1)
		IfNotBlocked
		reached[0][45] = 1;
		if (!((now.state[0]==4)))
			continue;
		/* merge: state[0] = Received(0, 46, 375) */
		reached[0][46] = 1;
		(trpt+1)->bup.oval = now.state[0];
		now.state[0] = 3;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 16: // STATE 48 - hybrid.pml:85 - [((state[1]==Sent))] (375:0:1 - 1)
		IfNotBlocked
		reached[0][48] = 1;
		if (!((now.state[1]==4)))
			continue;
		/* merge: state[1] = Received(0, 49, 375) */
		reached[0][49] = 1;
		(trpt+1)->bup.oval = now.state[1];
		now.state[1] = 3;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 17: // STATE 51 - hybrid.pml:86 - [((state[2]==Sent))] (375:0:1 - 1)
		IfNotBlocked
		reached[0][51] = 1;
		if (!((now.state[2]==4)))
			continue;
		/* merge: state[2] = Received(0, 52, 375) */
		reached[0][52] = 1;
		(trpt+1)->bup.oval = now.state[2];
		now.state[2] = 3;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 18: // STATE 54 - hybrid.pml:87 - [((state[3]==Sent))] (375:0:1 - 1)
		IfNotBlocked
		reached[0][54] = 1;
		if (!((now.state[3]==4)))
			continue;
		/* merge: state[3] = Received(0, 55, 375) */
		reached[0][55] = 1;
		(trpt+1)->bup.oval = now.state[3];
		now.state[3] = 3;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 19: // STATE 57 - hybrid.pml:88 - [((state[4]==Sent))] (375:0:1 - 1)
		IfNotBlocked
		reached[0][57] = 1;
		if (!((now.state[4]==4)))
			continue;
		/* merge: state[4] = Received(0, 58, 375) */
		reached[0][58] = 1;
		(trpt+1)->bup.oval = now.state[4];
		now.state[4] = 3;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 20: // STATE 60 - hybrid.pml:89 - [((state[5]==Sent))] (375:0:1 - 1)
		IfNotBlocked
		reached[0][60] = 1;
		if (!((now.state[5]==4)))
			continue;
		/* merge: state[5] = Received(0, 61, 375) */
		reached[0][61] = 1;
		(trpt+1)->bup.oval = now.state[5];
		now.state[5] = 3;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 21: // STATE 63 - hybrid.pml:90 - [((state[6]==Sent))] (375:0:1 - 1)
		IfNotBlocked
		reached[0][63] = 1;
		if (!((now.state[6]==4)))
			continue;
		/* merge: state[6] = Received(0, 64, 375) */
		reached[0][64] = 1;
		(trpt+1)->bup.oval = now.state[6];
		now.state[6] = 3;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 22: // STATE 66 - hybrid.pml:91 - [((state[7]==Sent))] (375:0:1 - 1)
		IfNotBlocked
		reached[0][66] = 1;
		if (!((now.state[7]==4)))
			continue;
		/* merge: state[7] = Received(0, 67, 375) */
		reached[0][67] = 1;
		(trpt+1)->bup.oval = now.state[7];
		now.state[7] = 3;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 23: // STATE 69 - hybrid.pml:94 - [(((state[0]==Received)&&(state[1]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][69] = 1;
		if (!(((now.state[0]==3)&&(now.state[1]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 70 - hybrid.pml:33 - [assert((state[1]==Absent))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][70] = 1;
		spin_assert((now.state[1]==5), "(state[1]==5)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 71 - hybrid.pml:35 - [((1==4))] (82:0:1 - 1)
		IfNotBlocked
		reached[0][71] = 1;
		if (!((1==4)))
			continue;
		/* merge: recipient[1] = 6(82, 72, 82) */
		reached[0][72] = 1;
		(trpt+1)->bup.oval = ((int)now.recipient[1]);
		now.recipient[1] = 6;
#ifdef VAR_RANGES
		logval("recipient[1]", ((int)now.recipient[1]));
#endif
		;
		/* merge: .(goto)(82, 76, 82) */
		reached[0][76] = 1;
		;
		/* merge: assert((((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1))))(82, 77, 82) */
		reached[0][77] = 1;
		spin_assert((((((((((((((((((int)now.sender[1])==0)&&(((int)now.recipient[1])==1))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==0)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==1)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==1)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==3)))||((((int)now.sender[1])==3)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==5)))||((((int)now.sender[1])==5)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==6)))||((((int)now.sender[1])==6)&&(((int)now.recipient[1])==1))), "(((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1)))", II, tt, t);
		_m = 3; goto P999; /* 3 */
	case 26: // STATE 74 - hybrid.pml:35 - [(1)] (82:0:0 - 1)
		IfNotBlocked
		reached[0][74] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(82, 76, 82) */
		reached[0][76] = 1;
		;
		/* merge: assert((((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1))))(82, 77, 82) */
		reached[0][77] = 1;
		spin_assert((((((((((((((((((int)now.sender[1])==0)&&(((int)now.recipient[1])==1))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==0)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==1)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==1)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==3)))||((((int)now.sender[1])==3)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==5)))||((((int)now.sender[1])==5)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==6)))||((((int)now.sender[1])==6)&&(((int)now.recipient[1])==1))), "(((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 27: // STATE 77 - hybrid.pml:37 - [assert((((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1))))] (0:82:0 - 3)
		IfNotBlocked
		reached[0][77] = 1;
		spin_assert((((((((((((((((((int)now.sender[1])==0)&&(((int)now.recipient[1])==1))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==0)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==1)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==1)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==3)))||((((int)now.sender[1])==3)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==5)))||((((int)now.sender[1])==5)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==6)))||((((int)now.sender[1])==6)&&(((int)now.recipient[1])==1))), "(((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 28: // STATE 78 - hybrid.pml:39 - [((1==7))] (375:0:2 - 1)
		IfNotBlocked
		reached[0][78] = 1;
		if (!((1==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(375, 79, 375) */
		reached[0][79] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(375, 83, 375) */
		reached[0][83] = 1;
		;
		/* merge: state[1] = Sent(375, 84, 375) */
		reached[0][84] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[1];
		now.state[1] = 4;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 85, 375) */
		reached[0][85] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 86, 375) */
		reached[0][86] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 29: // STATE 81 - hybrid.pml:40 - [(1)] (375:0:2 - 1)
		IfNotBlocked
		reached[0][81] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(375, 83, 375) */
		reached[0][83] = 1;
		;
		/* merge: state[1] = Sent(375, 84, 375) */
		reached[0][84] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[1];
		now.state[1] = 4;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 85, 375) */
		reached[0][85] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 86, 375) */
		reached[0][86] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 30: // STATE 84 - hybrid.pml:42 - [state[1] = Sent] (0:375:2 - 3)
		IfNotBlocked
		reached[0][84] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[1];
		now.state[1] = 4;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 85, 375) */
		reached[0][85] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 86, 375) */
		reached[0][86] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 31: // STATE 89 - hybrid.pml:95 - [(((state[0]==Received)&&(state[2]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][89] = 1;
		if (!(((now.state[0]==3)&&(now.state[2]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 90 - hybrid.pml:33 - [assert((state[2]==Absent))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][90] = 1;
		spin_assert((now.state[2]==5), "(state[2]==5)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 91 - hybrid.pml:35 - [((2==4))] (102:0:1 - 1)
		IfNotBlocked
		reached[0][91] = 1;
		if (!((2==4)))
			continue;
		/* merge: recipient[2] = 6(102, 92, 102) */
		reached[0][92] = 1;
		(trpt+1)->bup.oval = ((int)now.recipient[2]);
		now.recipient[2] = 6;
#ifdef VAR_RANGES
		logval("recipient[2]", ((int)now.recipient[2]));
#endif
		;
		/* merge: .(goto)(102, 96, 102) */
		reached[0][96] = 1;
		;
		/* merge: assert((((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1))))(102, 97, 102) */
		reached[0][97] = 1;
		spin_assert((((((((((((((((((int)now.sender[2])==0)&&(((int)now.recipient[2])==1))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==0)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==1)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==1)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==3)))||((((int)now.sender[2])==3)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==5)))||((((int)now.sender[2])==5)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==6)))||((((int)now.sender[2])==6)&&(((int)now.recipient[2])==1))), "(((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1)))", II, tt, t);
		_m = 3; goto P999; /* 3 */
	case 34: // STATE 94 - hybrid.pml:35 - [(1)] (102:0:0 - 1)
		IfNotBlocked
		reached[0][94] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(102, 96, 102) */
		reached[0][96] = 1;
		;
		/* merge: assert((((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1))))(102, 97, 102) */
		reached[0][97] = 1;
		spin_assert((((((((((((((((((int)now.sender[2])==0)&&(((int)now.recipient[2])==1))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==0)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==1)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==1)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==3)))||((((int)now.sender[2])==3)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==5)))||((((int)now.sender[2])==5)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==6)))||((((int)now.sender[2])==6)&&(((int)now.recipient[2])==1))), "(((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 35: // STATE 97 - hybrid.pml:37 - [assert((((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1))))] (0:102:0 - 3)
		IfNotBlocked
		reached[0][97] = 1;
		spin_assert((((((((((((((((((int)now.sender[2])==0)&&(((int)now.recipient[2])==1))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==0)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==1)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==1)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==3)))||((((int)now.sender[2])==3)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==5)))||((((int)now.sender[2])==5)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==6)))||((((int)now.sender[2])==6)&&(((int)now.recipient[2])==1))), "(((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 36: // STATE 98 - hybrid.pml:39 - [((2==7))] (375:0:2 - 1)
		IfNotBlocked
		reached[0][98] = 1;
		if (!((2==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(375, 99, 375) */
		reached[0][99] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(375, 103, 375) */
		reached[0][103] = 1;
		;
		/* merge: state[2] = Sent(375, 104, 375) */
		reached[0][104] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[2];
		now.state[2] = 4;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 105, 375) */
		reached[0][105] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 106, 375) */
		reached[0][106] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 37: // STATE 101 - hybrid.pml:40 - [(1)] (375:0:2 - 1)
		IfNotBlocked
		reached[0][101] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(375, 103, 375) */
		reached[0][103] = 1;
		;
		/* merge: state[2] = Sent(375, 104, 375) */
		reached[0][104] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[2];
		now.state[2] = 4;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 105, 375) */
		reached[0][105] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 106, 375) */
		reached[0][106] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 38: // STATE 104 - hybrid.pml:42 - [state[2] = Sent] (0:375:2 - 3)
		IfNotBlocked
		reached[0][104] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[2];
		now.state[2] = 4;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 105, 375) */
		reached[0][105] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 106, 375) */
		reached[0][106] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 39: // STATE 109 - hybrid.pml:96 - [(((state[1]==Received)&&(state[3]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][109] = 1;
		if (!(((now.state[1]==3)&&(now.state[3]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 110 - hybrid.pml:33 - [assert((state[3]==Absent))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][110] = 1;
		spin_assert((now.state[3]==5), "(state[3]==5)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 41: // STATE 111 - hybrid.pml:35 - [((3==4))] (122:0:1 - 1)
		IfNotBlocked
		reached[0][111] = 1;
		if (!((3==4)))
			continue;
		/* merge: recipient[3] = 6(122, 112, 122) */
		reached[0][112] = 1;
		(trpt+1)->bup.oval = ((int)now.recipient[3]);
		now.recipient[3] = 6;
#ifdef VAR_RANGES
		logval("recipient[3]", ((int)now.recipient[3]));
#endif
		;
		/* merge: .(goto)(122, 116, 122) */
		reached[0][116] = 1;
		;
		/* merge: assert((((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1))))(122, 117, 122) */
		reached[0][117] = 1;
		spin_assert((((((((((((((((((int)now.sender[3])==0)&&(((int)now.recipient[3])==1))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==0)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==1)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==1)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==3)))||((((int)now.sender[3])==3)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==5)))||((((int)now.sender[3])==5)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==6)))||((((int)now.sender[3])==6)&&(((int)now.recipient[3])==1))), "(((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1)))", II, tt, t);
		_m = 3; goto P999; /* 3 */
	case 42: // STATE 114 - hybrid.pml:35 - [(1)] (122:0:0 - 1)
		IfNotBlocked
		reached[0][114] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(122, 116, 122) */
		reached[0][116] = 1;
		;
		/* merge: assert((((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1))))(122, 117, 122) */
		reached[0][117] = 1;
		spin_assert((((((((((((((((((int)now.sender[3])==0)&&(((int)now.recipient[3])==1))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==0)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==1)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==1)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==3)))||((((int)now.sender[3])==3)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==5)))||((((int)now.sender[3])==5)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==6)))||((((int)now.sender[3])==6)&&(((int)now.recipient[3])==1))), "(((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 43: // STATE 117 - hybrid.pml:37 - [assert((((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1))))] (0:122:0 - 3)
		IfNotBlocked
		reached[0][117] = 1;
		spin_assert((((((((((((((((((int)now.sender[3])==0)&&(((int)now.recipient[3])==1))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==0)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==1)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==1)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==3)))||((((int)now.sender[3])==3)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==5)))||((((int)now.sender[3])==5)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==6)))||((((int)now.sender[3])==6)&&(((int)now.recipient[3])==1))), "(((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 44: // STATE 118 - hybrid.pml:39 - [((3==7))] (375:0:2 - 1)
		IfNotBlocked
		reached[0][118] = 1;
		if (!((3==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(375, 119, 375) */
		reached[0][119] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(375, 123, 375) */
		reached[0][123] = 1;
		;
		/* merge: state[3] = Sent(375, 124, 375) */
		reached[0][124] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[3];
		now.state[3] = 4;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 125, 375) */
		reached[0][125] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 126, 375) */
		reached[0][126] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 45: // STATE 121 - hybrid.pml:40 - [(1)] (375:0:2 - 1)
		IfNotBlocked
		reached[0][121] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(375, 123, 375) */
		reached[0][123] = 1;
		;
		/* merge: state[3] = Sent(375, 124, 375) */
		reached[0][124] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[3];
		now.state[3] = 4;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 125, 375) */
		reached[0][125] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 126, 375) */
		reached[0][126] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 46: // STATE 124 - hybrid.pml:42 - [state[3] = Sent] (0:375:2 - 3)
		IfNotBlocked
		reached[0][124] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[3];
		now.state[3] = 4;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 125, 375) */
		reached[0][125] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 126, 375) */
		reached[0][126] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 47: // STATE 129 - hybrid.pml:97 - [(((state[1]==Received)&&(state[3]==Failed)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][129] = 1;
		if (!(((now.state[1]==3)&&(now.state[3]==1))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 48: // STATE 130 - hybrid.pml:48 - [assert((state[1]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][130] = 1;
		spin_assert((now.state[1]==3), "(state[1]==3)", II, tt, t);
		/* merge: reply_to[1] = 1(375, 131, 375) */
		reached[0][131] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[1]);
		now.reply_to[1] = 1;
#ifdef VAR_RANGES
		logval("reply_to[1]", ((int)now.reply_to[1]));
#endif
		;
		/* merge: assert((reply_to[1]==1))(375, 132, 375) */
		reached[0][132] = 1;
		spin_assert((((int)now.reply_to[1])==1), "(reply_to[1]==1)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))(375, 133, 375) */
		reached[0][133] = 1;
		spin_assert((((((((((((((((((int)now.recipient[1])==0)&&(((int)now.sender[1])==1))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==0)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==3)))||((((int)now.recipient[1])==3)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==5)))||((((int)now.recipient[1])==5)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==6)))||((((int)now.recipient[1])==6)&&(((int)now.sender[1])==1))), "(((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1)))", II, tt, t);
		/* merge: state[1] = 1(375, 134, 375) */
		reached[0][134] = 1;
		(trpt+1)->bup.ovals[1] = now.state[1];
		now.state[1] = 1;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 49: // STATE 137 - hybrid.pml:98 - [((((state[1]==Received)&&(state[3]==Succeeded))&&(state[4]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][137] = 1;
		if (!((((now.state[1]==3)&&(now.state[3]==2))&&(now.state[4]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 50: // STATE 138 - hybrid.pml:33 - [assert((state[4]==Absent))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][138] = 1;
		spin_assert((now.state[4]==5), "(state[4]==5)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 51: // STATE 139 - hybrid.pml:35 - [((4==4))] (150:0:1 - 1)
		IfNotBlocked
		reached[0][139] = 1;
		if (!((4==4)))
			continue;
		/* merge: recipient[4] = 6(150, 140, 150) */
		reached[0][140] = 1;
		(trpt+1)->bup.oval = ((int)now.recipient[4]);
		now.recipient[4] = 6;
#ifdef VAR_RANGES
		logval("recipient[4]", ((int)now.recipient[4]));
#endif
		;
		/* merge: .(goto)(150, 144, 150) */
		reached[0][144] = 1;
		;
		/* merge: assert((((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1))))(150, 145, 150) */
		reached[0][145] = 1;
		spin_assert((((((((((((((((((int)now.sender[4])==0)&&(((int)now.recipient[4])==1))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==0)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==1)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==1)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==3)))||((((int)now.sender[4])==3)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==5)))||((((int)now.sender[4])==5)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==6)))||((((int)now.sender[4])==6)&&(((int)now.recipient[4])==1))), "(((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1)))", II, tt, t);
		_m = 3; goto P999; /* 3 */
	case 52: // STATE 142 - hybrid.pml:35 - [(1)] (150:0:0 - 1)
		IfNotBlocked
		reached[0][142] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(150, 144, 150) */
		reached[0][144] = 1;
		;
		/* merge: assert((((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1))))(150, 145, 150) */
		reached[0][145] = 1;
		spin_assert((((((((((((((((((int)now.sender[4])==0)&&(((int)now.recipient[4])==1))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==0)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==1)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==1)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==3)))||((((int)now.sender[4])==3)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==5)))||((((int)now.sender[4])==5)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==6)))||((((int)now.sender[4])==6)&&(((int)now.recipient[4])==1))), "(((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 53: // STATE 145 - hybrid.pml:37 - [assert((((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1))))] (0:150:0 - 3)
		IfNotBlocked
		reached[0][145] = 1;
		spin_assert((((((((((((((((((int)now.sender[4])==0)&&(((int)now.recipient[4])==1))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==0)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==1)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==1)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==3)))||((((int)now.sender[4])==3)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==5)))||((((int)now.sender[4])==5)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==6)))||((((int)now.sender[4])==6)&&(((int)now.recipient[4])==1))), "(((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 54: // STATE 146 - hybrid.pml:39 - [((4==7))] (375:0:2 - 1)
		IfNotBlocked
		reached[0][146] = 1;
		if (!((4==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(375, 147, 375) */
		reached[0][147] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(375, 151, 375) */
		reached[0][151] = 1;
		;
		/* merge: state[4] = Sent(375, 152, 375) */
		reached[0][152] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[4];
		now.state[4] = 4;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 153, 375) */
		reached[0][153] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 154, 375) */
		reached[0][154] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 55: // STATE 149 - hybrid.pml:40 - [(1)] (375:0:2 - 1)
		IfNotBlocked
		reached[0][149] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(375, 151, 375) */
		reached[0][151] = 1;
		;
		/* merge: state[4] = Sent(375, 152, 375) */
		reached[0][152] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[4];
		now.state[4] = 4;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 153, 375) */
		reached[0][153] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 154, 375) */
		reached[0][154] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 56: // STATE 152 - hybrid.pml:42 - [state[4] = Sent] (0:375:2 - 3)
		IfNotBlocked
		reached[0][152] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[4];
		now.state[4] = 4;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 153, 375) */
		reached[0][153] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 154, 375) */
		reached[0][154] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 57: // STATE 157 - hybrid.pml:99 - [(((state[1]==Received)&&((state[4]==Succeeded)||(state[4]==Failed))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][157] = 1;
		if (!(((now.state[1]==3)&&((now.state[4]==2)||(now.state[4]==1)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 58: // STATE 158 - hybrid.pml:60 - [((state[4]==Succeeded))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][158] = 1;
		if (!((now.state[4]==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 59: // STATE 159 - hybrid.pml:48 - [assert((state[1]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][159] = 1;
		spin_assert((now.state[1]==3), "(state[1]==3)", II, tt, t);
		/* merge: reply_to[1] = 1(375, 160, 375) */
		reached[0][160] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[1]);
		now.reply_to[1] = 1;
#ifdef VAR_RANGES
		logval("reply_to[1]", ((int)now.reply_to[1]));
#endif
		;
		/* merge: assert((reply_to[1]==1))(375, 161, 375) */
		reached[0][161] = 1;
		spin_assert((((int)now.reply_to[1])==1), "(reply_to[1]==1)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))(375, 162, 375) */
		reached[0][162] = 1;
		spin_assert((((((((((((((((((int)now.recipient[1])==0)&&(((int)now.sender[1])==1))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==0)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==3)))||((((int)now.recipient[1])==3)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==5)))||((((int)now.recipient[1])==5)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==6)))||((((int)now.recipient[1])==6)&&(((int)now.sender[1])==1))), "(((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1)))", II, tt, t);
		/* merge: state[1] = 2(375, 163, 375) */
		reached[0][163] = 1;
		(trpt+1)->bup.ovals[1] = now.state[1];
		now.state[1] = 2;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: .(goto)(375, 173, 375) */
		reached[0][173] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 60: // STATE 173 - hybrid.pml:63 - [.(goto)] (0:375:0 - 2)
		IfNotBlocked
		reached[0][173] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 61: // STATE 165 - hybrid.pml:61 - [((state[4]==Failed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][165] = 1;
		if (!((now.state[4]==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 62: // STATE 166 - hybrid.pml:48 - [assert((state[1]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][166] = 1;
		spin_assert((now.state[1]==3), "(state[1]==3)", II, tt, t);
		/* merge: reply_to[1] = 1(375, 167, 375) */
		reached[0][167] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[1]);
		now.reply_to[1] = 1;
#ifdef VAR_RANGES
		logval("reply_to[1]", ((int)now.reply_to[1]));
#endif
		;
		/* merge: assert((reply_to[1]==1))(375, 168, 375) */
		reached[0][168] = 1;
		spin_assert((((int)now.reply_to[1])==1), "(reply_to[1]==1)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))(375, 169, 375) */
		reached[0][169] = 1;
		spin_assert((((((((((((((((((int)now.recipient[1])==0)&&(((int)now.sender[1])==1))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==0)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==3)))||((((int)now.recipient[1])==3)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==5)))||((((int)now.recipient[1])==5)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==6)))||((((int)now.recipient[1])==6)&&(((int)now.sender[1])==1))), "(((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1)))", II, tt, t);
		/* merge: state[1] = 1(375, 170, 375) */
		reached[0][170] = 1;
		(trpt+1)->bup.ovals[1] = now.state[1];
		now.state[1] = 1;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: .(goto)(375, 173, 375) */
		reached[0][173] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 63: // STATE 176 - hybrid.pml:100 - [(((state[2]==Received)&&(state[5]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][176] = 1;
		if (!(((now.state[2]==3)&&(now.state[5]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 64: // STATE 177 - hybrid.pml:33 - [assert((state[5]==Absent))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][177] = 1;
		spin_assert((now.state[5]==5), "(state[5]==5)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 65: // STATE 178 - hybrid.pml:35 - [((5==4))] (189:0:1 - 1)
		IfNotBlocked
		reached[0][178] = 1;
		if (!((5==4)))
			continue;
		/* merge: recipient[5] = 6(189, 179, 189) */
		reached[0][179] = 1;
		(trpt+1)->bup.oval = ((int)now.recipient[5]);
		now.recipient[5] = 6;
#ifdef VAR_RANGES
		logval("recipient[5]", ((int)now.recipient[5]));
#endif
		;
		/* merge: .(goto)(189, 183, 189) */
		reached[0][183] = 1;
		;
		/* merge: assert((((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1))))(189, 184, 189) */
		reached[0][184] = 1;
		spin_assert((((((((((((((((((int)now.sender[5])==0)&&(((int)now.recipient[5])==1))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==0)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==1)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==1)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==3)))||((((int)now.sender[5])==3)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==5)))||((((int)now.sender[5])==5)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==6)))||((((int)now.sender[5])==6)&&(((int)now.recipient[5])==1))), "(((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1)))", II, tt, t);
		_m = 3; goto P999; /* 3 */
	case 66: // STATE 181 - hybrid.pml:35 - [(1)] (189:0:0 - 1)
		IfNotBlocked
		reached[0][181] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(189, 183, 189) */
		reached[0][183] = 1;
		;
		/* merge: assert((((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1))))(189, 184, 189) */
		reached[0][184] = 1;
		spin_assert((((((((((((((((((int)now.sender[5])==0)&&(((int)now.recipient[5])==1))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==0)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==1)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==1)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==3)))||((((int)now.sender[5])==3)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==5)))||((((int)now.sender[5])==5)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==6)))||((((int)now.sender[5])==6)&&(((int)now.recipient[5])==1))), "(((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 67: // STATE 184 - hybrid.pml:37 - [assert((((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1))))] (0:189:0 - 3)
		IfNotBlocked
		reached[0][184] = 1;
		spin_assert((((((((((((((((((int)now.sender[5])==0)&&(((int)now.recipient[5])==1))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==0)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==1)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==1)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==3)))||((((int)now.sender[5])==3)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==5)))||((((int)now.sender[5])==5)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==6)))||((((int)now.sender[5])==6)&&(((int)now.recipient[5])==1))), "(((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 68: // STATE 185 - hybrid.pml:39 - [((5==7))] (375:0:2 - 1)
		IfNotBlocked
		reached[0][185] = 1;
		if (!((5==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(375, 186, 375) */
		reached[0][186] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(375, 190, 375) */
		reached[0][190] = 1;
		;
		/* merge: state[5] = Sent(375, 191, 375) */
		reached[0][191] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[5];
		now.state[5] = 4;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 192, 375) */
		reached[0][192] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 193, 375) */
		reached[0][193] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 69: // STATE 188 - hybrid.pml:40 - [(1)] (375:0:2 - 1)
		IfNotBlocked
		reached[0][188] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(375, 190, 375) */
		reached[0][190] = 1;
		;
		/* merge: state[5] = Sent(375, 191, 375) */
		reached[0][191] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[5];
		now.state[5] = 4;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 192, 375) */
		reached[0][192] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 193, 375) */
		reached[0][193] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 70: // STATE 191 - hybrid.pml:42 - [state[5] = Sent] (0:375:2 - 3)
		IfNotBlocked
		reached[0][191] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[5];
		now.state[5] = 4;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 192, 375) */
		reached[0][192] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 193, 375) */
		reached[0][193] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 71: // STATE 196 - hybrid.pml:101 - [(((state[2]==Received)&&((state[5]==Succeeded)||(state[5]==Failed))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][196] = 1;
		if (!(((now.state[2]==3)&&((now.state[5]==2)||(now.state[5]==1)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 72: // STATE 197 - hybrid.pml:60 - [((state[5]==Succeeded))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][197] = 1;
		if (!((now.state[5]==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 73: // STATE 198 - hybrid.pml:48 - [assert((state[2]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][198] = 1;
		spin_assert((now.state[2]==3), "(state[2]==3)", II, tt, t);
		/* merge: reply_to[2] = 2(375, 199, 375) */
		reached[0][199] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[2]);
		now.reply_to[2] = 2;
#ifdef VAR_RANGES
		logval("reply_to[2]", ((int)now.reply_to[2]));
#endif
		;
		/* merge: assert((reply_to[2]==2))(375, 200, 375) */
		reached[0][200] = 1;
		spin_assert((((int)now.reply_to[2])==2), "(reply_to[2]==2)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1))))(375, 201, 375) */
		reached[0][201] = 1;
		spin_assert((((((((((((((((((int)now.recipient[2])==0)&&(((int)now.sender[2])==1))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==0)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==1)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==1)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==3)))||((((int)now.recipient[2])==3)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==5)))||((((int)now.recipient[2])==5)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==6)))||((((int)now.recipient[2])==6)&&(((int)now.sender[2])==1))), "(((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1)))", II, tt, t);
		/* merge: state[2] = 2(375, 202, 375) */
		reached[0][202] = 1;
		(trpt+1)->bup.ovals[1] = now.state[2];
		now.state[2] = 2;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: .(goto)(375, 212, 375) */
		reached[0][212] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 74: // STATE 212 - hybrid.pml:63 - [.(goto)] (0:375:0 - 2)
		IfNotBlocked
		reached[0][212] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 75: // STATE 204 - hybrid.pml:61 - [((state[5]==Failed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][204] = 1;
		if (!((now.state[5]==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 76: // STATE 205 - hybrid.pml:48 - [assert((state[2]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][205] = 1;
		spin_assert((now.state[2]==3), "(state[2]==3)", II, tt, t);
		/* merge: reply_to[2] = 2(375, 206, 375) */
		reached[0][206] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[2]);
		now.reply_to[2] = 2;
#ifdef VAR_RANGES
		logval("reply_to[2]", ((int)now.reply_to[2]));
#endif
		;
		/* merge: assert((reply_to[2]==2))(375, 207, 375) */
		reached[0][207] = 1;
		spin_assert((((int)now.reply_to[2])==2), "(reply_to[2]==2)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1))))(375, 208, 375) */
		reached[0][208] = 1;
		spin_assert((((((((((((((((((int)now.recipient[2])==0)&&(((int)now.sender[2])==1))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==0)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==1)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==1)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==3)))||((((int)now.recipient[2])==3)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==5)))||((((int)now.recipient[2])==5)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==6)))||((((int)now.recipient[2])==6)&&(((int)now.sender[2])==1))), "(((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1)))", II, tt, t);
		/* merge: state[2] = 1(375, 209, 375) */
		reached[0][209] = 1;
		(trpt+1)->bup.ovals[1] = now.state[2];
		now.state[2] = 1;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: .(goto)(375, 212, 375) */
		reached[0][212] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 77: // STATE 215 - hybrid.pml:102 - [(((state[4]==Received)&&(state[6]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][215] = 1;
		if (!(((now.state[4]==3)&&(now.state[6]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 78: // STATE 216 - hybrid.pml:33 - [assert((state[6]==Absent))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][216] = 1;
		spin_assert((now.state[6]==5), "(state[6]==5)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 79: // STATE 217 - hybrid.pml:35 - [((6==4))] (228:0:1 - 1)
		IfNotBlocked
		reached[0][217] = 1;
		if (!((6==4)))
			continue;
		/* merge: recipient[6] = 6(228, 218, 228) */
		reached[0][218] = 1;
		(trpt+1)->bup.oval = ((int)now.recipient[6]);
		now.recipient[6] = 6;
#ifdef VAR_RANGES
		logval("recipient[6]", ((int)now.recipient[6]));
#endif
		;
		/* merge: .(goto)(228, 222, 228) */
		reached[0][222] = 1;
		;
		/* merge: assert((((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1))))(228, 223, 228) */
		reached[0][223] = 1;
		spin_assert((((((((((((((((((int)now.sender[6])==0)&&(((int)now.recipient[6])==1))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==0)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==1)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==1)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==3)))||((((int)now.sender[6])==3)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==5)))||((((int)now.sender[6])==5)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==6)))||((((int)now.sender[6])==6)&&(((int)now.recipient[6])==1))), "(((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1)))", II, tt, t);
		_m = 3; goto P999; /* 3 */
	case 80: // STATE 220 - hybrid.pml:35 - [(1)] (228:0:0 - 1)
		IfNotBlocked
		reached[0][220] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(228, 222, 228) */
		reached[0][222] = 1;
		;
		/* merge: assert((((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1))))(228, 223, 228) */
		reached[0][223] = 1;
		spin_assert((((((((((((((((((int)now.sender[6])==0)&&(((int)now.recipient[6])==1))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==0)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==1)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==1)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==3)))||((((int)now.sender[6])==3)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==5)))||((((int)now.sender[6])==5)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==6)))||((((int)now.sender[6])==6)&&(((int)now.recipient[6])==1))), "(((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 81: // STATE 223 - hybrid.pml:37 - [assert((((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1))))] (0:228:0 - 3)
		IfNotBlocked
		reached[0][223] = 1;
		spin_assert((((((((((((((((((int)now.sender[6])==0)&&(((int)now.recipient[6])==1))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==0)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==1)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==1)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==3)))||((((int)now.sender[6])==3)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==5)))||((((int)now.sender[6])==5)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==6)))||((((int)now.sender[6])==6)&&(((int)now.recipient[6])==1))), "(((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 82: // STATE 224 - hybrid.pml:39 - [((6==7))] (375:0:2 - 1)
		IfNotBlocked
		reached[0][224] = 1;
		if (!((6==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(375, 225, 375) */
		reached[0][225] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(375, 229, 375) */
		reached[0][229] = 1;
		;
		/* merge: state[6] = Sent(375, 230, 375) */
		reached[0][230] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[6];
		now.state[6] = 4;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 231, 375) */
		reached[0][231] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 232, 375) */
		reached[0][232] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 83: // STATE 227 - hybrid.pml:40 - [(1)] (375:0:2 - 1)
		IfNotBlocked
		reached[0][227] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(375, 229, 375) */
		reached[0][229] = 1;
		;
		/* merge: state[6] = Sent(375, 230, 375) */
		reached[0][230] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[6];
		now.state[6] = 4;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 231, 375) */
		reached[0][231] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 232, 375) */
		reached[0][232] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 84: // STATE 230 - hybrid.pml:42 - [state[6] = Sent] (0:375:2 - 3)
		IfNotBlocked
		reached[0][230] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[6];
		now.state[6] = 4;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 231, 375) */
		reached[0][231] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 232, 375) */
		reached[0][232] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 85: // STATE 235 - hybrid.pml:103 - [(((state[4]==Received)&&((state[6]==Succeeded)||(state[6]==Failed))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][235] = 1;
		if (!(((now.state[4]==3)&&((now.state[6]==2)||(now.state[6]==1)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 86: // STATE 236 - hybrid.pml:60 - [((state[6]==Succeeded))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][236] = 1;
		if (!((now.state[6]==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 87: // STATE 237 - hybrid.pml:48 - [assert((state[4]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][237] = 1;
		spin_assert((now.state[4]==3), "(state[4]==3)", II, tt, t);
		/* merge: reply_to[4] = 4(375, 238, 375) */
		reached[0][238] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[4]);
		now.reply_to[4] = 4;
#ifdef VAR_RANGES
		logval("reply_to[4]", ((int)now.reply_to[4]));
#endif
		;
		/* merge: assert((reply_to[4]==4))(375, 239, 375) */
		reached[0][239] = 1;
		spin_assert((((int)now.reply_to[4])==4), "(reply_to[4]==4)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1))))(375, 240, 375) */
		reached[0][240] = 1;
		spin_assert((((((((((((((((((int)now.recipient[4])==0)&&(((int)now.sender[4])==1))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==0)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==1)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==1)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==3)))||((((int)now.recipient[4])==3)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==5)))||((((int)now.recipient[4])==5)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==6)))||((((int)now.recipient[4])==6)&&(((int)now.sender[4])==1))), "(((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1)))", II, tt, t);
		/* merge: state[4] = 2(375, 241, 375) */
		reached[0][241] = 1;
		(trpt+1)->bup.ovals[1] = now.state[4];
		now.state[4] = 2;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: .(goto)(375, 251, 375) */
		reached[0][251] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 88: // STATE 251 - hybrid.pml:63 - [.(goto)] (0:375:0 - 2)
		IfNotBlocked
		reached[0][251] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 89: // STATE 243 - hybrid.pml:61 - [((state[6]==Failed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][243] = 1;
		if (!((now.state[6]==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 90: // STATE 244 - hybrid.pml:48 - [assert((state[4]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][244] = 1;
		spin_assert((now.state[4]==3), "(state[4]==3)", II, tt, t);
		/* merge: reply_to[4] = 4(375, 245, 375) */
		reached[0][245] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[4]);
		now.reply_to[4] = 4;
#ifdef VAR_RANGES
		logval("reply_to[4]", ((int)now.reply_to[4]));
#endif
		;
		/* merge: assert((reply_to[4]==4))(375, 246, 375) */
		reached[0][246] = 1;
		spin_assert((((int)now.reply_to[4])==4), "(reply_to[4]==4)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1))))(375, 247, 375) */
		reached[0][247] = 1;
		spin_assert((((((((((((((((((int)now.recipient[4])==0)&&(((int)now.sender[4])==1))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==0)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==1)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==1)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==3)))||((((int)now.recipient[4])==3)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==5)))||((((int)now.recipient[4])==5)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==6)))||((((int)now.recipient[4])==6)&&(((int)now.sender[4])==1))), "(((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1)))", II, tt, t);
		/* merge: state[4] = 1(375, 248, 375) */
		reached[0][248] = 1;
		(trpt+1)->bup.ovals[1] = now.state[4];
		now.state[4] = 1;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: .(goto)(375, 251, 375) */
		reached[0][251] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 91: // STATE 254 - hybrid.pml:106 - [((state[3]==Received))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][254] = 1;
		if (!((now.state[3]==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 92: // STATE 255 - hybrid.pml:48 - [assert((state[3]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][255] = 1;
		spin_assert((now.state[3]==3), "(state[3]==3)", II, tt, t);
		/* merge: reply_to[3] = 3(375, 256, 375) */
		reached[0][256] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[3]);
		now.reply_to[3] = 3;
#ifdef VAR_RANGES
		logval("reply_to[3]", ((int)now.reply_to[3]));
#endif
		;
		/* merge: assert((reply_to[3]==3))(375, 257, 375) */
		reached[0][257] = 1;
		spin_assert((((int)now.reply_to[3])==3), "(reply_to[3]==3)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1))))(375, 258, 375) */
		reached[0][258] = 1;
		spin_assert((((((((((((((((((int)now.recipient[3])==0)&&(((int)now.sender[3])==1))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==0)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==1)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==1)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==3)))||((((int)now.recipient[3])==3)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==5)))||((((int)now.recipient[3])==5)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==6)))||((((int)now.recipient[3])==6)&&(((int)now.sender[3])==1))), "(((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1)))", II, tt, t);
		/* merge: state[3] = 2(375, 259, 375) */
		reached[0][259] = 1;
		(trpt+1)->bup.ovals[1] = now.state[3];
		now.state[3] = 2;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: .(goto)(375, 268, 375) */
		reached[0][268] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 93: // STATE 268 - hybrid.pml:106 - [.(goto)] (0:375:0 - 2)
		IfNotBlocked
		reached[0][268] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 94: // STATE 261 - hybrid.pml:48 - [assert((state[3]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][261] = 1;
		spin_assert((now.state[3]==3), "(state[3]==3)", II, tt, t);
		/* merge: reply_to[3] = 3(375, 262, 375) */
		reached[0][262] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[3]);
		now.reply_to[3] = 3;
#ifdef VAR_RANGES
		logval("reply_to[3]", ((int)now.reply_to[3]));
#endif
		;
		/* merge: assert((reply_to[3]==3))(375, 263, 375) */
		reached[0][263] = 1;
		spin_assert((((int)now.reply_to[3])==3), "(reply_to[3]==3)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1))))(375, 264, 375) */
		reached[0][264] = 1;
		spin_assert((((((((((((((((((int)now.recipient[3])==0)&&(((int)now.sender[3])==1))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==0)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==1)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==1)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==3)))||((((int)now.recipient[3])==3)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==5)))||((((int)now.recipient[3])==5)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==6)))||((((int)now.recipient[3])==6)&&(((int)now.sender[3])==1))), "(((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1)))", II, tt, t);
		/* merge: state[3] = 1(375, 265, 375) */
		reached[0][265] = 1;
		(trpt+1)->bup.ovals[1] = now.state[3];
		now.state[3] = 1;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: .(goto)(375, 268, 375) */
		reached[0][268] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 95: // STATE 270 - hybrid.pml:107 - [((state[5]==Received))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][270] = 1;
		if (!((now.state[5]==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 96: // STATE 271 - hybrid.pml:48 - [assert((state[5]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][271] = 1;
		spin_assert((now.state[5]==3), "(state[5]==3)", II, tt, t);
		/* merge: reply_to[5] = 5(375, 272, 375) */
		reached[0][272] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[5]);
		now.reply_to[5] = 5;
#ifdef VAR_RANGES
		logval("reply_to[5]", ((int)now.reply_to[5]));
#endif
		;
		/* merge: assert((reply_to[5]==5))(375, 273, 375) */
		reached[0][273] = 1;
		spin_assert((((int)now.reply_to[5])==5), "(reply_to[5]==5)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1))))(375, 274, 375) */
		reached[0][274] = 1;
		spin_assert((((((((((((((((((int)now.recipient[5])==0)&&(((int)now.sender[5])==1))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==0)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==1)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==1)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==3)))||((((int)now.recipient[5])==3)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==5)))||((((int)now.recipient[5])==5)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==6)))||((((int)now.recipient[5])==6)&&(((int)now.sender[5])==1))), "(((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1)))", II, tt, t);
		/* merge: state[5] = 2(375, 275, 375) */
		reached[0][275] = 1;
		(trpt+1)->bup.ovals[1] = now.state[5];
		now.state[5] = 2;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: .(goto)(375, 284, 375) */
		reached[0][284] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 97: // STATE 284 - hybrid.pml:107 - [.(goto)] (0:375:0 - 2)
		IfNotBlocked
		reached[0][284] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 98: // STATE 277 - hybrid.pml:48 - [assert((state[5]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][277] = 1;
		spin_assert((now.state[5]==3), "(state[5]==3)", II, tt, t);
		/* merge: reply_to[5] = 5(375, 278, 375) */
		reached[0][278] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[5]);
		now.reply_to[5] = 5;
#ifdef VAR_RANGES
		logval("reply_to[5]", ((int)now.reply_to[5]));
#endif
		;
		/* merge: assert((reply_to[5]==5))(375, 279, 375) */
		reached[0][279] = 1;
		spin_assert((((int)now.reply_to[5])==5), "(reply_to[5]==5)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1))))(375, 280, 375) */
		reached[0][280] = 1;
		spin_assert((((((((((((((((((int)now.recipient[5])==0)&&(((int)now.sender[5])==1))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==0)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==1)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==1)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==3)))||((((int)now.recipient[5])==3)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==5)))||((((int)now.recipient[5])==5)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==6)))||((((int)now.recipient[5])==6)&&(((int)now.sender[5])==1))), "(((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1)))", II, tt, t);
		/* merge: state[5] = 1(375, 281, 375) */
		reached[0][281] = 1;
		(trpt+1)->bup.ovals[1] = now.state[5];
		now.state[5] = 1;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: .(goto)(375, 284, 375) */
		reached[0][284] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 99: // STATE 286 - hybrid.pml:108 - [((state[6]==Received))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][286] = 1;
		if (!((now.state[6]==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 100: // STATE 287 - hybrid.pml:48 - [assert((state[6]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][287] = 1;
		spin_assert((now.state[6]==3), "(state[6]==3)", II, tt, t);
		/* merge: reply_to[6] = 6(375, 288, 375) */
		reached[0][288] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[6]);
		now.reply_to[6] = 6;
#ifdef VAR_RANGES
		logval("reply_to[6]", ((int)now.reply_to[6]));
#endif
		;
		/* merge: assert((reply_to[6]==6))(375, 289, 375) */
		reached[0][289] = 1;
		spin_assert((((int)now.reply_to[6])==6), "(reply_to[6]==6)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1))))(375, 290, 375) */
		reached[0][290] = 1;
		spin_assert((((((((((((((((((int)now.recipient[6])==0)&&(((int)now.sender[6])==1))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==0)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==1)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==1)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==3)))||((((int)now.recipient[6])==3)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==5)))||((((int)now.recipient[6])==5)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==6)))||((((int)now.recipient[6])==6)&&(((int)now.sender[6])==1))), "(((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1)))", II, tt, t);
		/* merge: state[6] = 2(375, 291, 375) */
		reached[0][291] = 1;
		(trpt+1)->bup.ovals[1] = now.state[6];
		now.state[6] = 2;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: .(goto)(375, 300, 375) */
		reached[0][300] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 101: // STATE 300 - hybrid.pml:108 - [.(goto)] (0:375:0 - 2)
		IfNotBlocked
		reached[0][300] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 102: // STATE 293 - hybrid.pml:48 - [assert((state[6]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][293] = 1;
		spin_assert((now.state[6]==3), "(state[6]==3)", II, tt, t);
		/* merge: reply_to[6] = 6(375, 294, 375) */
		reached[0][294] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[6]);
		now.reply_to[6] = 6;
#ifdef VAR_RANGES
		logval("reply_to[6]", ((int)now.reply_to[6]));
#endif
		;
		/* merge: assert((reply_to[6]==6))(375, 295, 375) */
		reached[0][295] = 1;
		spin_assert((((int)now.reply_to[6])==6), "(reply_to[6]==6)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1))))(375, 296, 375) */
		reached[0][296] = 1;
		spin_assert((((((((((((((((((int)now.recipient[6])==0)&&(((int)now.sender[6])==1))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==0)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==1)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==1)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==3)))||((((int)now.recipient[6])==3)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==5)))||((((int)now.recipient[6])==5)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==6)))||((((int)now.recipient[6])==6)&&(((int)now.sender[6])==1))), "(((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1)))", II, tt, t);
		/* merge: state[6] = 1(375, 297, 375) */
		reached[0][297] = 1;
		(trpt+1)->bup.ovals[1] = now.state[6];
		now.state[6] = 1;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: .(goto)(375, 300, 375) */
		reached[0][300] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 103: // STATE 302 - hybrid.pml:109 - [((state[7]==Received))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][302] = 1;
		if (!((now.state[7]==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 104: // STATE 303 - hybrid.pml:48 - [assert((state[7]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][303] = 1;
		spin_assert((now.state[7]==3), "(state[7]==3)", II, tt, t);
		/* merge: reply_to[7] = 7(375, 304, 375) */
		reached[0][304] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[7]);
		now.reply_to[7] = 7;
#ifdef VAR_RANGES
		logval("reply_to[7]", ((int)now.reply_to[7]));
#endif
		;
		/* merge: assert((reply_to[7]==7))(375, 305, 375) */
		reached[0][305] = 1;
		spin_assert((((int)now.reply_to[7])==7), "(reply_to[7]==7)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1))))(375, 306, 375) */
		reached[0][306] = 1;
		spin_assert((((((((((((((((((int)now.recipient[7])==0)&&(((int)now.sender[7])==1))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==0)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==1)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==1)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==3)))||((((int)now.recipient[7])==3)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==5)))||((((int)now.recipient[7])==5)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==6)))||((((int)now.recipient[7])==6)&&(((int)now.sender[7])==1))), "(((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1)))", II, tt, t);
		/* merge: state[7] = 2(375, 307, 375) */
		reached[0][307] = 1;
		(trpt+1)->bup.ovals[1] = now.state[7];
		now.state[7] = 2;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: .(goto)(375, 316, 375) */
		reached[0][316] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 105: // STATE 316 - hybrid.pml:109 - [.(goto)] (0:375:0 - 2)
		IfNotBlocked
		reached[0][316] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 106: // STATE 309 - hybrid.pml:48 - [assert((state[7]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][309] = 1;
		spin_assert((now.state[7]==3), "(state[7]==3)", II, tt, t);
		/* merge: reply_to[7] = 7(375, 310, 375) */
		reached[0][310] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[7]);
		now.reply_to[7] = 7;
#ifdef VAR_RANGES
		logval("reply_to[7]", ((int)now.reply_to[7]));
#endif
		;
		/* merge: assert((reply_to[7]==7))(375, 311, 375) */
		reached[0][311] = 1;
		spin_assert((((int)now.reply_to[7])==7), "(reply_to[7]==7)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1))))(375, 312, 375) */
		reached[0][312] = 1;
		spin_assert((((((((((((((((((int)now.recipient[7])==0)&&(((int)now.sender[7])==1))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==0)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==1)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==1)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==3)))||((((int)now.recipient[7])==3)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==5)))||((((int)now.recipient[7])==5)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==6)))||((((int)now.recipient[7])==6)&&(((int)now.sender[7])==1))), "(((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1)))", II, tt, t);
		/* merge: state[7] = 1(375, 313, 375) */
		reached[0][313] = 1;
		(trpt+1)->bup.ovals[1] = now.state[7];
		now.state[7] = 1;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: .(goto)(375, 316, 375) */
		reached[0][316] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 107: // STATE 318 - hybrid.pml:114 - [((((state[0]==Received)&&((state[1]==Succeeded)&&(state[2]==Succeeded)))&&(state[7]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][318] = 1;
		if (!((((now.state[0]==3)&&((now.state[1]==2)&&(now.state[2]==2)))&&(now.state[7]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 108: // STATE 319 - hybrid.pml:33 - [assert((state[7]==Absent))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][319] = 1;
		spin_assert((now.state[7]==5), "(state[7]==5)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 109: // STATE 320 - hybrid.pml:35 - [((7==4))] (331:0:1 - 1)
		IfNotBlocked
		reached[0][320] = 1;
		if (!((7==4)))
			continue;
		/* merge: recipient[7] = 6(331, 321, 331) */
		reached[0][321] = 1;
		(trpt+1)->bup.oval = ((int)now.recipient[7]);
		now.recipient[7] = 6;
#ifdef VAR_RANGES
		logval("recipient[7]", ((int)now.recipient[7]));
#endif
		;
		/* merge: .(goto)(331, 325, 331) */
		reached[0][325] = 1;
		;
		/* merge: assert((((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1))))(331, 326, 331) */
		reached[0][326] = 1;
		spin_assert((((((((((((((((((int)now.sender[7])==0)&&(((int)now.recipient[7])==1))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==0)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==1)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==1)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==3)))||((((int)now.sender[7])==3)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==5)))||((((int)now.sender[7])==5)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==6)))||((((int)now.sender[7])==6)&&(((int)now.recipient[7])==1))), "(((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1)))", II, tt, t);
		_m = 3; goto P999; /* 3 */
	case 110: // STATE 323 - hybrid.pml:35 - [(1)] (331:0:0 - 1)
		IfNotBlocked
		reached[0][323] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(331, 325, 331) */
		reached[0][325] = 1;
		;
		/* merge: assert((((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1))))(331, 326, 331) */
		reached[0][326] = 1;
		spin_assert((((((((((((((((((int)now.sender[7])==0)&&(((int)now.recipient[7])==1))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==0)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==1)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==1)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==3)))||((((int)now.sender[7])==3)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==5)))||((((int)now.sender[7])==5)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==6)))||((((int)now.sender[7])==6)&&(((int)now.recipient[7])==1))), "(((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1)))", II, tt, t);
		_m = 3; goto P999; /* 2 */
	case 111: // STATE 326 - hybrid.pml:37 - [assert((((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1))))] (0:331:0 - 3)
		IfNotBlocked
		reached[0][326] = 1;
		spin_assert((((((((((((((((((int)now.sender[7])==0)&&(((int)now.recipient[7])==1))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==0)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==1)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==1)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==3)))||((((int)now.sender[7])==3)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==5)))||((((int)now.sender[7])==5)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==6)))||((((int)now.sender[7])==6)&&(((int)now.recipient[7])==1))), "(((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 112: // STATE 327 - hybrid.pml:39 - [((7==7))] (375:0:2 - 1)
		IfNotBlocked
		reached[0][327] = 1;
		if (!((7==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(375, 328, 375) */
		reached[0][328] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(375, 332, 375) */
		reached[0][332] = 1;
		;
		/* merge: state[7] = Sent(375, 333, 375) */
		reached[0][333] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[7];
		now.state[7] = 4;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 334, 375) */
		reached[0][334] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 335, 375) */
		reached[0][335] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 113: // STATE 330 - hybrid.pml:40 - [(1)] (375:0:2 - 1)
		IfNotBlocked
		reached[0][330] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(375, 332, 375) */
		reached[0][332] = 1;
		;
		/* merge: state[7] = Sent(375, 333, 375) */
		reached[0][333] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[7];
		now.state[7] = 4;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 334, 375) */
		reached[0][334] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 335, 375) */
		reached[0][335] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 114: // STATE 333 - hybrid.pml:42 - [state[7] = Sent] (0:375:2 - 3)
		IfNotBlocked
		reached[0][333] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[7];
		now.state[7] = 4;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(375, 334, 375) */
		reached[0][334] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(375, 335, 375) */
		reached[0][335] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 115: // STATE 338 - hybrid.pml:115 - [(((((state[0]==Received)&&((state[1]==Succeeded)||(state[1]==Failed)))&&((state[2]==Succeeded)||(state[2]==Failed)))&&!(((state[1]==Succeeded)&&(state[2]==Succeeded)))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][338] = 1;
		if (!(((((now.state[0]==3)&&((now.state[1]==2)||(now.state[1]==1)))&&((now.state[2]==2)||(now.state[2]==1)))&& !(((now.state[1]==2)&&(now.state[2]==2))))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 116: // STATE 339 - hybrid.pml:48 - [assert((state[0]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][339] = 1;
		spin_assert((now.state[0]==3), "(state[0]==3)", II, tt, t);
		/* merge: reply_to[0] = 0(375, 340, 375) */
		reached[0][340] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[0]);
		now.reply_to[0] = 0;
#ifdef VAR_RANGES
		logval("reply_to[0]", ((int)now.reply_to[0]));
#endif
		;
		/* merge: assert((reply_to[0]==0))(375, 341, 375) */
		reached[0][341] = 1;
		spin_assert((((int)now.reply_to[0])==0), "(reply_to[0]==0)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))(375, 342, 375) */
		reached[0][342] = 1;
		spin_assert((((((((((((((((((int)now.recipient[0])==0)&&(((int)now.sender[0])==1))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==0)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==3)))||((((int)now.recipient[0])==3)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==5)))||((((int)now.recipient[0])==5)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==6)))||((((int)now.recipient[0])==6)&&(((int)now.sender[0])==1))), "(((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1)))", II, tt, t);
		/* merge: state[0] = 1(375, 343, 375) */
		reached[0][343] = 1;
		(trpt+1)->bup.ovals[1] = now.state[0];
		now.state[0] = 1;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 117: // STATE 346 - hybrid.pml:116 - [(((state[0]==Received)&&((state[7]==Succeeded)||(state[7]==Failed))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][346] = 1;
		if (!(((now.state[0]==3)&&((now.state[7]==2)||(now.state[7]==1)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 118: // STATE 347 - hybrid.pml:60 - [((state[7]==Succeeded))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][347] = 1;
		if (!((now.state[7]==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 119: // STATE 348 - hybrid.pml:48 - [assert((state[0]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][348] = 1;
		spin_assert((now.state[0]==3), "(state[0]==3)", II, tt, t);
		/* merge: reply_to[0] = 0(375, 349, 375) */
		reached[0][349] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[0]);
		now.reply_to[0] = 0;
#ifdef VAR_RANGES
		logval("reply_to[0]", ((int)now.reply_to[0]));
#endif
		;
		/* merge: assert((reply_to[0]==0))(375, 350, 375) */
		reached[0][350] = 1;
		spin_assert((((int)now.reply_to[0])==0), "(reply_to[0]==0)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))(375, 351, 375) */
		reached[0][351] = 1;
		spin_assert((((((((((((((((((int)now.recipient[0])==0)&&(((int)now.sender[0])==1))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==0)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==3)))||((((int)now.recipient[0])==3)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==5)))||((((int)now.recipient[0])==5)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==6)))||((((int)now.recipient[0])==6)&&(((int)now.sender[0])==1))), "(((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1)))", II, tt, t);
		/* merge: state[0] = 2(375, 352, 375) */
		reached[0][352] = 1;
		(trpt+1)->bup.ovals[1] = now.state[0];
		now.state[0] = 2;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: .(goto)(375, 362, 375) */
		reached[0][362] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 120: // STATE 362 - hybrid.pml:63 - [.(goto)] (0:375:0 - 2)
		IfNotBlocked
		reached[0][362] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 121: // STATE 354 - hybrid.pml:61 - [((state[7]==Failed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][354] = 1;
		if (!((now.state[7]==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 122: // STATE 355 - hybrid.pml:48 - [assert((state[0]==Received))] (0:375:2 - 1)
		IfNotBlocked
		reached[0][355] = 1;
		spin_assert((now.state[0]==3), "(state[0]==3)", II, tt, t);
		/* merge: reply_to[0] = 0(375, 356, 375) */
		reached[0][356] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[0]);
		now.reply_to[0] = 0;
#ifdef VAR_RANGES
		logval("reply_to[0]", ((int)now.reply_to[0]));
#endif
		;
		/* merge: assert((reply_to[0]==0))(375, 357, 375) */
		reached[0][357] = 1;
		spin_assert((((int)now.reply_to[0])==0), "(reply_to[0]==0)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))(375, 358, 375) */
		reached[0][358] = 1;
		spin_assert((((((((((((((((((int)now.recipient[0])==0)&&(((int)now.sender[0])==1))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==0)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==3)))||((((int)now.recipient[0])==3)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==5)))||((((int)now.recipient[0])==5)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==6)))||((((int)now.recipient[0])==6)&&(((int)now.sender[0])==1))), "(((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1)))", II, tt, t);
		/* merge: state[0] = 1(375, 359, 375) */
		reached[0][359] = 1;
		(trpt+1)->bup.ovals[1] = now.state[0];
		now.state[0] = 1;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: .(goto)(375, 362, 375) */
		reached[0][362] = 1;
		;
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 123: // STATE 365 - hybrid.pml:121 - [((observer_reads<2))] (375:0:2 - 1)
		IfNotBlocked
		reached[0][365] = 1;
		if (!((((int)now.observer_reads)<2)))
			continue;
		/* merge: observed_dispatches = dispatches(375, 366, 375) */
		reached[0][366] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.observed_dispatches);
		now.observed_dispatches = ((int)now.dispatches);
#ifdef VAR_RANGES
		logval("observed_dispatches", ((int)now.observed_dispatches));
#endif
		;
		/* merge: observer_reads = (observer_reads+1)(375, 367, 375) */
		reached[0][367] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.observer_reads);
		now.observer_reads = (((int)now.observer_reads)+1);
#ifdef VAR_RANGES
		logval("observer_reads", ((int)now.observer_reads));
#endif
		;
		/* merge: assert((observed_dispatches==dispatches))(375, 368, 375) */
		reached[0][368] = 1;
		spin_assert((((int)now.observed_dispatches)==((int)now.dispatches)), "(observed_dispatches==dispatches)", II, tt, t);
		/* merge: .(goto)(0, 376, 375) */
		reached[0][376] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 124: // STATE 370 - hybrid.pml:133 - [(((state[0]==Succeeded)||(state[0]==Failed)))] (378:0:1 - 1)
		IfNotBlocked
		reached[0][370] = 1;
		if (!(((now.state[0]==2)||(now.state[0]==1))))
			continue;
		/* merge: assert(((state[0]!=Succeeded)||(((state[1]==Succeeded)&&(state[2]==Succeeded))&&(state[7]==Succeeded))))(378, 371, 378) */
		reached[0][371] = 1;
		spin_assert(((now.state[0]!=2)||(((now.state[1]==2)&&(now.state[2]==2))&&(now.state[7]==2))), "((state[0]!=2)||(((state[1]==2)&&(state[2]==2))&&(state[7]==2)))", II, tt, t);
		/* merge: done = 1(378, 372, 378) */
		reached[0][372] = 1;
		(trpt+1)->bup.oval = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: goto :b1(378, 373, 378) */
		reached[0][373] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 125: // STATE 378 - hybrid.pml:142 - [-end-] (0:0:0 - 2)
		IfNotBlocked
		reached[0][378] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

