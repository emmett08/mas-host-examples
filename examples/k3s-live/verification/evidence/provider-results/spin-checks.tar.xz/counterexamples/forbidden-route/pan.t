#ifdef PEG
struct T_SRC {
	char *fl; int ln;
} T_SRC[NTRANS];

void
tr_2_src(int m, char *file, int ln)
{	T_SRC[m].fl = file;
	T_SRC[m].ln = ln;
}

void
putpeg(int n, int m)
{	printf("%5d	trans %4d ", m, n);
	printf("%s:%d\n",
		T_SRC[n].fl, T_SRC[n].ln);
}
#endif

void
settable(void)
{	Trans *T;
	Trans *settr(int, int, int, int, int, char *, int, int, int);

	trans = (Trans ***) emalloc(3*sizeof(Trans **));

	/* proctype 1: choreography_settles */

	trans[1] = (Trans **) emalloc(7*sizeof(Trans *));

	trans[1][4]	= settr(381,0,3,1,0,".(goto)", 0, 2, 0);
	T = trans[1][3] = settr(380,0,0,0,0,"DO", 0, 2, 0);
	    T->nxt	= settr(380,0,1,0,0,"DO", 0, 2, 0);
	trans[1][1]	= settr(378,0,3,3,0,"(!(done))", 1, 2, 0);
	trans[1][2]	= settr(379,0,3,1,0,"goto T0_init", 0, 2, 0);
	trans[1][5]	= settr(382,0,6,1,0,"break", 0, 2, 0);
	trans[1][6]	= settr(383,0,0,4,4,"-end-", 0, 3500, 0);

	/* proctype 0: Choreography */

	trans[0] = (Trans **) emalloc(379*sizeof(Trans *));

	T = trans[ 0][44] = settr(43,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(43,2,1,0,0,"ATOMIC", 1, 2, 0);
	trans[0][1]	= settr(0,2,7,5,5,"i = 0", 1, 2, 0);
	trans[0][8]	= settr(7,2,7,1,0,".(goto)", 1, 2, 0);
	T = trans[0][7] = settr(6,2,0,0,0,"DO", 1, 2, 0);
	T = T->nxt	= settr(6,2,2,0,0,"DO", 1, 2, 0);
	    T->nxt	= settr(6,2,5,0,0,"DO", 1, 2, 0);
	trans[0][2]	= settr(1,2,7,6,6,"((i<8))", 1, 2, 0); /* m: 3 -> 7,0 */
	reached0[3] = 1;
	trans[0][3]	= settr(0,0,0,0,0,"state[i] = Absent",0,0,0);
	trans[0][4]	= settr(0,0,0,0,0,"i = (i+1)",0,0,0);
	trans[0][5]	= settr(4,2,10,2,0,"else", 1, 2, 0);
	trans[0][6]	= settr(5,2,10,1,0,"goto :b0", 1, 2, 0); /* m: 10 -> 0,43 */
	reached0[10] = 1;
	trans[0][9]	= settr(8,2,10,1,0,"break", 1, 2, 0);
	trans[0][10]	= settr(9,2,43,7,7,"sender[0] = 0", 1, 2, 0); /* m: 11 -> 0,43 */
	reached0[11] = 1;
	trans[0][11]	= settr(0,0,0,0,0,"recipient[0] = 1",0,0,0);
	trans[0][12]	= settr(0,0,0,0,0,"sender[1] = 1",0,0,0);
	trans[0][13]	= settr(0,0,0,0,0,"recipient[1] = 2",0,0,0);
	trans[0][14]	= settr(0,0,0,0,0,"sender[2] = 1",0,0,0);
	trans[0][15]	= settr(0,0,0,0,0,"recipient[2] = 4",0,0,0);
	trans[0][16]	= settr(0,0,0,0,0,"sender[3] = 2",0,0,0);
	trans[0][17]	= settr(0,0,0,0,0,"recipient[3] = 3",0,0,0);
	trans[0][18]	= settr(0,0,0,0,0,"sender[4] = 2",0,0,0);
	trans[0][19]	= settr(0,0,0,0,0,"recipient[4] = 4",0,0,0);
	trans[0][20]	= settr(0,0,0,0,0,"sender[5] = 4",0,0,0);
	trans[0][21]	= settr(0,0,0,0,0,"recipient[5] = 5",0,0,0);
	trans[0][22]	= settr(0,0,0,0,0,"sender[6] = 4",0,0,0);
	trans[0][23]	= settr(0,0,0,0,0,"recipient[6] = 5",0,0,0);
	trans[0][24]	= settr(0,0,0,0,0,"sender[7] = 1",0,0,0);
	trans[0][25]	= settr(0,0,0,0,0,"recipient[7] = 6",0,0,0);
	T = trans[ 0][43] = settr(42,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(42,0,26,0,0,"sub-sequence", 1, 2, 0);
	trans[0][26]	= settr(25,2,31,8,0,"assert((state[0]==Absent))", 1, 2, 0);
	T = trans[0][31] = settr(30,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(30,2,27,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(30,2,29,0,0,"IF", 1, 2, 0);
	trans[0][27]	= settr(26,2,38,9,9,"((0==4))", 1, 2, 0); /* m: 28 -> 38,0 */
	reached0[28] = 1;
	trans[0][28]	= settr(0,0,0,0,0,"recipient[0] = 6",0,0,0);
	trans[0][32]	= settr(31,2,33,1,0,".(goto)", 1, 2, 0); /* m: 33 -> 0,38 */
	reached0[33] = 1;
	trans[0][29]	= settr(28,2,30,2,0,"else", 1, 2, 0);
	trans[0][30]	= settr(29,2,38,10,10,"(1)", 1, 2, 0); /* m: 33 -> 38,0 */
	reached0[33] = 1;
	trans[0][33]	= settr(32,2,38,11,11,"assert((((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1))))", 1, 2, 0);
	T = trans[0][38] = settr(37,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(37,2,34,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(37,2,36,0,0,"IF", 1, 2, 0);
	trans[0][34]	= settr(33,0,375,12,12,"((0==7))", 1, 2, 0); /* m: 35 -> 375,0 */
	reached0[35] = 1;
	trans[0][35]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][39]	= settr(38,2,40,1,0,".(goto)", 1, 2, 0); /* m: 40 -> 0,375 */
	reached0[40] = 1;
	trans[0][36]	= settr(35,2,37,2,0,"else", 1, 2, 0);
	trans[0][37]	= settr(36,0,375,13,13,"(1)", 1, 2, 0); /* m: 40 -> 375,0 */
	reached0[40] = 1;
	trans[0][40]	= settr(39,0,375,14,14,"state[0] = Sent", 1, 2, 0); /* m: 41 -> 0,375 */
	reached0[41] = 1;
	trans[0][41]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][42]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	trans[0][376]	= settr(375,0,375,1,0,".(goto)", 0, 2, 0);
	T = trans[0][375] = settr(374,0,0,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,47,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,50,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,53,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,56,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,59,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,62,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,65,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,68,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,88,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,108,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,128,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,136,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,156,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,175,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,195,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,214,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,234,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,253,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,269,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,285,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,301,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,317,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,337,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,345,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,364,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(374,0,369,0,0,"DO", 0, 2, 0);
	    T->nxt	= settr(374,0,374,0,0,"DO", 0, 2, 0);
	T = trans[ 0][47] = settr(46,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(46,2,45,0,0,"ATOMIC", 1, 2, 0);
	trans[0][45]	= settr(44,0,375,15,15,"((state[0]==Sent))", 1, 2, 0); /* m: 46 -> 375,0 */
	reached0[46] = 1;
	trans[0][46]	= settr(0,0,0,0,0,"state[0] = Received",0,0,0);
	T = trans[ 0][50] = settr(49,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(49,2,48,0,0,"ATOMIC", 1, 2, 0);
	trans[0][48]	= settr(47,0,375,16,16,"((state[1]==Sent))", 1, 2, 0); /* m: 49 -> 375,0 */
	reached0[49] = 1;
	trans[0][49]	= settr(0,0,0,0,0,"state[1] = Received",0,0,0);
	T = trans[ 0][53] = settr(52,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(52,2,51,0,0,"ATOMIC", 1, 2, 0);
	trans[0][51]	= settr(50,0,375,17,17,"((state[2]==Sent))", 1, 2, 0); /* m: 52 -> 375,0 */
	reached0[52] = 1;
	trans[0][52]	= settr(0,0,0,0,0,"state[2] = Received",0,0,0);
	T = trans[ 0][56] = settr(55,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(55,2,54,0,0,"ATOMIC", 1, 2, 0);
	trans[0][54]	= settr(53,0,375,18,18,"((state[3]==Sent))", 1, 2, 0); /* m: 55 -> 375,0 */
	reached0[55] = 1;
	trans[0][55]	= settr(0,0,0,0,0,"state[3] = Received",0,0,0);
	T = trans[ 0][59] = settr(58,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(58,2,57,0,0,"ATOMIC", 1, 2, 0);
	trans[0][57]	= settr(56,0,375,19,19,"((state[4]==Sent))", 1, 2, 0); /* m: 58 -> 375,0 */
	reached0[58] = 1;
	trans[0][58]	= settr(0,0,0,0,0,"state[4] = Received",0,0,0);
	T = trans[ 0][62] = settr(61,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(61,2,60,0,0,"ATOMIC", 1, 2, 0);
	trans[0][60]	= settr(59,0,375,20,20,"((state[5]==Sent))", 1, 2, 0); /* m: 61 -> 375,0 */
	reached0[61] = 1;
	trans[0][61]	= settr(0,0,0,0,0,"state[5] = Received",0,0,0);
	T = trans[ 0][65] = settr(64,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(64,2,63,0,0,"ATOMIC", 1, 2, 0);
	trans[0][63]	= settr(62,0,375,21,21,"((state[6]==Sent))", 1, 2, 0); /* m: 64 -> 375,0 */
	reached0[64] = 1;
	trans[0][64]	= settr(0,0,0,0,0,"state[6] = Received",0,0,0);
	T = trans[ 0][68] = settr(67,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(67,2,66,0,0,"ATOMIC", 1, 2, 0);
	trans[0][66]	= settr(65,0,375,22,22,"((state[7]==Sent))", 1, 2, 0); /* m: 67 -> 375,0 */
	reached0[67] = 1;
	trans[0][67]	= settr(0,0,0,0,0,"state[7] = Received",0,0,0);
	T = trans[ 0][88] = settr(87,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(87,2,69,0,0,"ATOMIC", 1, 2, 0);
	trans[0][69]	= settr(68,2,87,23,0,"(((state[0]==Received)&&(state[1]==Absent)))", 1, 2, 0);
	T = trans[ 0][87] = settr(86,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(86,0,70,0,0,"sub-sequence", 1, 2, 0);
	trans[0][70]	= settr(69,2,75,24,0,"assert((state[1]==Absent))", 1, 2, 0);
	T = trans[0][75] = settr(74,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(74,2,71,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(74,2,73,0,0,"IF", 1, 2, 0);
	trans[0][71]	= settr(70,2,82,25,25,"((1==4))", 1, 2, 0); /* m: 72 -> 82,0 */
	reached0[72] = 1;
	trans[0][72]	= settr(0,0,0,0,0,"recipient[1] = 6",0,0,0);
	trans[0][76]	= settr(75,2,77,1,0,".(goto)", 1, 2, 0); /* m: 77 -> 0,82 */
	reached0[77] = 1;
	trans[0][73]	= settr(72,2,74,2,0,"else", 1, 2, 0);
	trans[0][74]	= settr(73,2,82,26,26,"(1)", 1, 2, 0); /* m: 77 -> 82,0 */
	reached0[77] = 1;
	trans[0][77]	= settr(76,2,82,27,27,"assert((((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1))))", 1, 2, 0);
	T = trans[0][82] = settr(81,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(81,2,78,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(81,2,80,0,0,"IF", 1, 2, 0);
	trans[0][78]	= settr(77,0,375,28,28,"((1==7))", 1, 2, 0); /* m: 79 -> 375,0 */
	reached0[79] = 1;
	trans[0][79]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][83]	= settr(82,2,84,1,0,".(goto)", 1, 2, 0); /* m: 84 -> 0,375 */
	reached0[84] = 1;
	trans[0][80]	= settr(79,2,81,2,0,"else", 1, 2, 0);
	trans[0][81]	= settr(80,0,375,29,29,"(1)", 1, 2, 0); /* m: 84 -> 375,0 */
	reached0[84] = 1;
	trans[0][84]	= settr(83,0,375,30,30,"state[1] = Sent", 1, 2, 0); /* m: 85 -> 0,375 */
	reached0[85] = 1;
	trans[0][85]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][86]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][108] = settr(107,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(107,2,89,0,0,"ATOMIC", 1, 2, 0);
	trans[0][89]	= settr(88,2,107,31,0,"(((state[0]==Received)&&(state[2]==Absent)))", 1, 2, 0);
	T = trans[ 0][107] = settr(106,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(106,0,90,0,0,"sub-sequence", 1, 2, 0);
	trans[0][90]	= settr(89,2,95,32,0,"assert((state[2]==Absent))", 1, 2, 0);
	T = trans[0][95] = settr(94,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(94,2,91,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(94,2,93,0,0,"IF", 1, 2, 0);
	trans[0][91]	= settr(90,2,102,33,33,"((2==4))", 1, 2, 0); /* m: 92 -> 102,0 */
	reached0[92] = 1;
	trans[0][92]	= settr(0,0,0,0,0,"recipient[2] = 6",0,0,0);
	trans[0][96]	= settr(95,2,97,1,0,".(goto)", 1, 2, 0); /* m: 97 -> 0,102 */
	reached0[97] = 1;
	trans[0][93]	= settr(92,2,94,2,0,"else", 1, 2, 0);
	trans[0][94]	= settr(93,2,102,34,34,"(1)", 1, 2, 0); /* m: 97 -> 102,0 */
	reached0[97] = 1;
	trans[0][97]	= settr(96,2,102,35,35,"assert((((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1))))", 1, 2, 0);
	T = trans[0][102] = settr(101,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(101,2,98,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(101,2,100,0,0,"IF", 1, 2, 0);
	trans[0][98]	= settr(97,0,375,36,36,"((2==7))", 1, 2, 0); /* m: 99 -> 375,0 */
	reached0[99] = 1;
	trans[0][99]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][103]	= settr(102,2,104,1,0,".(goto)", 1, 2, 0); /* m: 104 -> 0,375 */
	reached0[104] = 1;
	trans[0][100]	= settr(99,2,101,2,0,"else", 1, 2, 0);
	trans[0][101]	= settr(100,0,375,37,37,"(1)", 1, 2, 0); /* m: 104 -> 375,0 */
	reached0[104] = 1;
	trans[0][104]	= settr(103,0,375,38,38,"state[2] = Sent", 1, 2, 0); /* m: 105 -> 0,375 */
	reached0[105] = 1;
	trans[0][105]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][106]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][128] = settr(127,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(127,2,109,0,0,"ATOMIC", 1, 2, 0);
	trans[0][109]	= settr(108,2,127,39,0,"(((state[1]==Received)&&(state[3]==Absent)))", 1, 2, 0);
	T = trans[ 0][127] = settr(126,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(126,0,110,0,0,"sub-sequence", 1, 2, 0);
	trans[0][110]	= settr(109,2,115,40,0,"assert((state[3]==Absent))", 1, 2, 0);
	T = trans[0][115] = settr(114,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(114,2,111,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(114,2,113,0,0,"IF", 1, 2, 0);
	trans[0][111]	= settr(110,2,122,41,41,"((3==4))", 1, 2, 0); /* m: 112 -> 122,0 */
	reached0[112] = 1;
	trans[0][112]	= settr(0,0,0,0,0,"recipient[3] = 6",0,0,0);
	trans[0][116]	= settr(115,2,117,1,0,".(goto)", 1, 2, 0); /* m: 117 -> 0,122 */
	reached0[117] = 1;
	trans[0][113]	= settr(112,2,114,2,0,"else", 1, 2, 0);
	trans[0][114]	= settr(113,2,122,42,42,"(1)", 1, 2, 0); /* m: 117 -> 122,0 */
	reached0[117] = 1;
	trans[0][117]	= settr(116,2,122,43,43,"assert((((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1))))", 1, 2, 0);
	T = trans[0][122] = settr(121,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(121,2,118,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(121,2,120,0,0,"IF", 1, 2, 0);
	trans[0][118]	= settr(117,0,375,44,44,"((3==7))", 1, 2, 0); /* m: 119 -> 375,0 */
	reached0[119] = 1;
	trans[0][119]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][123]	= settr(122,2,124,1,0,".(goto)", 1, 2, 0); /* m: 124 -> 0,375 */
	reached0[124] = 1;
	trans[0][120]	= settr(119,2,121,2,0,"else", 1, 2, 0);
	trans[0][121]	= settr(120,0,375,45,45,"(1)", 1, 2, 0); /* m: 124 -> 375,0 */
	reached0[124] = 1;
	trans[0][124]	= settr(123,0,375,46,46,"state[3] = Sent", 1, 2, 0); /* m: 125 -> 0,375 */
	reached0[125] = 1;
	trans[0][125]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][126]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][136] = settr(135,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(135,2,129,0,0,"ATOMIC", 1, 2, 0);
	trans[0][129]	= settr(128,2,135,47,0,"(((state[1]==Received)&&(state[3]==Failed)))", 1, 2, 0);
	T = trans[ 0][135] = settr(134,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(134,0,130,0,0,"sub-sequence", 1, 2, 0);
	trans[0][130]	= settr(129,0,375,48,48,"assert((state[1]==Received))", 1, 2, 0); /* m: 131 -> 0,375 */
	reached0[131] = 1;
	trans[0][131]	= settr(0,0,0,0,0,"reply_to[1] = 1",0,0,0);
	trans[0][132]	= settr(0,0,0,0,0,"assert((reply_to[1]==1))",0,0,0);
	trans[0][133]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))",0,0,0);
	trans[0][134]	= settr(0,0,0,0,0,"state[1] = 1",0,0,0);
	T = trans[ 0][156] = settr(155,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(155,2,137,0,0,"ATOMIC", 1, 2, 0);
	trans[0][137]	= settr(136,2,155,49,0,"((((state[1]==Received)&&(state[3]==Succeeded))&&(state[4]==Absent)))", 1, 2, 0);
	T = trans[ 0][155] = settr(154,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(154,0,138,0,0,"sub-sequence", 1, 2, 0);
	trans[0][138]	= settr(137,2,143,50,0,"assert((state[4]==Absent))", 1, 2, 0);
	T = trans[0][143] = settr(142,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(142,2,139,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(142,2,141,0,0,"IF", 1, 2, 0);
	trans[0][139]	= settr(138,2,150,51,51,"((4==4))", 1, 2, 0); /* m: 140 -> 150,0 */
	reached0[140] = 1;
	trans[0][140]	= settr(0,0,0,0,0,"recipient[4] = 6",0,0,0);
	trans[0][144]	= settr(143,2,145,1,0,".(goto)", 1, 2, 0); /* m: 145 -> 0,150 */
	reached0[145] = 1;
	trans[0][141]	= settr(140,2,142,2,0,"else", 1, 2, 0);
	trans[0][142]	= settr(141,2,150,52,52,"(1)", 1, 2, 0); /* m: 145 -> 150,0 */
	reached0[145] = 1;
	trans[0][145]	= settr(144,2,150,53,53,"assert((((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1))))", 1, 2, 0);
	T = trans[0][150] = settr(149,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(149,2,146,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(149,2,148,0,0,"IF", 1, 2, 0);
	trans[0][146]	= settr(145,0,375,54,54,"((4==7))", 1, 2, 0); /* m: 147 -> 375,0 */
	reached0[147] = 1;
	trans[0][147]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][151]	= settr(150,2,152,1,0,".(goto)", 1, 2, 0); /* m: 152 -> 0,375 */
	reached0[152] = 1;
	trans[0][148]	= settr(147,2,149,2,0,"else", 1, 2, 0);
	trans[0][149]	= settr(148,0,375,55,55,"(1)", 1, 2, 0); /* m: 152 -> 375,0 */
	reached0[152] = 1;
	trans[0][152]	= settr(151,0,375,56,56,"state[4] = Sent", 1, 2, 0); /* m: 153 -> 0,375 */
	reached0[153] = 1;
	trans[0][153]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][154]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][175] = settr(174,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(174,2,157,0,0,"ATOMIC", 1, 2, 0);
	trans[0][157]	= settr(156,2,174,57,0,"(((state[1]==Received)&&((state[4]==Succeeded)||(state[4]==Failed))))", 1, 2, 0);
	T = trans[ 0][174] = settr(173,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(173,0,172,0,0,"sub-sequence", 1, 2, 0);
	T = trans[0][172] = settr(171,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(171,2,158,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(171,2,165,0,0,"IF", 1, 2, 0);
	trans[0][158]	= settr(157,2,164,58,0,"((state[4]==Succeeded))", 1, 2, 0);
	T = trans[ 0][164] = settr(163,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(163,0,159,0,0,"sub-sequence", 1, 2, 0);
	trans[0][159]	= settr(158,0,375,59,59,"assert((state[1]==Received))", 1, 2, 0); /* m: 160 -> 0,375 */
	reached0[160] = 1;
	trans[0][160]	= settr(0,0,0,0,0,"reply_to[1] = 1",0,0,0);
	trans[0][161]	= settr(0,0,0,0,0,"assert((reply_to[1]==1))",0,0,0);
	trans[0][162]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))",0,0,0);
	trans[0][163]	= settr(0,0,0,0,0,"state[1] = 2",0,0,0);
	trans[0][173]	= settr(172,0,375,60,60,".(goto)", 1, 2, 0);
	trans[0][165]	= settr(164,2,171,61,0,"((state[4]==Failed))", 1, 2, 0);
	T = trans[ 0][171] = settr(170,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(170,0,166,0,0,"sub-sequence", 1, 2, 0);
	trans[0][166]	= settr(165,0,375,62,62,"assert((state[1]==Received))", 1, 2, 0); /* m: 167 -> 0,375 */
	reached0[167] = 1;
	trans[0][167]	= settr(0,0,0,0,0,"reply_to[1] = 1",0,0,0);
	trans[0][168]	= settr(0,0,0,0,0,"assert((reply_to[1]==1))",0,0,0);
	trans[0][169]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))",0,0,0);
	trans[0][170]	= settr(0,0,0,0,0,"state[1] = 1",0,0,0);
	T = trans[ 0][195] = settr(194,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(194,2,176,0,0,"ATOMIC", 1, 2, 0);
	trans[0][176]	= settr(175,2,194,63,0,"(((state[2]==Received)&&(state[5]==Absent)))", 1, 2, 0);
	T = trans[ 0][194] = settr(193,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(193,0,177,0,0,"sub-sequence", 1, 2, 0);
	trans[0][177]	= settr(176,2,182,64,0,"assert((state[5]==Absent))", 1, 2, 0);
	T = trans[0][182] = settr(181,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(181,2,178,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(181,2,180,0,0,"IF", 1, 2, 0);
	trans[0][178]	= settr(177,2,189,65,65,"((5==4))", 1, 2, 0); /* m: 179 -> 189,0 */
	reached0[179] = 1;
	trans[0][179]	= settr(0,0,0,0,0,"recipient[5] = 6",0,0,0);
	trans[0][183]	= settr(182,2,184,1,0,".(goto)", 1, 2, 0); /* m: 184 -> 0,189 */
	reached0[184] = 1;
	trans[0][180]	= settr(179,2,181,2,0,"else", 1, 2, 0);
	trans[0][181]	= settr(180,2,189,66,66,"(1)", 1, 2, 0); /* m: 184 -> 189,0 */
	reached0[184] = 1;
	trans[0][184]	= settr(183,2,189,67,67,"assert((((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1))))", 1, 2, 0);
	T = trans[0][189] = settr(188,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(188,2,185,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(188,2,187,0,0,"IF", 1, 2, 0);
	trans[0][185]	= settr(184,0,375,68,68,"((5==7))", 1, 2, 0); /* m: 186 -> 375,0 */
	reached0[186] = 1;
	trans[0][186]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][190]	= settr(189,2,191,1,0,".(goto)", 1, 2, 0); /* m: 191 -> 0,375 */
	reached0[191] = 1;
	trans[0][187]	= settr(186,2,188,2,0,"else", 1, 2, 0);
	trans[0][188]	= settr(187,0,375,69,69,"(1)", 1, 2, 0); /* m: 191 -> 375,0 */
	reached0[191] = 1;
	trans[0][191]	= settr(190,0,375,70,70,"state[5] = Sent", 1, 2, 0); /* m: 192 -> 0,375 */
	reached0[192] = 1;
	trans[0][192]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][193]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][214] = settr(213,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(213,2,196,0,0,"ATOMIC", 1, 2, 0);
	trans[0][196]	= settr(195,2,213,71,0,"(((state[2]==Received)&&((state[5]==Succeeded)||(state[5]==Failed))))", 1, 2, 0);
	T = trans[ 0][213] = settr(212,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(212,0,211,0,0,"sub-sequence", 1, 2, 0);
	T = trans[0][211] = settr(210,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(210,2,197,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(210,2,204,0,0,"IF", 1, 2, 0);
	trans[0][197]	= settr(196,2,203,72,0,"((state[5]==Succeeded))", 1, 2, 0);
	T = trans[ 0][203] = settr(202,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(202,0,198,0,0,"sub-sequence", 1, 2, 0);
	trans[0][198]	= settr(197,0,375,73,73,"assert((state[2]==Received))", 1, 2, 0); /* m: 199 -> 0,375 */
	reached0[199] = 1;
	trans[0][199]	= settr(0,0,0,0,0,"reply_to[2] = 2",0,0,0);
	trans[0][200]	= settr(0,0,0,0,0,"assert((reply_to[2]==2))",0,0,0);
	trans[0][201]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1))))",0,0,0);
	trans[0][202]	= settr(0,0,0,0,0,"state[2] = 2",0,0,0);
	trans[0][212]	= settr(211,0,375,74,74,".(goto)", 1, 2, 0);
	trans[0][204]	= settr(203,2,210,75,0,"((state[5]==Failed))", 1, 2, 0);
	T = trans[ 0][210] = settr(209,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(209,0,205,0,0,"sub-sequence", 1, 2, 0);
	trans[0][205]	= settr(204,0,375,76,76,"assert((state[2]==Received))", 1, 2, 0); /* m: 206 -> 0,375 */
	reached0[206] = 1;
	trans[0][206]	= settr(0,0,0,0,0,"reply_to[2] = 2",0,0,0);
	trans[0][207]	= settr(0,0,0,0,0,"assert((reply_to[2]==2))",0,0,0);
	trans[0][208]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1))))",0,0,0);
	trans[0][209]	= settr(0,0,0,0,0,"state[2] = 1",0,0,0);
	T = trans[ 0][234] = settr(233,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(233,2,215,0,0,"ATOMIC", 1, 2, 0);
	trans[0][215]	= settr(214,2,233,77,0,"(((state[4]==Received)&&(state[6]==Absent)))", 1, 2, 0);
	T = trans[ 0][233] = settr(232,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(232,0,216,0,0,"sub-sequence", 1, 2, 0);
	trans[0][216]	= settr(215,2,221,78,0,"assert((state[6]==Absent))", 1, 2, 0);
	T = trans[0][221] = settr(220,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(220,2,217,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(220,2,219,0,0,"IF", 1, 2, 0);
	trans[0][217]	= settr(216,2,228,79,79,"((6==4))", 1, 2, 0); /* m: 218 -> 228,0 */
	reached0[218] = 1;
	trans[0][218]	= settr(0,0,0,0,0,"recipient[6] = 6",0,0,0);
	trans[0][222]	= settr(221,2,223,1,0,".(goto)", 1, 2, 0); /* m: 223 -> 0,228 */
	reached0[223] = 1;
	trans[0][219]	= settr(218,2,220,2,0,"else", 1, 2, 0);
	trans[0][220]	= settr(219,2,228,80,80,"(1)", 1, 2, 0); /* m: 223 -> 228,0 */
	reached0[223] = 1;
	trans[0][223]	= settr(222,2,228,81,81,"assert((((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1))))", 1, 2, 0);
	T = trans[0][228] = settr(227,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(227,2,224,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(227,2,226,0,0,"IF", 1, 2, 0);
	trans[0][224]	= settr(223,0,375,82,82,"((6==7))", 1, 2, 0); /* m: 225 -> 375,0 */
	reached0[225] = 1;
	trans[0][225]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][229]	= settr(228,2,230,1,0,".(goto)", 1, 2, 0); /* m: 230 -> 0,375 */
	reached0[230] = 1;
	trans[0][226]	= settr(225,2,227,2,0,"else", 1, 2, 0);
	trans[0][227]	= settr(226,0,375,83,83,"(1)", 1, 2, 0); /* m: 230 -> 375,0 */
	reached0[230] = 1;
	trans[0][230]	= settr(229,0,375,84,84,"state[6] = Sent", 1, 2, 0); /* m: 231 -> 0,375 */
	reached0[231] = 1;
	trans[0][231]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][232]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][253] = settr(252,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(252,2,235,0,0,"ATOMIC", 1, 2, 0);
	trans[0][235]	= settr(234,2,252,85,0,"(((state[4]==Received)&&((state[6]==Succeeded)||(state[6]==Failed))))", 1, 2, 0);
	T = trans[ 0][252] = settr(251,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(251,0,250,0,0,"sub-sequence", 1, 2, 0);
	T = trans[0][250] = settr(249,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(249,2,236,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(249,2,243,0,0,"IF", 1, 2, 0);
	trans[0][236]	= settr(235,2,242,86,0,"((state[6]==Succeeded))", 1, 2, 0);
	T = trans[ 0][242] = settr(241,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(241,0,237,0,0,"sub-sequence", 1, 2, 0);
	trans[0][237]	= settr(236,0,375,87,87,"assert((state[4]==Received))", 1, 2, 0); /* m: 238 -> 0,375 */
	reached0[238] = 1;
	trans[0][238]	= settr(0,0,0,0,0,"reply_to[4] = 4",0,0,0);
	trans[0][239]	= settr(0,0,0,0,0,"assert((reply_to[4]==4))",0,0,0);
	trans[0][240]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1))))",0,0,0);
	trans[0][241]	= settr(0,0,0,0,0,"state[4] = 2",0,0,0);
	trans[0][251]	= settr(250,0,375,88,88,".(goto)", 1, 2, 0);
	trans[0][243]	= settr(242,2,249,89,0,"((state[6]==Failed))", 1, 2, 0);
	T = trans[ 0][249] = settr(248,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(248,0,244,0,0,"sub-sequence", 1, 2, 0);
	trans[0][244]	= settr(243,0,375,90,90,"assert((state[4]==Received))", 1, 2, 0); /* m: 245 -> 0,375 */
	reached0[245] = 1;
	trans[0][245]	= settr(0,0,0,0,0,"reply_to[4] = 4",0,0,0);
	trans[0][246]	= settr(0,0,0,0,0,"assert((reply_to[4]==4))",0,0,0);
	trans[0][247]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1))))",0,0,0);
	trans[0][248]	= settr(0,0,0,0,0,"state[4] = 1",0,0,0);
	T = trans[ 0][269] = settr(268,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(268,2,254,0,0,"ATOMIC", 1, 2, 0);
	trans[0][254]	= settr(253,2,267,91,0,"((state[3]==Received))", 1, 2, 0);
	T = trans[0][267] = settr(266,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(266,2,260,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(266,2,266,0,0,"IF", 1, 2, 0);
	T = trans[ 0][260] = settr(259,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(259,0,255,0,0,"sub-sequence", 1, 2, 0);
	trans[0][255]	= settr(254,0,375,92,92,"assert((state[3]==Received))", 1, 2, 0); /* m: 256 -> 0,375 */
	reached0[256] = 1;
	trans[0][256]	= settr(0,0,0,0,0,"reply_to[3] = 3",0,0,0);
	trans[0][257]	= settr(0,0,0,0,0,"assert((reply_to[3]==3))",0,0,0);
	trans[0][258]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1))))",0,0,0);
	trans[0][259]	= settr(0,0,0,0,0,"state[3] = 2",0,0,0);
	trans[0][268]	= settr(267,0,375,93,93,".(goto)", 1, 2, 0);
	T = trans[ 0][266] = settr(265,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(265,0,261,0,0,"sub-sequence", 1, 2, 0);
	trans[0][261]	= settr(260,0,375,94,94,"assert((state[3]==Received))", 1, 2, 0); /* m: 262 -> 0,375 */
	reached0[262] = 1;
	trans[0][262]	= settr(0,0,0,0,0,"reply_to[3] = 3",0,0,0);
	trans[0][263]	= settr(0,0,0,0,0,"assert((reply_to[3]==3))",0,0,0);
	trans[0][264]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1))))",0,0,0);
	trans[0][265]	= settr(0,0,0,0,0,"state[3] = 1",0,0,0);
	T = trans[ 0][285] = settr(284,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(284,2,270,0,0,"ATOMIC", 1, 2, 0);
	trans[0][270]	= settr(269,2,283,95,0,"((state[5]==Received))", 1, 2, 0);
	T = trans[0][283] = settr(282,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(282,2,276,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(282,2,282,0,0,"IF", 1, 2, 0);
	T = trans[ 0][276] = settr(275,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(275,0,271,0,0,"sub-sequence", 1, 2, 0);
	trans[0][271]	= settr(270,0,375,96,96,"assert((state[5]==Received))", 1, 2, 0); /* m: 272 -> 0,375 */
	reached0[272] = 1;
	trans[0][272]	= settr(0,0,0,0,0,"reply_to[5] = 5",0,0,0);
	trans[0][273]	= settr(0,0,0,0,0,"assert((reply_to[5]==5))",0,0,0);
	trans[0][274]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1))))",0,0,0);
	trans[0][275]	= settr(0,0,0,0,0,"state[5] = 2",0,0,0);
	trans[0][284]	= settr(283,0,375,97,97,".(goto)", 1, 2, 0);
	T = trans[ 0][282] = settr(281,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(281,0,277,0,0,"sub-sequence", 1, 2, 0);
	trans[0][277]	= settr(276,0,375,98,98,"assert((state[5]==Received))", 1, 2, 0); /* m: 278 -> 0,375 */
	reached0[278] = 1;
	trans[0][278]	= settr(0,0,0,0,0,"reply_to[5] = 5",0,0,0);
	trans[0][279]	= settr(0,0,0,0,0,"assert((reply_to[5]==5))",0,0,0);
	trans[0][280]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1))))",0,0,0);
	trans[0][281]	= settr(0,0,0,0,0,"state[5] = 1",0,0,0);
	T = trans[ 0][301] = settr(300,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(300,2,286,0,0,"ATOMIC", 1, 2, 0);
	trans[0][286]	= settr(285,2,299,99,0,"((state[6]==Received))", 1, 2, 0);
	T = trans[0][299] = settr(298,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(298,2,292,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(298,2,298,0,0,"IF", 1, 2, 0);
	T = trans[ 0][292] = settr(291,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(291,0,287,0,0,"sub-sequence", 1, 2, 0);
	trans[0][287]	= settr(286,0,375,100,100,"assert((state[6]==Received))", 1, 2, 0); /* m: 288 -> 0,375 */
	reached0[288] = 1;
	trans[0][288]	= settr(0,0,0,0,0,"reply_to[6] = 6",0,0,0);
	trans[0][289]	= settr(0,0,0,0,0,"assert((reply_to[6]==6))",0,0,0);
	trans[0][290]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1))))",0,0,0);
	trans[0][291]	= settr(0,0,0,0,0,"state[6] = 2",0,0,0);
	trans[0][300]	= settr(299,0,375,101,101,".(goto)", 1, 2, 0);
	T = trans[ 0][298] = settr(297,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(297,0,293,0,0,"sub-sequence", 1, 2, 0);
	trans[0][293]	= settr(292,0,375,102,102,"assert((state[6]==Received))", 1, 2, 0); /* m: 294 -> 0,375 */
	reached0[294] = 1;
	trans[0][294]	= settr(0,0,0,0,0,"reply_to[6] = 6",0,0,0);
	trans[0][295]	= settr(0,0,0,0,0,"assert((reply_to[6]==6))",0,0,0);
	trans[0][296]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1))))",0,0,0);
	trans[0][297]	= settr(0,0,0,0,0,"state[6] = 1",0,0,0);
	T = trans[ 0][317] = settr(316,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(316,2,302,0,0,"ATOMIC", 1, 2, 0);
	trans[0][302]	= settr(301,2,315,103,0,"((state[7]==Received))", 1, 2, 0);
	T = trans[0][315] = settr(314,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(314,2,308,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(314,2,314,0,0,"IF", 1, 2, 0);
	T = trans[ 0][308] = settr(307,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(307,0,303,0,0,"sub-sequence", 1, 2, 0);
	trans[0][303]	= settr(302,0,375,104,104,"assert((state[7]==Received))", 1, 2, 0); /* m: 304 -> 0,375 */
	reached0[304] = 1;
	trans[0][304]	= settr(0,0,0,0,0,"reply_to[7] = 7",0,0,0);
	trans[0][305]	= settr(0,0,0,0,0,"assert((reply_to[7]==7))",0,0,0);
	trans[0][306]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1))))",0,0,0);
	trans[0][307]	= settr(0,0,0,0,0,"state[7] = 2",0,0,0);
	trans[0][316]	= settr(315,0,375,105,105,".(goto)", 1, 2, 0);
	T = trans[ 0][314] = settr(313,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(313,0,309,0,0,"sub-sequence", 1, 2, 0);
	trans[0][309]	= settr(308,0,375,106,106,"assert((state[7]==Received))", 1, 2, 0); /* m: 310 -> 0,375 */
	reached0[310] = 1;
	trans[0][310]	= settr(0,0,0,0,0,"reply_to[7] = 7",0,0,0);
	trans[0][311]	= settr(0,0,0,0,0,"assert((reply_to[7]==7))",0,0,0);
	trans[0][312]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1))))",0,0,0);
	trans[0][313]	= settr(0,0,0,0,0,"state[7] = 1",0,0,0);
	T = trans[ 0][337] = settr(336,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(336,2,318,0,0,"ATOMIC", 1, 2, 0);
	trans[0][318]	= settr(317,2,336,107,0,"((((state[0]==Received)&&((state[1]==Succeeded)&&(state[2]==Succeeded)))&&(state[7]==Absent)))", 1, 2, 0);
	T = trans[ 0][336] = settr(335,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(335,0,319,0,0,"sub-sequence", 1, 2, 0);
	trans[0][319]	= settr(318,2,324,108,0,"assert((state[7]==Absent))", 1, 2, 0);
	T = trans[0][324] = settr(323,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(323,2,320,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(323,2,322,0,0,"IF", 1, 2, 0);
	trans[0][320]	= settr(319,2,331,109,109,"((7==4))", 1, 2, 0); /* m: 321 -> 331,0 */
	reached0[321] = 1;
	trans[0][321]	= settr(0,0,0,0,0,"recipient[7] = 6",0,0,0);
	trans[0][325]	= settr(324,2,326,1,0,".(goto)", 1, 2, 0); /* m: 326 -> 0,331 */
	reached0[326] = 1;
	trans[0][322]	= settr(321,2,323,2,0,"else", 1, 2, 0);
	trans[0][323]	= settr(322,2,331,110,110,"(1)", 1, 2, 0); /* m: 326 -> 331,0 */
	reached0[326] = 1;
	trans[0][326]	= settr(325,2,331,111,111,"assert((((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1))))", 1, 2, 0);
	T = trans[0][331] = settr(330,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(330,2,327,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(330,2,329,0,0,"IF", 1, 2, 0);
	trans[0][327]	= settr(326,0,375,112,112,"((7==7))", 1, 2, 0); /* m: 328 -> 375,0 */
	reached0[328] = 1;
	trans[0][328]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][332]	= settr(331,2,333,1,0,".(goto)", 1, 2, 0); /* m: 333 -> 0,375 */
	reached0[333] = 1;
	trans[0][329]	= settr(328,2,330,2,0,"else", 1, 2, 0);
	trans[0][330]	= settr(329,0,375,113,113,"(1)", 1, 2, 0); /* m: 333 -> 375,0 */
	reached0[333] = 1;
	trans[0][333]	= settr(332,0,375,114,114,"state[7] = Sent", 1, 2, 0); /* m: 334 -> 0,375 */
	reached0[334] = 1;
	trans[0][334]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][335]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][345] = settr(344,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(344,2,338,0,0,"ATOMIC", 1, 2, 0);
	trans[0][338]	= settr(337,2,344,115,0,"(((((state[0]==Received)&&((state[1]==Succeeded)||(state[1]==Failed)))&&((state[2]==Succeeded)||(state[2]==Failed)))&&!(((state[1]==Succeeded)&&(state[2]==Succeeded)))))", 1, 2, 0);
	T = trans[ 0][344] = settr(343,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(343,0,339,0,0,"sub-sequence", 1, 2, 0);
	trans[0][339]	= settr(338,0,375,116,116,"assert((state[0]==Received))", 1, 2, 0); /* m: 340 -> 0,375 */
	reached0[340] = 1;
	trans[0][340]	= settr(0,0,0,0,0,"reply_to[0] = 0",0,0,0);
	trans[0][341]	= settr(0,0,0,0,0,"assert((reply_to[0]==0))",0,0,0);
	trans[0][342]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))",0,0,0);
	trans[0][343]	= settr(0,0,0,0,0,"state[0] = 1",0,0,0);
	T = trans[ 0][364] = settr(363,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(363,2,346,0,0,"ATOMIC", 1, 2, 0);
	trans[0][346]	= settr(345,2,363,117,0,"(((state[0]==Received)&&((state[7]==Succeeded)||(state[7]==Failed))))", 1, 2, 0);
	T = trans[ 0][363] = settr(362,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(362,0,361,0,0,"sub-sequence", 1, 2, 0);
	T = trans[0][361] = settr(360,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(360,2,347,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(360,2,354,0,0,"IF", 1, 2, 0);
	trans[0][347]	= settr(346,2,353,118,0,"((state[7]==Succeeded))", 1, 2, 0);
	T = trans[ 0][353] = settr(352,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(352,0,348,0,0,"sub-sequence", 1, 2, 0);
	trans[0][348]	= settr(347,0,375,119,119,"assert((state[0]==Received))", 1, 2, 0); /* m: 349 -> 0,375 */
	reached0[349] = 1;
	trans[0][349]	= settr(0,0,0,0,0,"reply_to[0] = 0",0,0,0);
	trans[0][350]	= settr(0,0,0,0,0,"assert((reply_to[0]==0))",0,0,0);
	trans[0][351]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))",0,0,0);
	trans[0][352]	= settr(0,0,0,0,0,"state[0] = 2",0,0,0);
	trans[0][362]	= settr(361,0,375,120,120,".(goto)", 1, 2, 0);
	trans[0][354]	= settr(353,2,360,121,0,"((state[7]==Failed))", 1, 2, 0);
	T = trans[ 0][360] = settr(359,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(359,0,355,0,0,"sub-sequence", 1, 2, 0);
	trans[0][355]	= settr(354,0,375,122,122,"assert((state[0]==Received))", 1, 2, 0); /* m: 356 -> 0,375 */
	reached0[356] = 1;
	trans[0][356]	= settr(0,0,0,0,0,"reply_to[0] = 0",0,0,0);
	trans[0][357]	= settr(0,0,0,0,0,"assert((reply_to[0]==0))",0,0,0);
	trans[0][358]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))",0,0,0);
	trans[0][359]	= settr(0,0,0,0,0,"state[0] = 1",0,0,0);
	T = trans[ 0][369] = settr(368,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(368,2,365,0,0,"ATOMIC", 1, 2, 0);
	trans[0][365]	= settr(364,0,375,123,123,"((observer_reads<2))", 1, 2, 0); /* m: 366 -> 375,0 */
	reached0[366] = 1;
	trans[0][366]	= settr(0,0,0,0,0,"observed_dispatches = dispatches",0,0,0);
	trans[0][367]	= settr(0,0,0,0,0,"observer_reads = (observer_reads+1)",0,0,0);
	trans[0][368]	= settr(0,0,0,0,0,"assert((observed_dispatches==dispatches))",0,0,0);
	T = trans[ 0][374] = settr(373,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(373,2,370,0,0,"ATOMIC", 1, 2, 0);
	trans[0][370]	= settr(369,4,378,124,124,"(((state[0]==Succeeded)||(state[0]==Failed)))", 1, 2, 0); /* m: 371 -> 378,0 */
	reached0[371] = 1;
	trans[0][371]	= settr(0,0,0,0,0,"assert(((state[0]!=Succeeded)||(((state[1]==Succeeded)&&(state[2]==Succeeded))&&(state[7]==Succeeded))))",0,0,0);
	trans[0][372]	= settr(0,0,0,0,0,"done = 1",0,0,0);
	trans[0][373]	= settr(372,0,378,1,0,"goto :b1", 1, 2, 0);
	trans[0][377]	= settr(376,0,378,1,0,"break", 0, 2, 0);
	trans[0][378]	= settr(377,0,0,125,125,"-end-", 0, 3500, 0);
	/* np_ demon: */
	trans[_NP_] = (Trans **) emalloc(3*sizeof(Trans *));
	T = trans[_NP_][0] = settr(9997,0,1,_T5,0,"(np_)", 1,2,0);
	    T->nxt	  = settr(9998,0,0,_T2,0,"(1)",   0,2,0);
	T = trans[_NP_][1] = settr(9999,0,1,_T5,0,"(np_)", 1,2,0);
}

Trans *
settr(	int t_id, int a, int b, int c, int d,
	char *t, int g, int tpe0, int tpe1)
{	Trans *tmp = (Trans *) emalloc(sizeof(Trans));

	tmp->atom  = a&(6|32);	/* only (2|8|32) have meaning */
	if (!g) tmp->atom |= 8;	/* no global references */
	tmp->st    = b;
	tmp->tpe[0] = tpe0;
	tmp->tpe[1] = tpe1;
	tmp->tp    = t;
	tmp->t_id  = t_id;
	tmp->forw  = c;
	tmp->back  = d;
	return tmp;
}

Trans *
cpytr(Trans *a)
{	Trans *tmp = (Trans *) emalloc(sizeof(Trans));

	int i;
	tmp->atom  = a->atom;
	tmp->st    = a->st;
#ifdef HAS_UNLESS
	tmp->e_trans = a->e_trans;
	for (i = 0; i < HAS_UNLESS; i++)
		tmp->escp[i] = a->escp[i];
#endif
	tmp->tpe[0] = a->tpe[0];
	tmp->tpe[1] = a->tpe[1];
	for (i = 0; i < 6; i++)
	{	tmp->qu[i] = a->qu[i];
		tmp->ty[i] = a->ty[i];
	}
	tmp->tp    = (char *) emalloc(strlen(a->tp)+1);
	strcpy(tmp->tp, a->tp);
	tmp->t_id  = a->t_id;
	tmp->forw  = a->forw;
	tmp->back  = a->back;
	return tmp;
}

#ifndef NOREDUCE
int
srinc_set(int n)
{	if (n <= 2) return LOCAL;
	if (n <= 2+  DELTA) return Q_FULL_F; /* 's' or nfull  */
	if (n <= 2+2*DELTA) return Q_EMPT_F; /* 'r' or nempty */
	if (n <= 2+3*DELTA) return Q_EMPT_T; /* empty */
	if (n <= 2+4*DELTA) return Q_FULL_T; /* full  */
	if (n ==   5*DELTA) return GLOBAL;
	if (n ==   6*DELTA) return TIMEOUT_F;
	if (n ==   7*DELTA) return ALPHA_F;
	Uerror("cannot happen srinc_class");
	return BAD;
}
int
srunc(int n, int m)
{	switch(m) {
	case Q_FULL_F: return n-2;
	case Q_EMPT_F: return n-2-DELTA;
	case Q_EMPT_T: return n-2-2*DELTA;
	case Q_FULL_T: return n-2-3*DELTA;
	case ALPHA_F:
	case TIMEOUT_F: return 257; /* non-zero, and > MAXQ */
	}
	Uerror("cannot happen srunc");
	return 0;
}
#endif
int cnt;
#ifdef HAS_UNLESS
int
isthere(Trans *a, int b)
{	Trans *t;
	for (t = a; t; t = t->nxt)
		if (t->t_id == b)
			return 1;
	return 0;
}
#endif
#ifndef NOREDUCE
int
mark_safety(Trans *t) /* for conditional safety */
{	int g = 0, i, j, k;

	if (!t) return 0;
	if (t->qu[0])
		return (t->qu[1])?2:1;	/* marked */

	for (i = 0; i < 2; i++)
	{	j = srinc_set(t->tpe[i]);
		if (j >= GLOBAL && j != ALPHA_F)
			return -1;
		if (j != LOCAL)
		{	k = srunc(t->tpe[i], j);
			if (g == 0
			||  t->qu[0] != k
			||  t->ty[0] != j)
			{	t->qu[g] = k;
				t->ty[g] = j;
				g++;
	}	}	}
	return g;
}
#endif
void
retrans(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
	/* process n, with m states, is=initial state */
{	Trans *T0, *T1, *T2, *T3;
	Trans *T4, *T5; /* t_reverse or has_unless */
	int i;
#if defined(HAS_UNLESS) || !defined(NOREDUCE)
	int k;
#endif
#ifndef NOREDUCE
	int g, h, j, aa;
#endif
#ifdef HAS_UNLESS
	int p;
#endif
	if (state_tables >= 4)
	{	printf("STEP 1 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
	do {
		for (i = 1, cnt = 0; i < m; i++)
		{	T2 = trans[n][i];
			T1 = T2?T2->nxt:(Trans *)0;
/* prescan: */		for (T0 = T1; T0; T0 = T0->nxt)
/* choice in choice */	{	if (T0->st && trans[n][T0->st]
				&&  trans[n][T0->st]->nxt)
					break;
			}
#if 0
		if (T0)
		printf("\tstate %d / %d: choice in choice\n",
		i, T0->st);
#endif
			if (T0)
			for (T0 = T1; T0; T0 = T0->nxt)
			{	T3 = trans[n][T0->st];
				if (!T3->nxt)
				{	T2->nxt = cpytr(T0);
					T2 = T2->nxt;
					imed(T2, T0->st, n, i);
					continue;
				}
				do {	T3 = T3->nxt;
					T2->nxt = cpytr(T3);
					T2 = T2->nxt;
					imed(T2, T0->st, n, i);
				} while (T3->nxt);
				cnt++;
			}
		}
	} while (cnt);
	if (state_tables >= 3)
	{	printf("STEP 2 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
	for (i = 1; i < m; i++)
	{	if (trans[n][i] && trans[n][i]->nxt) /* optimize */
		{	T1 = trans[n][i]->nxt;
#if 0
			printf("\t\tpull %d (%d) to %d\n",
			T1->st, T1->forw, i);
#endif
			srcln[i] = srcln[T1->st];	/* Oyvind Teig, 5.2.0 */

			if (!trans[n][T1->st]) continue;
			T0 = cpytr(trans[n][T1->st]);
			trans[n][i] = T0;
			reach[T1->st] = 1;
			imed(T0, T1->st, n, i);
			for (T1 = T1->nxt; T1; T1 = T1->nxt)
			{
#if 0
			printf("\t\tpull %d (%d) to %d\n",
				T1->st, T1->forw, i);
#endif
		/*		srcln[i] = srcln[T1->st];  gh: not useful */
				if (!trans[n][T1->st]) continue;
				T0->nxt = cpytr(trans[n][T1->st]);
				T0 = T0->nxt;
				reach[T1->st] = 1;
				imed(T0, T1->st, n, i);
	}	}	}
	if (state_tables >= 2)
	{	printf("STEP 3 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
#ifdef HAS_UNLESS
	for (i = 1; i < m; i++)
	{	if (!trans[n][i]) continue;
		/* check for each state i if an
		 * escape to some state p is defined
		 * if so, copy and mark p's transitions
		 * and prepend them to the transition-
		 * list of state i
		 */
	 if (!like_java) /* the default */
	 {	for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		for (k = HAS_UNLESS-1; k >= 0; k--)
		{	if (p = T0->escp[k])
			for (T1 = trans[n][p]; T1; T1 = T1->nxt)
			{	if (isthere(trans[n][i], T1->t_id))
					continue;
				T2 = cpytr(T1);
				T2->e_trans = p;
				T2->nxt = trans[n][i];
				trans[n][i] = T2;
		}	}
	 } else /* outermost unless checked first */
	 {	T4 = T3 = (Trans *) 0;
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		for (k = HAS_UNLESS-1; k >= 0; k--)
		{	if (p = T0->escp[k])
			for (T1 = trans[n][p]; T1; T1 = T1->nxt)
			{	if (isthere(trans[n][i], T1->t_id))
					continue;
				T2 = cpytr(T1);
				T2->nxt = (Trans *) 0;
				T2->e_trans = p;
				if (T3)	T3->nxt = T2;
				else	T4 = T2;
				T3 = T2;
		}	}
		if (T4)
		{	T3->nxt = trans[n][i];
			trans[n][i] = T4;
		}
	 }
	}
#endif
#ifndef NOREDUCE
	for (i = 1; i < m; i++)
	{	if (a_cycles)
		{ /* moves through these states are visible */
	#if PROG_LAB>0 && defined(HAS_NP)
			if (progstate[n][i])
				goto degrade;
			for (T1 = trans[n][i]; T1; T1 = T1->nxt)
				if (progstate[n][T1->st])
					goto degrade;
	#endif
			if (accpstate[n][i] || visstate[n][i])
				goto degrade;
			for (T1 = trans[n][i]; T1; T1 = T1->nxt)
				if (accpstate[n][T1->st])
					goto degrade;
		}
		T1 = trans[n][i];
		if (!T1) continue;
		g = mark_safety(T1);	/* V3.3.1 */
		if (g < 0) goto degrade; /* global */
		/* check if mixing of guards preserves reduction */
		if (T1->nxt)
		{	k = 0;
			for (T0 = T1; T0; T0 = T0->nxt)
			{	if (!(T0->atom&8))
					goto degrade;
				for (aa = 0; aa < 2; aa++)
				{	j = srinc_set(T0->tpe[aa]);
					if (j >= GLOBAL && j != ALPHA_F)
						goto degrade;
					if (T0->tpe[aa]
					&&  T0->tpe[aa]
					!=  T1->tpe[0])
						k = 1;
			}	}
			/* g = 0;	V3.3.1 */
			if (k)	/* non-uniform selection */
			for (T0 = T1; T0; T0 = T0->nxt)
			for (aa = 0; aa < 2; aa++)
			{	j = srinc_set(T0->tpe[aa]);
				if (j != LOCAL)
				{	k = srunc(T0->tpe[aa], j);
					for (h = 0; h < 6; h++)
						if (T1->qu[h] == k
						&&  T1->ty[h] == j)
							break;
					if (h >= 6)
					{	T1->qu[g%6] = k;
						T1->ty[g%6] = j;
						g++;
			}	}	}
			if (g > 6)
			{	T1->qu[0] = 0;	/* turn it off */
				printf("pan: warning, line %d, ",
					srcln[i]);
			 	printf("too many stmnt types (%d)",
					g);
			  	printf(" in selection\n");
			  goto degrade;
			}
		}
		/* mark all options global if >=1 is global */
		for (T1 = trans[n][i]; T1; T1 = T1->nxt)
			if (!(T1->atom&8)) break;
		if (T1)
degrade:	for (T1 = trans[n][i]; T1; T1 = T1->nxt)
			T1->atom &= ~8;	/* mark as unsafe */
		/* can only mix 'r's or 's's if on same chan */
		/* and not mixed with other local operations */
		T1 = trans[n][i];
		if (!T1 || T1->qu[0]) continue;
		j = T1->tpe[0];
		if (T1->nxt && T1->atom&8)
		{ if (j == 5*DELTA)
		  {	printf("warning: line %d ", srcln[i]);
			printf("mixed condition ");
			printf("(defeats reduction)\n");
			goto degrade;
		  }
		  for (T0 = T1; T0; T0 = T0->nxt)
		  for (aa = 0; aa < 2; aa++)
		  if  (T0->tpe[aa] && T0->tpe[aa] != j)
		  {	printf("warning: line %d ", srcln[i]);
			printf("[%d-%d] mixed %stion ",
				T0->tpe[aa], j, 
				(j==5*DELTA)?"condi":"selec");
			printf("(defeats reduction)\n");
			printf("	'%s' <-> '%s'\n",
				T1->tp, T0->tp);
			goto degrade;
		} }
	}
#endif
	for (i = 1; i < m; i++)
	{	T2 = trans[n][i];
		if (!T2
		||  T2->nxt
		||  strncmp(T2->tp, ".(goto)", 7)
		||  !stopstate[n][i])
			continue;
		stopstate[n][T2->st] = 1;
	}
	if (state_tables && !verbose)
	{	if (dodot)
		{	char buf[256], *q = buf, *p = procname[n];
			while (*p != '\0')
			{	if (*p != ':')
				{	*q++ = *p;
				}
				p++;
			}
			*q = '\0';
			printf("digraph ");
			switch (Btypes[n]) {
			case I_PROC:  printf("init {\n"); break;
			case N_CLAIM: printf("claim_%s {\n", buf); break;
			case E_TRACE: printf("notrace {\n"); break;
			case N_TRACE: printf("trace {\n"); break;
			default:      printf("p_%s {\n", buf); break;
			}
			printf("size=\"8,10\";\n");
			printf("  GT [shape=box,style=dotted,label=\"%s\"];\n", buf);
			printf("  GT -> S%d;\n", is);
		} else
		{	switch (Btypes[n]) {
			case I_PROC:  printf("init\n"); break;
			case N_CLAIM: printf("claim %s\n", procname[n]); break;
			case E_TRACE: printf("notrace assertion\n"); break;
			case N_TRACE: printf("trace assertion\n"); break;
			default:      printf("proctype %s\n", procname[n]); break;
		}	}
		for (i = 1; i < m; i++)
		{	reach[i] = 1;
		}
		tagtable(n, m, is, srcln, reach);
		if (dodot) printf("}\n");
	} else
	for (i = 1; i < m; i++)
	{	int nrelse;
		if (Btypes[n] != N_CLAIM)
		{	for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			{	if (T0->st == i
				&& strcmp(T0->tp, "(1)") == 0)
				{	printf("error: proctype '%s' ",
						procname[n]);
		  			printf("line %d, state %d: has un",
						srcln[i], i);
					printf("conditional self-loop\n");
					pan_exit(1);
		}	}	}
		nrelse = 0;
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		{	if (strcmp(T0->tp, "else") == 0)
				nrelse++;
		}
		if (nrelse > 1)
		{	printf("error: proctype '%s' state",
				procname[n]);
		  	printf(" %d, inherits %d", i, nrelse);
		  	printf(" 'else' stmnts\n");
			pan_exit(1);
	}	}
#if !defined(LOOPSTATE) && !defined(BFS_PAR)
	if (state_tables)
#endif
	do_dfs(n, m, is, srcln, reach, lpstate);

	if (!t_reverse)
	{	return;
	}
	/* process n, with m states, is=initial state -- reverse list */
	if (!state_tables && Btypes[n] != N_CLAIM)
	{	for (i = 1; i < m; i++)
		{	Trans *Tx = (Trans *) 0; /* list of escapes */
			Trans *Ty = (Trans *) 0; /* its tail element */
			T1 = (Trans *) 0; /* reversed list */
			T2 = (Trans *) 0; /* its tail */
			T3 = (Trans *) 0; /* remembers possible 'else' */

			/* find unless-escapes, they should go first */
			T4 = T5 = T0 = trans[n][i];
	#ifdef HAS_UNLESS
			while (T4 && T4->e_trans) /* escapes are first in orig list */
			{	T5 = T4;	  /* remember predecessor */
				T4 = T4->nxt;
			}
	#endif
			/* T4 points to first non-escape, T5 to its parent, T0 to original list */
			if (T4 != T0)		 /* there was at least one escape */
			{	T3 = T5->nxt;		 /* start of non-escapes */
				T5->nxt = (Trans *) 0;	 /* separate */
				Tx = T0;		 /* start of the escapes */
				Ty = T5;		 /* its tail */
				T0 = T3;		 /* the rest, to be reversed */
			}
			/* T0 points to first non-escape, Tx to the list of escapes, Ty to its tail */

			/* first tail-add non-escape transitions, reversed */
			T3 = (Trans *) 0;
			for (T5 = T0; T5; T5 = T4)
			{	T4 = T5->nxt;
	#ifdef HAS_UNLESS
				if (T5->e_trans)
				{	printf("error: cannot happen!\n");
					continue;
				}
	#endif
				if (strcmp(T5->tp, "else") == 0)
				{	T3 = T5;
					T5->nxt = (Trans *) 0;
				} else
				{	T5->nxt = T1;
					if (!T1) { T2 = T5; }
					T1 = T5;
			}	}
			/* T3 points to a possible else, which is removed from the list */
			/* T1 points to the reversed list so far (without escapes) */
			/* T2 points to the tail element -- where the else should go */
			if (T2 && T3)
			{	T2->nxt = T3;	/* add else */
			} else
			{	if (T3) /* there was an else, but there's no tail */
				{	if (!T1)	/* and no reversed list */
					{	T1 = T3; /* odd, but possible */
					} else		/* even stranger */
					{	T1->nxt = T3;
			}	}	}

			/* add in the escapes, to that they appear at the front */
			if (Tx && Ty) { Ty->nxt = T1; T1 = Tx; }

			trans[n][i] = T1;
			/* reversed, with escapes first and else last */
	}	}
	if (state_tables && verbose)
	{	printf("FINAL proctype %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
	}
}
void
imed(Trans *T, int v, int n, int j)	/* set intermediate state */
{	progstate[n][T->st] |= progstate[n][v];
	accpstate[n][T->st] |= accpstate[n][v];
	stopstate[n][T->st] |= stopstate[n][v];
	mapstate[n][j] = T->st;
}
void
tagtable(int n, int m, int is, short srcln[], uchar reach[])
{	Trans *z;

	if (is >= m || !trans[n][is]
	||  is <= 0 || reach[is] == 0)
		return;
	reach[is] = 0;
	if (state_tables)
	for (z = trans[n][is]; z; z = z->nxt)
	{	if (dodot)
			dot_crack(n, is, z);
		else
			crack(n, is, z, srcln);
	}

	for (z = trans[n][is]; z; z = z->nxt)
	{
#ifdef HAS_UNLESS
		int i, j;
#endif
		tagtable(n, m, z->st, srcln, reach);
#ifdef HAS_UNLESS
		for (i = 0; i < HAS_UNLESS; i++)
		{	j = trans[n][is]->escp[i];
			if (!j) break;
			tagtable(n, m, j, srcln, reach);
		}
#endif
	}
}

extern Trans *t_id_lkup[];

void
dfs_table(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
{	Trans *z;

	if (is >= m || is <= 0 || !trans[n][is])
		return;
	if ((reach[is] & (4|8|16)) != 0)
	{	if ((reach[is] & (8|16)) == 16)	/* on stack, not yet recorded */
		{	lpstate[is] = 1;
			reach[is] |= 8; /* recorded */
			if (state_tables && verbose)
			{	printf("state %d line %d is a loopstate\n", is, srcln[is]);
		}	}
		return;
	}
	reach[is] |= (4|16);	/* visited | onstack */
	for (z = trans[n][is]; z; z = z->nxt)
	{	t_id_lkup[z->t_id] = z;
#ifdef HAS_UNLESS
		int i, j;
#endif
		dfs_table(n, m, z->st, srcln, reach, lpstate);
#ifdef HAS_UNLESS
		for (i = 0; i < HAS_UNLESS; i++)
		{	j = trans[n][is]->escp[i];
			if (!j) break;
			dfs_table(n, m, j, srcln, reach, lpstate);
		}
#endif
	}
	reach[is] &= ~16; /* no longer on stack */
}
void
do_dfs(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
{	int i;
	dfs_table(n, m, is, srcln, reach, lpstate);
	for (i = 0; i < m; i++)
		reach[i] &= ~(4|8|16);
}
void
crack(int n, int j, Trans *z, short srcln[])
{	int i;

	if (!z) return;
	printf("	state %3d -(tr %3d)-> state %3d  ",
		j, z->forw, z->st);
	printf("[id %3d tp %3d", z->t_id, z->tpe[0]);
	if (z->tpe[1]) printf(",%d", z->tpe[1]);
#ifdef HAS_UNLESS
	if (z->e_trans)
		printf(" org %3d", z->e_trans);
	else if (state_tables >= 2)
	for (i = 0; i < HAS_UNLESS; i++)
	{	if (!z->escp[i]) break;
		printf(" esc %d", z->escp[i]);
	}
#endif
	printf("]");
	printf(" [%s%s%s%s%s] %s:%d => ",
		z->atom&6?"A":z->atom&32?"D":"-",
		accpstate[n][j]?"a" :"-",
		stopstate[n][j]?"e" : "-",
		progstate[n][j]?"p" : "-",
		z->atom & 8 ?"L":"G",
		PanSource, srcln[j]);
	for (i = 0; z->tp[i]; i++)
		if (z->tp[i] == '\n')
			printf("\\n");
		else
			putchar(z->tp[i]);
	if (verbose && z->qu[0])
	{	printf("\t[");
		for (i = 0; i < 6; i++)
			if (z->qu[i])
				printf("(%d,%d)",
				z->qu[i], z->ty[i]);
		printf("]");
	}
	printf("\n");
	fflush(stdout);
}
/* spin -a m.pml; cc -o pan pan.c; ./pan -D | dot -Tps > foo.ps; ps2pdf foo.ps */
void
dot_crack(int n, int j, Trans *z)
{	int i;

	if (!z) return;
	printf("	S%d -> S%d  [color=black", j, z->st);

	if (z->atom&6) printf(",style=dashed");
	else if (z->atom&32) printf(",style=dotted");
	else if (z->atom&8) printf(",style=solid");
	else printf(",style=bold");

	printf(",label=\"");
	for (i = 0; z->tp[i]; i++)
	{	if (z->tp[i] == '\\'
		&&  z->tp[i+1] == 'n')
		{	i++; printf(" ");
		} else
		{	putchar(z->tp[i]);
	}	}
	printf("\"];\n");
	if (accpstate[n][j]) printf("  S%d [color=red,style=bold];\n", j);
	else if (progstate[n][j]) printf("  S%d [color=green,style=bold];\n", j);
	if (stopstate[n][j]) printf("  S%d [color=blue,style=bold,shape=box];\n", j);
}

#ifdef VAR_RANGES
#define BYTESIZE	32	/* 2^8 : 2^3 = 256:8 = 32 */

typedef struct Vr_Ptr {
	char	*nm;
	uchar	vals[BYTESIZE];
	struct Vr_Ptr *nxt;
} Vr_Ptr;
Vr_Ptr *ranges = (Vr_Ptr *) 0;

void
logval(char *s, int v)
{	Vr_Ptr *tmp;

	if (v<0 || v > 255) return;
	for (tmp = ranges; tmp; tmp = tmp->nxt)
		if (!strcmp(tmp->nm, s))
			goto found;
	tmp = (Vr_Ptr *) emalloc(sizeof(Vr_Ptr));
	tmp->nxt = ranges;
	ranges = tmp;
	tmp->nm = s;
found:
	tmp->vals[(v)/8] |= 1<<((v)%8);
}

void
dumpval(uchar X[], int range)
{	int w, x, i, j = -1;

	for (w = i = 0; w < range; w++)
	for (x = 0; x < 8; x++, i++)
	{
from:		if ((X[w] & (1<<x)))
		{	printf("%d", i);
			j = i;
			goto upto;
	}	}
	return;
	for (w = 0; w < range; w++)
	for (x = 0; x < 8; x++, i++)
	{
upto:		if (!(X[w] & (1<<x)))
		{	if (i-1 == j)
				printf(", ");
			else
				printf("-%d, ", i-1);
			goto from;
	}	}
	if (j >= 0 && j != 255)
		printf("-255");
}

void
dumpranges(void)
{	Vr_Ptr *tmp;
	printf("\nValues assigned within ");
	printf("interval [0..255]:\n");
	for (tmp = ranges; tmp; tmp = tmp->nxt)
	{	printf("\t%s\t: ", tmp->nm);
		dumpval(tmp->vals, BYTESIZE);
		printf("\n");
	}
}
#endif
