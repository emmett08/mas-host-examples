	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM choreography_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Choreography */

	case 5: // STATE 1
		;
		((P0 *)_this)->i = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 4
		;
		((P0 *)_this)->i = trpt->bup.ovals[1];
		now.state[ Index(((P0 *)_this)->i, 8) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 7: // STATE 25
		;
		now.recipient[7] = trpt->bup.ovals[15];
		now.sender[7] = trpt->bup.ovals[14];
		now.recipient[6] = trpt->bup.ovals[13];
		now.sender[6] = trpt->bup.ovals[12];
		now.recipient[5] = trpt->bup.ovals[11];
		now.sender[5] = trpt->bup.ovals[10];
		now.recipient[4] = trpt->bup.ovals[9];
		now.sender[4] = trpt->bup.ovals[8];
		now.recipient[3] = trpt->bup.ovals[7];
		now.sender[3] = trpt->bup.ovals[6];
		now.recipient[2] = trpt->bup.ovals[5];
		now.sender[2] = trpt->bup.ovals[4];
		now.recipient[1] = trpt->bup.ovals[3];
		now.sender[1] = trpt->bup.ovals[2];
		now.recipient[0] = trpt->bup.ovals[1];
		now.sender[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 16);
		goto R999;
;
		;
		
	case 9: // STATE 28
		;
		now.recipient[0] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 10: // STATE 30
		goto R999;
;
		
	case 11: // STATE 33
		goto R999;

	case 12: // STATE 41
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 13: // STATE 41
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 14: // STATE 41
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 15: // STATE 46
		;
		now.state[0] = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 49
		;
		now.state[1] = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 52
		;
		now.state[2] = trpt->bup.oval;
		;
		goto R999;

	case 18: // STATE 55
		;
		now.state[3] = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 58
		;
		now.state[4] = trpt->bup.oval;
		;
		goto R999;

	case 20: // STATE 61
		;
		now.state[5] = trpt->bup.oval;
		;
		goto R999;

	case 21: // STATE 64
		;
		now.state[6] = trpt->bup.oval;
		;
		goto R999;

	case 22: // STATE 67
		;
		now.state[7] = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 25: // STATE 72
		;
		now.recipient[1] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 26: // STATE 74
		goto R999;
;
		
	case 27: // STATE 77
		goto R999;

	case 28: // STATE 85
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 29: // STATE 85
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 30: // STATE 85
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 33: // STATE 92
		;
		now.recipient[2] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 34: // STATE 94
		goto R999;
;
		
	case 35: // STATE 97
		goto R999;

	case 36: // STATE 105
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 37: // STATE 105
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 38: // STATE 105
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 41: // STATE 112
		;
		now.recipient[3] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 42: // STATE 114
		goto R999;
;
		
	case 43: // STATE 117
		goto R999;

	case 44: // STATE 125
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 45: // STATE 125
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 46: // STATE 125
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 48: // STATE 134
		;
		now.state[1] = trpt->bup.ovals[1];
		now.reply_to[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 51: // STATE 140
		;
		now.recipient[4] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 52: // STATE 142
		goto R999;
;
		
	case 53: // STATE 145
		goto R999;

	case 54: // STATE 153
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 55: // STATE 153
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 56: // STATE 153
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 59: // STATE 163
		;
		now.state[1] = trpt->bup.ovals[1];
		now.reply_to[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 60: // STATE 173
		goto R999;
;
		;
		
	case 62: // STATE 170
		;
		now.state[1] = trpt->bup.ovals[1];
		now.reply_to[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 65: // STATE 179
		;
		now.recipient[5] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 66: // STATE 181
		goto R999;
;
		
	case 67: // STATE 184
		goto R999;

	case 68: // STATE 192
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 69: // STATE 192
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 70: // STATE 192
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 73: // STATE 202
		;
		now.state[2] = trpt->bup.ovals[1];
		now.reply_to[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 74: // STATE 212
		goto R999;
;
		;
		
	case 76: // STATE 209
		;
		now.state[2] = trpt->bup.ovals[1];
		now.reply_to[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 79: // STATE 218
		;
		now.recipient[6] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 80: // STATE 220
		goto R999;
;
		
	case 81: // STATE 223
		goto R999;

	case 82: // STATE 231
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 83: // STATE 231
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 84: // STATE 231
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 87: // STATE 241
		;
		now.state[4] = trpt->bup.ovals[1];
		now.reply_to[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 88: // STATE 251
		goto R999;
;
		;
		
	case 90: // STATE 248
		;
		now.state[4] = trpt->bup.ovals[1];
		now.reply_to[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 92: // STATE 259
		;
		now.state[3] = trpt->bup.ovals[1];
		now.reply_to[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 93: // STATE 268
		goto R999;

	case 94: // STATE 265
		;
		now.state[3] = trpt->bup.ovals[1];
		now.reply_to[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 96: // STATE 275
		;
		now.state[5] = trpt->bup.ovals[1];
		now.reply_to[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 97: // STATE 284
		goto R999;

	case 98: // STATE 281
		;
		now.state[5] = trpt->bup.ovals[1];
		now.reply_to[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 100: // STATE 291
		;
		now.state[6] = trpt->bup.ovals[1];
		now.reply_to[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 101: // STATE 300
		goto R999;

	case 102: // STATE 297
		;
		now.state[6] = trpt->bup.ovals[1];
		now.reply_to[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 104: // STATE 307
		;
		now.state[7] = trpt->bup.ovals[1];
		now.reply_to[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 105: // STATE 316
		goto R999;

	case 106: // STATE 313
		;
		now.state[7] = trpt->bup.ovals[1];
		now.reply_to[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 109: // STATE 321
		;
		now.recipient[7] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 110: // STATE 323
		goto R999;
;
		
	case 111: // STATE 326
		goto R999;

	case 112: // STATE 334
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 113: // STATE 334
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 114: // STATE 334
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 116: // STATE 343
		;
		now.state[0] = trpt->bup.ovals[1];
		now.reply_to[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 119: // STATE 352
		;
		now.state[0] = trpt->bup.ovals[1];
		now.reply_to[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 120: // STATE 362
		goto R999;
;
		;
		
	case 122: // STATE 359
		;
		now.state[0] = trpt->bup.ovals[1];
		now.reply_to[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 123: // STATE 367
		;
		now.observer_reads = trpt->bup.ovals[1];
		now.observed_dispatches = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 124: // STATE 372
		;
		now.done = trpt->bup.oval;
		;
		goto R999;

	case 125: // STATE 378
		;
		p_restor(II);
		;
		;
		goto R999;
	}

