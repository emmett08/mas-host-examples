	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM choreography_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Choreography */

	case 5: // STATE 1
		;
		((P0 *)_this)->i = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 4
		;
		((P0 *)_this)->i = trpt->bup.ovals[1];
		now.state[ Index(((P0 *)_this)->i, 8) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 7: // STATE 25
		;
		now.recipient[7] = trpt->bup.ovals[15];
		now.sender[7] = trpt->bup.ovals[14];
		now.recipient[6] = trpt->bup.ovals[13];
		now.sender[6] = trpt->bup.ovals[12];
		now.recipient[5] = trpt->bup.ovals[11];
		now.sender[5] = trpt->bup.ovals[10];
		now.recipient[4] = trpt->bup.ovals[9];
		now.sender[4] = trpt->bup.ovals[8];
		now.recipient[3] = trpt->bup.ovals[7];
		now.sender[3] = trpt->bup.ovals[6];
		now.recipient[2] = trpt->bup.ovals[5];
		now.sender[2] = trpt->bup.ovals[4];
		now.recipient[1] = trpt->bup.ovals[3];
		now.sender[1] = trpt->bup.ovals[2];
		now.recipient[0] = trpt->bup.ovals[1];
		now.sender[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 16);
		goto R999;
;
		
	case 8: // STATE 26
		goto R999;

	case 9: // STATE 35
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 10: // STATE 35
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 11: // STATE 35
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 12: // STATE 40
		;
		now.state[0] = trpt->bup.oval;
		;
		goto R999;

	case 13: // STATE 43
		;
		now.state[1] = trpt->bup.oval;
		;
		goto R999;

	case 14: // STATE 46
		;
		now.state[2] = trpt->bup.oval;
		;
		goto R999;

	case 15: // STATE 49
		;
		now.state[3] = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 52
		;
		now.state[4] = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 55
		;
		now.state[5] = trpt->bup.oval;
		;
		goto R999;

	case 18: // STATE 58
		;
		now.state[6] = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 61
		;
		now.state[7] = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		
	case 21: // STATE 64
		goto R999;

	case 22: // STATE 73
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 23: // STATE 73
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 24: // STATE 73
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		
	case 26: // STATE 78
		goto R999;

	case 27: // STATE 87
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 28: // STATE 87
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 29: // STATE 87
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		
	case 31: // STATE 92
		goto R999;

	case 32: // STATE 101
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 33: // STATE 101
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 34: // STATE 101
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 36: // STATE 110
		;
		now.state[1] = trpt->bup.ovals[1];
		now.reply_to[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		
	case 38: // STATE 114
		goto R999;

	case 39: // STATE 123
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 40: // STATE 123
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 41: // STATE 123
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 44: // STATE 133
		;
		now.state[1] = trpt->bup.ovals[1];
		now.reply_to[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 45: // STATE 143
		goto R999;
;
		;
		
	case 47: // STATE 140
		;
		now.state[1] = trpt->bup.ovals[1];
		now.reply_to[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		
	case 49: // STATE 147
		goto R999;

	case 50: // STATE 156
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 51: // STATE 156
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 52: // STATE 156
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 55: // STATE 166
		;
		now.state[2] = trpt->bup.ovals[1];
		now.reply_to[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 56: // STATE 176
		goto R999;
;
		;
		
	case 58: // STATE 173
		;
		now.state[2] = trpt->bup.ovals[1];
		now.reply_to[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		
	case 60: // STATE 180
		goto R999;

	case 61: // STATE 189
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 62: // STATE 189
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 63: // STATE 189
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 66: // STATE 199
		;
		now.state[4] = trpt->bup.ovals[1];
		now.reply_to[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 67: // STATE 209
		goto R999;
;
		;
		
	case 69: // STATE 206
		;
		now.state[4] = trpt->bup.ovals[1];
		now.reply_to[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 71: // STATE 217
		;
		now.state[3] = trpt->bup.ovals[1];
		now.reply_to[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 72: // STATE 226
		goto R999;

	case 73: // STATE 223
		;
		now.state[3] = trpt->bup.ovals[1];
		now.reply_to[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 75: // STATE 233
		;
		now.state[5] = trpt->bup.ovals[1];
		now.reply_to[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 76: // STATE 242
		goto R999;

	case 77: // STATE 239
		;
		now.state[5] = trpt->bup.ovals[1];
		now.reply_to[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 79: // STATE 249
		;
		now.state[6] = trpt->bup.ovals[1];
		now.reply_to[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 80: // STATE 258
		goto R999;

	case 81: // STATE 255
		;
		now.state[6] = trpt->bup.ovals[1];
		now.reply_to[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 83: // STATE 265
		;
		now.state[7] = trpt->bup.ovals[1];
		now.reply_to[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 84: // STATE 274
		goto R999;

	case 85: // STATE 271
		;
		now.state[7] = trpt->bup.ovals[1];
		now.reply_to[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		
	case 87: // STATE 277
		goto R999;

	case 88: // STATE 286
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 89: // STATE 286
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 90: // STATE 286
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 92: // STATE 295
		;
		now.state[0] = trpt->bup.ovals[1];
		now.reply_to[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 95: // STATE 304
		;
		now.state[0] = trpt->bup.ovals[1];
		now.reply_to[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 96: // STATE 314
		goto R999;
;
		;
		
	case 98: // STATE 311
		;
		now.state[0] = trpt->bup.ovals[1];
		now.reply_to[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 99: // STATE 319
		;
		now.observer_reads = trpt->bup.ovals[1];
		now.observed_dispatches = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 100: // STATE 324
		;
		now.done = trpt->bup.oval;
		;
		goto R999;

	case 101: // STATE 331
		;
		p_restor(II);
		;
		;
		goto R999;
	}

