#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM remediation_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(done))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][1] = 1;
		if (!( !(((int)now.done))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Remediation */
	case 5: // STATE 1 - remediation.pml:62 - [remediation_enabled = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)now.remediation_enabled);
		now.remediation_enabled = 1;
#ifdef VAR_RANGES
		logval("remediation_enabled", ((int)now.remediation_enabled));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - remediation.pml:62 - [remediation_enabled = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		(trpt+1)->bup.oval = ((int)now.remediation_enabled);
		now.remediation_enabled = 0;
#ifdef VAR_RANGES
		logval("remediation_enabled", ((int)now.remediation_enabled));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 6 - remediation.pml:62 - [evidence_valid = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][6] = 1;
		(trpt+1)->bup.oval = ((int)now.evidence_valid);
		now.evidence_valid = 1;
#ifdef VAR_RANGES
		logval("evidence_valid", ((int)now.evidence_valid));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 7 - remediation.pml:62 - [evidence_valid = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][7] = 1;
		(trpt+1)->bup.oval = ((int)now.evidence_valid);
		now.evidence_valid = 0;
#ifdef VAR_RANGES
		logval("evidence_valid", ((int)now.evidence_valid));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 11 - remediation.pml:62 - [proposal_allowed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][11] = 1;
		(trpt+1)->bup.oval = ((int)now.proposal_allowed);
		now.proposal_allowed = 1;
#ifdef VAR_RANGES
		logval("proposal_allowed", ((int)now.proposal_allowed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 10: // STATE 12 - remediation.pml:62 - [proposal_allowed = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][12] = 1;
		(trpt+1)->bup.oval = ((int)now.proposal_allowed);
		now.proposal_allowed = 0;
#ifdef VAR_RANGES
		logval("proposal_allowed", ((int)now.proposal_allowed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 16 - remediation.pml:62 - [namespace_uid_matches = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][16] = 1;
		(trpt+1)->bup.oval = ((int)now.namespace_uid_matches);
		now.namespace_uid_matches = 1;
#ifdef VAR_RANGES
		logval("namespace_uid_matches", ((int)now.namespace_uid_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 17 - remediation.pml:62 - [namespace_uid_matches = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][17] = 1;
		(trpt+1)->bup.oval = ((int)now.namespace_uid_matches);
		now.namespace_uid_matches = 0;
#ifdef VAR_RANGES
		logval("namespace_uid_matches", ((int)now.namespace_uid_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 21 - remediation.pml:62 - [observed_target_present = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][21] = 1;
		(trpt+1)->bup.oval = ((int)now.observed_target_present);
		now.observed_target_present = 1;
#ifdef VAR_RANGES
		logval("observed_target_present", ((int)now.observed_target_present));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 22 - remediation.pml:62 - [observed_target_present = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][22] = 1;
		(trpt+1)->bup.oval = ((int)now.observed_target_present);
		now.observed_target_present = 0;
#ifdef VAR_RANGES
		logval("observed_target_present", ((int)now.observed_target_present));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 15: // STATE 26 - remediation.pml:62 - [observed_uid_matches = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][26] = 1;
		(trpt+1)->bup.oval = ((int)now.observed_uid_matches);
		now.observed_uid_matches = 1;
#ifdef VAR_RANGES
		logval("observed_uid_matches", ((int)now.observed_uid_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 27 - remediation.pml:62 - [observed_uid_matches = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][27] = 1;
		(trpt+1)->bup.oval = ((int)now.observed_uid_matches);
		now.observed_uid_matches = 0;
#ifdef VAR_RANGES
		logval("observed_uid_matches", ((int)now.observed_uid_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 31 - remediation.pml:62 - [template_matches = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][31] = 1;
		(trpt+1)->bup.oval = ((int)now.template_matches);
		now.template_matches = 1;
#ifdef VAR_RANGES
		logval("template_matches", ((int)now.template_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 32 - remediation.pml:62 - [template_matches = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][32] = 1;
		(trpt+1)->bup.oval = ((int)now.template_matches);
		now.template_matches = 0;
#ifdef VAR_RANGES
		logval("template_matches", ((int)now.template_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 36 - remediation.pml:62 - [probe_matches = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][36] = 1;
		(trpt+1)->bup.oval = ((int)now.probe_matches);
		now.probe_matches = 1;
#ifdef VAR_RANGES
		logval("probe_matches", ((int)now.probe_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 37 - remediation.pml:62 - [probe_matches = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][37] = 1;
		(trpt+1)->bup.oval = ((int)now.probe_matches);
		now.probe_matches = 0;
#ifdef VAR_RANGES
		logval("probe_matches", ((int)now.probe_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 41 - remediation.pml:79 - [(!(remediation_enabled))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][41] = 1;
		if (!( !(((int)now.remediation_enabled))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 42 - remediation.pml:79 - [outcome = NotAttempted] (0:0:1 - 1)
		IfNotBlocked
		reached[0][42] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 14;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 43 - remediation.pml:80 - [((remediation_enabled&&!(evidence_valid)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][43] = 1;
		if (!((((int)now.remediation_enabled)&& !(((int)now.evidence_valid)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 44 - remediation.pml:80 - [outcome = Rejected] (0:0:1 - 1)
		IfNotBlocked
		reached[0][44] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 13;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 45 - remediation.pml:81 - [(((remediation_enabled&&evidence_valid)&&!(proposal_allowed)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][45] = 1;
		if (!(((((int)now.remediation_enabled)&&((int)now.evidence_valid))&& !(((int)now.proposal_allowed)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 26: // STATE 46 - remediation.pml:81 - [outcome = NotAttempted] (0:0:1 - 1)
		IfNotBlocked
		reached[0][46] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 14;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 27: // STATE 47 - remediation.pml:82 - [(((remediation_enabled&&evidence_valid)&&proposal_allowed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][47] = 1;
		if (!(((((int)now.remediation_enabled)&&((int)now.evidence_valid))&&((int)now.proposal_allowed))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 28: // STATE 48 - remediation.pml:84 - [((((((evidence_valid&&namespace_uid_matches)&&observed_target_present)&&observed_uid_matches)&&template_matches)&&probe_matches))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][48] = 1;
		if (!((((((((int)now.evidence_valid)&&((int)now.namespace_uid_matches))&&((int)now.observed_target_present))&&((int)now.observed_uid_matches))&&((int)now.template_matches))&&((int)now.probe_matches))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 29: // STATE 49 - remediation.pml:62 - [patch_target_present = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][49] = 1;
		(trpt+1)->bup.oval = ((int)now.patch_target_present);
		now.patch_target_present = 1;
#ifdef VAR_RANGES
		logval("patch_target_present", ((int)now.patch_target_present));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 30: // STATE 50 - remediation.pml:62 - [patch_target_present = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][50] = 1;
		(trpt+1)->bup.oval = ((int)now.patch_target_present);
		now.patch_target_present = 0;
#ifdef VAR_RANGES
		logval("patch_target_present", ((int)now.patch_target_present));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 54 - remediation.pml:62 - [patch_uid_matches = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][54] = 1;
		(trpt+1)->bup.oval = ((int)now.patch_uid_matches);
		now.patch_uid_matches = 1;
#ifdef VAR_RANGES
		logval("patch_uid_matches", ((int)now.patch_uid_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 55 - remediation.pml:62 - [patch_uid_matches = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][55] = 1;
		(trpt+1)->bup.oval = ((int)now.patch_uid_matches);
		now.patch_uid_matches = 0;
#ifdef VAR_RANGES
		logval("patch_uid_matches", ((int)now.patch_uid_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 59 - remediation.pml:62 - [resource_version_matches = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][59] = 1;
		(trpt+1)->bup.oval = ((int)now.resource_version_matches);
		now.resource_version_matches = 1;
#ifdef VAR_RANGES
		logval("resource_version_matches", ((int)now.resource_version_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 34: // STATE 60 - remediation.pml:62 - [resource_version_matches = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][60] = 1;
		(trpt+1)->bup.oval = ((int)now.resource_version_matches);
		now.resource_version_matches = 0;
#ifdef VAR_RANGES
		logval("resource_version_matches", ((int)now.resource_version_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 35: // STATE 64 - remediation.pml:62 - [api_accepts = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][64] = 1;
		(trpt+1)->bup.oval = ((int)now.api_accepts);
		now.api_accepts = 1;
#ifdef VAR_RANGES
		logval("api_accepts", ((int)now.api_accepts));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 36: // STATE 65 - remediation.pml:62 - [api_accepts = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][65] = 1;
		(trpt+1)->bup.oval = ((int)now.api_accepts);
		now.api_accepts = 0;
#ifdef VAR_RANGES
		logval("api_accepts", ((int)now.api_accepts));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 37: // STATE 69 - remediation.pml:96 - [effect_outcome = EffectUnknown] (0:0:1 - 3)
		IfNotBlocked
		reached[0][69] = 1;
		(trpt+1)->bup.oval = now.effect_outcome;
		now.effect_outcome = 5;
#ifdef VAR_RANGES
		logval("effect_outcome", now.effect_outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 38: // STATE 70 - remediation.pml:99 - [((((patch_target_present&&patch_uid_matches)&&resource_version_matches)&&api_accepts))] (86:0:2 - 1)
		IfNotBlocked
		reached[0][70] = 1;
		if (!((((((int)now.patch_target_present)&&((int)now.patch_uid_matches))&&((int)now.resource_version_matches))&&((int)now.api_accepts))))
			continue;
		/* merge: assert((((remediation_enabled&&evidence_valid)&&proposal_allowed)&&((((namespace_uid_matches&&observed_target_present)&&observed_uid_matches)&&template_matches)&&probe_matches)))(86, 71, 86) */
		reached[0][71] = 1;
		spin_assert((((((int)now.remediation_enabled)&&((int)now.evidence_valid))&&((int)now.proposal_allowed))&&((((((int)now.namespace_uid_matches)&&((int)now.observed_target_present))&&((int)now.observed_uid_matches))&&((int)now.template_matches))&&((int)now.probe_matches))), "(((remediation_enabled&&evidence_valid)&&proposal_allowed)&&((((namespace_uid_matches&&observed_target_present)&&observed_uid_matches)&&template_matches)&&probe_matches))", II, tt, t);
		/* merge: assert((patch_target_present&&patch_uid_matches))(86, 72, 86) */
		reached[0][72] = 1;
		spin_assert((((int)now.patch_target_present)&&((int)now.patch_uid_matches)), "(patch_target_present&&patch_uid_matches)", II, tt, t);
		/* merge: assert(resource_version_matches)(86, 73, 86) */
		reached[0][73] = 1;
		spin_assert(((int)now.resource_version_matches), "resource_version_matches", II, tt, t);
		/* merge: effects = (effects+1)(86, 74, 86) */
		reached[0][74] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.effects);
		now.effects = (((int)now.effects)+1);
#ifdef VAR_RANGES
		logval("effects", ((int)now.effects));
#endif
		;
		/* merge: assert((effects<=1))(86, 75, 86) */
		reached[0][75] = 1;
		spin_assert((((int)now.effects)<=1), "(effects<=1)", II, tt, t);
		/* merge: patch_applied = 1(86, 76, 86) */
		reached[0][76] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.patch_applied);
		now.patch_applied = 1;
#ifdef VAR_RANGES
		logval("patch_applied", ((int)now.patch_applied));
#endif
		;
		/* merge: .(goto)(86, 80, 86) */
		reached[0][80] = 1;
		;
		_m = 3; goto P999; /* 7 */
	case 39: // STATE 80 - remediation.pml:108 - [.(goto)] (0:86:0 - 2)
		IfNotBlocked
		reached[0][80] = 1;
		;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 77 - remediation.pml:106 - [(!((((patch_target_present&&patch_uid_matches)&&resource_version_matches)&&api_accepts)))] (86:0:1 - 1)
		IfNotBlocked
		reached[0][77] = 1;
		if (!( !((((((int)now.patch_target_present)&&((int)now.patch_uid_matches))&&((int)now.resource_version_matches))&&((int)now.api_accepts)))))
			continue;
		/* merge: outcome = PatchFailed(86, 78, 86) */
		reached[0][78] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 12;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		/* merge: .(goto)(86, 80, 86) */
		reached[0][80] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 41: // STATE 82 - remediation.pml:62 - [response_received = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][82] = 1;
		(trpt+1)->bup.oval = ((int)now.response_received);
		now.response_received = 1;
#ifdef VAR_RANGES
		logval("response_received", ((int)now.response_received));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 42: // STATE 83 - remediation.pml:62 - [response_received = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][83] = 1;
		(trpt+1)->bup.oval = ((int)now.response_received);
		now.response_received = 0;
#ifdef VAR_RANGES
		logval("response_received", ((int)now.response_received));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 43: // STATE 87 - remediation.pml:111 - [(patch_applied)] (0:0:0 - 1)
		IfNotBlocked
		reached[0][87] = 1;
		if (!(((int)now.patch_applied)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 44: // STATE 88 - remediation.pml:116 - [patch_acknowledged = response_received] (0:0:1 - 1)
		IfNotBlocked
		reached[0][88] = 1;
		(trpt+1)->bup.oval = ((int)now.patch_acknowledged);
		now.patch_acknowledged = ((int)now.response_received);
#ifdef VAR_RANGES
		logval("patch_acknowledged", ((int)now.patch_acknowledged));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 45: // STATE 89 - remediation.pml:118 - [(!(patch_acknowledged))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][89] = 1;
		if (!( !(((int)now.patch_acknowledged))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 46: // STATE 90 - remediation.pml:118 - [outcome = PatchUncertain] (0:0:1 - 1)
		IfNotBlocked
		reached[0][90] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 11;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 47: // STATE 91 - remediation.pml:119 - [(patch_acknowledged)] (0:0:0 - 1)
		IfNotBlocked
		reached[0][91] = 1;
		if (!(((int)now.patch_acknowledged)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 48: // STATE 92 - remediation.pml:120 - [effect_outcome = EffectApplied] (0:0:1 - 1)
		IfNotBlocked
		reached[0][92] = 1;
		(trpt+1)->bup.oval = now.effect_outcome;
		now.effect_outcome = 6;
#ifdef VAR_RANGES
		logval("effect_outcome", now.effect_outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 49: // STATE 93 - remediation.pml:62 - [recovery_identity_matches = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][93] = 1;
		(trpt+1)->bup.oval = ((int)now.recovery_identity_matches);
		now.recovery_identity_matches = 1;
#ifdef VAR_RANGES
		logval("recovery_identity_matches", ((int)now.recovery_identity_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 50: // STATE 94 - remediation.pml:62 - [recovery_identity_matches = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][94] = 1;
		(trpt+1)->bup.oval = ((int)now.recovery_identity_matches);
		now.recovery_identity_matches = 0;
#ifdef VAR_RANGES
		logval("recovery_identity_matches", ((int)now.recovery_identity_matches));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 51: // STATE 98 - remediation.pml:62 - [generation_observed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][98] = 1;
		(trpt+1)->bup.oval = ((int)now.generation_observed);
		now.generation_observed = 1;
#ifdef VAR_RANGES
		logval("generation_observed", ((int)now.generation_observed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 52: // STATE 99 - remediation.pml:62 - [generation_observed = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][99] = 1;
		(trpt+1)->bup.oval = ((int)now.generation_observed);
		now.generation_observed = 0;
#ifdef VAR_RANGES
		logval("generation_observed", ((int)now.generation_observed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 53: // STATE 103 - remediation.pml:62 - [rollout_ready = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][103] = 1;
		(trpt+1)->bup.oval = ((int)now.rollout_ready);
		now.rollout_ready = 1;
#ifdef VAR_RANGES
		logval("rollout_ready", ((int)now.rollout_ready));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 54: // STATE 104 - remediation.pml:62 - [rollout_ready = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][104] = 1;
		(trpt+1)->bup.oval = ((int)now.rollout_ready);
		now.rollout_ready = 0;
#ifdef VAR_RANGES
		logval("rollout_ready", ((int)now.rollout_ready));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 55: // STATE 108 - remediation.pml:62 - [replacement_pod_ready = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][108] = 1;
		(trpt+1)->bup.oval = ((int)now.replacement_pod_ready);
		now.replacement_pod_ready = 1;
#ifdef VAR_RANGES
		logval("replacement_pod_ready", ((int)now.replacement_pod_ready));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 56: // STATE 109 - remediation.pml:62 - [replacement_pod_ready = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][109] = 1;
		(trpt+1)->bup.oval = ((int)now.replacement_pod_ready);
		now.replacement_pod_ready = 0;
#ifdef VAR_RANGES
		logval("replacement_pod_ready", ((int)now.replacement_pod_ready));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 57: // STATE 113 - remediation.pml:62 - [endpoint_200_body = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][113] = 1;
		(trpt+1)->bup.oval = ((int)now.endpoint_200_body);
		now.endpoint_200_body = 1;
#ifdef VAR_RANGES
		logval("endpoint_200_body", ((int)now.endpoint_200_body));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 58: // STATE 114 - remediation.pml:62 - [endpoint_200_body = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][114] = 1;
		(trpt+1)->bup.oval = ((int)now.endpoint_200_body);
		now.endpoint_200_body = 0;
#ifdef VAR_RANGES
		logval("endpoint_200_body", ((int)now.endpoint_200_body));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 59: // STATE 118 - remediation.pml:62 - [fresh_metrics = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][118] = 1;
		(trpt+1)->bup.oval = ((int)now.fresh_metrics);
		now.fresh_metrics = 1;
#ifdef VAR_RANGES
		logval("fresh_metrics", ((int)now.fresh_metrics));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 60: // STATE 119 - remediation.pml:62 - [fresh_metrics = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][119] = 1;
		(trpt+1)->bup.oval = ((int)now.fresh_metrics);
		now.fresh_metrics = 0;
#ifdef VAR_RANGES
		logval("fresh_metrics", ((int)now.fresh_metrics));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 61: // STATE 123 - remediation.pml:133 - [outcome = Verified] (0:0:1 - 3)
		IfNotBlocked
		reached[0][123] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 9;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 62: // STATE 124 - remediation.pml:140 - [assert(((outcome!=Verified)||((patch_applied&&patch_acknowledged)&&(((((recovery_identity_matches&&generation_observed)&&rollout_ready)&&replacement_pod_ready)&&endpoint_200_body)&&fresh_metrics))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][124] = 1;
		spin_assert(((now.outcome!=9)||((((int)now.patch_applied)&&((int)now.patch_acknowledged))&&(((((((int)now.recovery_identity_matches)&&((int)now.generation_observed))&&((int)now.rollout_ready))&&((int)now.replacement_pod_ready))&&((int)now.endpoint_200_body))&&((int)now.fresh_metrics)))), "((outcome!=9)||((patch_applied&&patch_acknowledged)&&(((((recovery_identity_matches&&generation_observed)&&rollout_ready)&&replacement_pod_ready)&&endpoint_200_body)&&fresh_metrics)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 63: // STATE 125 - remediation.pml:141 - [assert(((outcome!=Verified)||(effects==1)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][125] = 1;
		spin_assert(((now.outcome!=9)||(((int)now.effects)==1)), "((outcome!=9)||(effects==1))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 64: // STATE 126 - remediation.pml:143 - [((((((recovery_identity_matches&&generation_observed)&&rollout_ready)&&replacement_pod_ready)&&endpoint_200_body)&&fresh_metrics))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][126] = 1;
		if (!((((((((int)now.recovery_identity_matches)&&((int)now.generation_observed))&&((int)now.rollout_ready))&&((int)now.replacement_pod_ready))&&((int)now.endpoint_200_body))&&((int)now.fresh_metrics))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 65: // STATE 127 - remediation.pml:143 - [verification_outcome = VerificationPassed] (0:0:1 - 1)
		IfNotBlocked
		reached[0][127] = 1;
		(trpt+1)->bup.oval = now.verification_outcome;
		now.verification_outcome = 3;
#ifdef VAR_RANGES
		logval("verification_outcome", now.verification_outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 66: // STATE 128 - remediation.pml:144 - [(!((((((recovery_identity_matches&&generation_observed)&&rollout_ready)&&replacement_pod_ready)&&endpoint_200_body)&&fresh_metrics)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][128] = 1;
		if (!( !((((((((int)now.recovery_identity_matches)&&((int)now.generation_observed))&&((int)now.rollout_ready))&&((int)now.replacement_pod_ready))&&((int)now.endpoint_200_body))&&((int)now.fresh_metrics)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 67: // STATE 129 - remediation.pml:62 - [observed_postcondition_failure = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][129] = 1;
		(trpt+1)->bup.oval = ((int)now.observed_postcondition_failure);
		now.observed_postcondition_failure = 1;
#ifdef VAR_RANGES
		logval("observed_postcondition_failure", ((int)now.observed_postcondition_failure));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 68: // STATE 130 - remediation.pml:62 - [observed_postcondition_failure = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][130] = 1;
		(trpt+1)->bup.oval = ((int)now.observed_postcondition_failure);
		now.observed_postcondition_failure = 0;
#ifdef VAR_RANGES
		logval("observed_postcondition_failure", ((int)now.observed_postcondition_failure));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 69: // STATE 134 - remediation.pml:147 - [(observed_postcondition_failure)] (0:0:0 - 1)
		IfNotBlocked
		reached[0][134] = 1;
		if (!(((int)now.observed_postcondition_failure)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 70: // STATE 135 - remediation.pml:147 - [verification_outcome = VerificationFailed] (0:0:1 - 1)
		IfNotBlocked
		reached[0][135] = 1;
		(trpt+1)->bup.oval = now.verification_outcome;
		now.verification_outcome = 2;
#ifdef VAR_RANGES
		logval("verification_outcome", now.verification_outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 71: // STATE 136 - remediation.pml:148 - [(!(observed_postcondition_failure))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][136] = 1;
		if (!( !(((int)now.observed_postcondition_failure))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 72: // STATE 137 - remediation.pml:148 - [verification_outcome = VerificationInconclusive] (0:0:1 - 1)
		IfNotBlocked
		reached[0][137] = 1;
		(trpt+1)->bup.oval = now.verification_outcome;
		now.verification_outcome = 1;
#ifdef VAR_RANGES
		logval("verification_outcome", now.verification_outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 73: // STATE 144 - remediation.pml:152 - [(!(patch_applied))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][144] = 1;
		if (!( !(((int)now.patch_applied))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 74: // STATE 145 - remediation.pml:154 - [(response_received)] (0:0:0 - 1)
		IfNotBlocked
		reached[0][145] = 1;
		if (!(((int)now.response_received)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 75: // STATE 146 - remediation.pml:154 - [effect_outcome = EffectRejected] (0:0:1 - 1)
		IfNotBlocked
		reached[0][146] = 1;
		(trpt+1)->bup.oval = now.effect_outcome;
		now.effect_outcome = 7;
#ifdef VAR_RANGES
		logval("effect_outcome", now.effect_outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 76: // STATE 147 - remediation.pml:155 - [(!(response_received))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][147] = 1;
		if (!( !(((int)now.response_received))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 77: // STATE 148 - remediation.pml:155 - [outcome = PatchUncertain] (0:0:1 - 1)
		IfNotBlocked
		reached[0][148] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 11;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 78: // STATE 153 - remediation.pml:158 - [(!((((((evidence_valid&&namespace_uid_matches)&&observed_target_present)&&observed_uid_matches)&&template_matches)&&probe_matches)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][153] = 1;
		if (!( !((((((((int)now.evidence_valid)&&((int)now.namespace_uid_matches))&&((int)now.observed_target_present))&&((int)now.observed_uid_matches))&&((int)now.template_matches))&&((int)now.probe_matches)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 79: // STATE 154 - remediation.pml:158 - [outcome = Rejected] (0:0:1 - 1)
		IfNotBlocked
		reached[0][154] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 13;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 80: // STATE 159 - remediation.pml:161 - [assert((outcome!=Pending))] (0:0:0 - 17)
		IfNotBlocked
		reached[0][159] = 1;
		spin_assert((now.outcome!=15), "(outcome!=15)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 81: // STATE 160 - remediation.pml:162 - [assert(((outcome!=Verified)||((((((((remediation_enabled&&evidence_valid)&&proposal_allowed)&&((((namespace_uid_matches&&observed_target_present)&&observed_uid_matches)&&template_matches)&&probe_matches))&&(patch_target_present&&patch_uid_matches))&&resource_version_matches)&&patch_applied)&&patch_acknowledged)&&(((((recovery_identity_matches&&generation_observed)&&rollout_ready)&&replacement_pod_ready)&&endpoint_200_body)&&fresh_metrics))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][160] = 1;
		spin_assert(((now.outcome!=9)||((((((((((int)now.remediation_enabled)&&((int)now.evidence_valid))&&((int)now.proposal_allowed))&&((((((int)now.namespace_uid_matches)&&((int)now.observed_target_present))&&((int)now.observed_uid_matches))&&((int)now.template_matches))&&((int)now.probe_matches)))&&(((int)now.patch_target_present)&&((int)now.patch_uid_matches)))&&((int)now.resource_version_matches))&&((int)now.patch_applied))&&((int)now.patch_acknowledged))&&(((((((int)now.recovery_identity_matches)&&((int)now.generation_observed))&&((int)now.rollout_ready))&&((int)now.replacement_pod_ready))&&((int)now.endpoint_200_body))&&((int)now.fresh_metrics)))), "((outcome!=9)||((((((((remediation_enabled&&evidence_valid)&&proposal_allowed)&&((((namespace_uid_matches&&observed_target_present)&&observed_uid_matches)&&template_matches)&&probe_matches))&&(patch_target_present&&patch_uid_matches))&&resource_version_matches)&&patch_applied)&&patch_acknowledged)&&(((((recovery_identity_matches&&generation_observed)&&rollout_ready)&&replacement_pod_ready)&&endpoint_200_body)&&fresh_metrics)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 82: // STATE 161 - remediation.pml:163 - [assert(((effects==0)||patch_applied))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][161] = 1;
		spin_assert(((((int)now.effects)==0)||((int)now.patch_applied)), "((effects==0)||patch_applied)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 83: // STATE 162 - remediation.pml:164 - [assert((!(patch_applied)||(effects==1)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][162] = 1;
		spin_assert(( !(((int)now.patch_applied))||(((int)now.effects)==1)), "( !(patch_applied)||(effects==1))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 84: // STATE 163 - remediation.pml:171 - [assert(((effect_outcome!=EffectApplied)||patch_acknowledged))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][163] = 1;
		spin_assert(((now.effect_outcome!=6)||((int)now.patch_acknowledged)), "((effect_outcome!=6)||patch_acknowledged)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 85: // STATE 164 - remediation.pml:172 - [assert(((verification_outcome!=VerificationPassed)||((effect_outcome==EffectApplied)&&(((((recovery_identity_matches&&generation_observed)&&rollout_ready)&&replacement_pod_ready)&&endpoint_200_body)&&fresh_metrics))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][164] = 1;
		spin_assert(((now.verification_outcome!=3)||((now.effect_outcome==6)&&(((((((int)now.recovery_identity_matches)&&((int)now.generation_observed))&&((int)now.rollout_ready))&&((int)now.replacement_pod_ready))&&((int)now.endpoint_200_body))&&((int)now.fresh_metrics)))), "((verification_outcome!=3)||((effect_outcome==6)&&(((((recovery_identity_matches&&generation_observed)&&rollout_ready)&&replacement_pod_ready)&&endpoint_200_body)&&fresh_metrics)))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 86: // STATE 165 - remediation.pml:173 - [assert(((effect_outcome==EffectApplied)||(verification_outcome==VerificationNotRun)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][165] = 1;
		spin_assert(((now.effect_outcome==6)||(now.verification_outcome==4)), "((effect_outcome==6)||(verification_outcome==4))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 87: // STATE 166 - remediation.pml:62 - [report_authenticated = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][166] = 1;
		(trpt+1)->bup.oval = ((int)now.report_authenticated);
		now.report_authenticated = 1;
#ifdef VAR_RANGES
		logval("report_authenticated", ((int)now.report_authenticated));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 88: // STATE 167 - remediation.pml:62 - [report_authenticated = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][167] = 1;
		(trpt+1)->bup.oval = ((int)now.report_authenticated);
		now.report_authenticated = 0;
#ifdef VAR_RANGES
		logval("report_authenticated", ((int)now.report_authenticated));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 89: // STATE 171 - remediation.pml:182 - [(report_authenticated)] (0:0:0 - 1)
		IfNotBlocked
		reached[0][171] = 1;
		if (!(((int)now.report_authenticated)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 90: // STATE 172 - remediation.pml:182 - [report_published = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][172] = 1;
		(trpt+1)->bup.oval = ((int)now.report_published);
		now.report_published = 1;
#ifdef VAR_RANGES
		logval("report_published", ((int)now.report_published));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 91: // STATE 173 - remediation.pml:183 - [(!(report_authenticated))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][173] = 1;
		if (!( !(((int)now.report_authenticated))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 92: // STATE 177 - remediation.pml:186 - [assert((!(report_published)||report_authenticated))] (0:0:0 - 3)
		IfNotBlocked
		reached[0][177] = 1;
		spin_assert(( !(((int)now.report_published))||((int)now.report_authenticated)), "( !(report_published)||report_authenticated)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 93: // STATE 178 - remediation.pml:187 - [done = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][178] = 1;
		(trpt+1)->bup.oval = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 94: // STATE 179 - remediation.pml:194 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][179] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

