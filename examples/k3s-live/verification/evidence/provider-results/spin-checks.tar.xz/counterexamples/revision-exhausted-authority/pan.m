#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM revision_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(done))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][1] = 1;
		if (!( !(((int)now.done))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Incident */
	case 5: // STATE 1 - revision.pml:17 - [admission = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)now.admission);
		now.admission = 1;
#ifdef VAR_RANGES
		logval("admission", ((int)now.admission));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - revision.pml:17 - [admission = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		(trpt+1)->bup.oval = ((int)now.admission);
		now.admission = 0;
#ifdef VAR_RANGES
		logval("admission", ((int)now.admission));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 5 - revision.pml:19 - [outcome = Cancelled] (0:0:1 - 1)
		IfNotBlocked
		reached[0][5] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 2;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 8: // STATE 6 - revision.pml:20 - [outcome = Blocked] (0:0:1 - 1)
		IfNotBlocked
		reached[0][6] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 1;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 9: // STATE 7 - revision.pml:21 - [passed[0] = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][7] = 1;
		(trpt+1)->bup.oval = ((int)now.passed[0]);
		now.passed[0] = 1;
#ifdef VAR_RANGES
		logval("passed[0]", ((int)now.passed[0]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 10: // STATE 8 - revision.pml:21 - [passed[0] = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][8] = 1;
		(trpt+1)->bup.oval = ((int)now.passed[0]);
		now.passed[0] = 0;
#ifdef VAR_RANGES
		logval("passed[0]", ((int)now.passed[0]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 11: // STATE 11 - revision.pml:22 - [assessments = (assessments+1)] (0:0:1 - 3)
		IfNotBlocked
		reached[0][11] = 1;
		(trpt+1)->bup.oval = ((int)now.assessments);
		now.assessments = (((int)now.assessments)+1);
#ifdef VAR_RANGES
		logval("assessments", ((int)now.assessments));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 12: // STATE 12 - revision.pml:24 - [(passed[0])] (0:0:0 - 1)
		IfNotBlocked
		reached[0][12] = 1;
		if (!(((int)now.passed[0])))
			continue;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 13 - revision.pml:24 - [outcome = Completed] (0:0:1 - 1)
		IfNotBlocked
		reached[0][13] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 4;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 14 - revision.pml:25 - [(!(passed[0]))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][14] = 1;
		if (!( !(((int)now.passed[0]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 15: // STATE 15 - revision.pml:26 - [supplied_feedback = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][15] = 1;
		(trpt+1)->bup.oval = ((int)now.supplied_feedback);
		now.supplied_feedback = 0;
#ifdef VAR_RANGES
		logval("supplied_feedback", ((int)now.supplied_feedback));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 16 - revision.pml:27 - [candidate = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][16] = 1;
		(trpt+1)->bup.oval = ((int)now.candidate);
		now.candidate = 1;
#ifdef VAR_RANGES
		logval("candidate", ((int)now.candidate));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 17 - revision.pml:28 - [assert((supplied_feedback==(candidate-1)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][17] = 1;
		spin_assert((((int)now.supplied_feedback)==(((int)now.candidate)-1)), "(supplied_feedback==(candidate-1))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 18 - revision.pml:29 - [passed[1] = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][18] = 1;
		(trpt+1)->bup.oval = ((int)now.passed[1]);
		now.passed[1] = 1;
#ifdef VAR_RANGES
		logval("passed[1]", ((int)now.passed[1]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 19 - revision.pml:29 - [passed[1] = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][19] = 1;
		(trpt+1)->bup.oval = ((int)now.passed[1]);
		now.passed[1] = 0;
#ifdef VAR_RANGES
		logval("passed[1]", ((int)now.passed[1]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 22 - revision.pml:30 - [assessments = (assessments+1)] (0:0:1 - 3)
		IfNotBlocked
		reached[0][22] = 1;
		(trpt+1)->bup.oval = ((int)now.assessments);
		now.assessments = (((int)now.assessments)+1);
#ifdef VAR_RANGES
		logval("assessments", ((int)now.assessments));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 23 - revision.pml:31 - [(passed[1])] (0:0:0 - 1)
		IfNotBlocked
		reached[0][23] = 1;
		if (!(((int)now.passed[1])))
			continue;
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 24 - revision.pml:31 - [outcome = Completed] (0:0:1 - 1)
		IfNotBlocked
		reached[0][24] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 4;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 25 - revision.pml:32 - [(!(passed[1]))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][25] = 1;
		if (!( !(((int)now.passed[1]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 24: // STATE 26 - revision.pml:32 - [outcome = Exhausted] (0:0:1 - 1)
		IfNotBlocked
		reached[0][26] = 1;
		(trpt+1)->bup.oval = now.outcome;
		now.outcome = 3;
#ifdef VAR_RANGES
		logval("outcome", now.outcome);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 33 - revision.pml:36 - [(((outcome==Completed)||(outcome==Exhausted)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][33] = 1;
		if (!(((now.outcome==4)||(now.outcome==3))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 26: // STATE 34 - revision.pml:36 - [selected = candidate] (0:0:1 - 1)
		IfNotBlocked
		reached[0][34] = 1;
		(trpt+1)->bup.oval = ((int)now.selected);
		now.selected = ((int)now.candidate);
#ifdef VAR_RANGES
		logval("selected", ((int)now.selected));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 27: // STATE 39 - revision.pml:39 - [assert(((candidate<=1)&&(assessments<=2)))] (0:0:0 - 3)
		IfNotBlocked
		reached[0][39] = 1;
		spin_assert(((((int)now.candidate)<=1)&&(((int)now.assessments)<=2)), "((candidate<=1)&&(assessments<=2))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 28: // STATE 40 - revision.pml:46 - [(((outcome==Completed)&&admission))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][40] = 1;
		if (!(((now.outcome==4)&&((int)now.admission))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 29: // STATE 41 - revision.pml:47 - [assert(((selected==candidate)&&exact_selected))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][41] = 1;
		spin_assert(((((int)now.selected)==((int)now.candidate))&&((int)now.exact_selected)), "((selected==candidate)&&exact_selected)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 30: // STATE 42 - revision.pml:48 - [mutation = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][42] = 1;
		(trpt+1)->bup.oval = ((int)now.mutation);
		now.mutation = 1;
#ifdef VAR_RANGES
		logval("mutation", ((int)now.mutation));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 47 - revision.pml:52 - [((outcome==Exhausted))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][47] = 1;
		if (!((now.outcome==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 48 - revision.pml:52 - [mutation = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][48] = 1;
		(trpt+1)->bup.oval = ((int)now.mutation);
		now.mutation = 1;
#ifdef VAR_RANGES
		logval("mutation", ((int)now.mutation));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 53 - revision.pml:54 - [assert((!(mutation)||(((outcome==Completed)&&passed[selected])&&admission)))] (0:0:0 - 3)
		IfNotBlocked
		reached[0][53] = 1;
		spin_assert(( !(((int)now.mutation))||(((now.outcome==4)&&((int)now.passed[ Index(((int)now.selected), 2) ]))&&((int)now.admission))), "( !(mutation)||(((outcome==4)&&passed[selected])&&admission))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 34: // STATE 54 - revision.pml:58 - [done = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][54] = 1;
		(trpt+1)->bup.oval = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 35: // STATE 55 - revision.pml:59 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][55] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

