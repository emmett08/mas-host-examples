	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM revision_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Incident */

	case 5: // STATE 1
		;
		now.admission = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 2
		;
		now.admission = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 5
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 6
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;

	case 9: // STATE 7
		;
		now.passed[0] = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 8
		;
		now.passed[0] = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 11
		;
		now.assessments = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 13: // STATE 13
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 15: // STATE 15
		;
		now.supplied_feedback = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 16
		;
		now.candidate = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 18: // STATE 18
		;
		now.passed[1] = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 19
		;
		now.passed[1] = trpt->bup.oval;
		;
		goto R999;

	case 20: // STATE 22
		;
		now.assessments = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 22: // STATE 24
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 24: // STATE 26
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 26: // STATE 34
		;
		now.selected = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		
	case 30: // STATE 42
		;
		now.mutation = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 33: // STATE 49
		;
		now.done = trpt->bup.oval;
		;
		goto R999;

	case 34: // STATE 50
		;
		p_restor(II);
		;
		;
		goto R999;
	}

