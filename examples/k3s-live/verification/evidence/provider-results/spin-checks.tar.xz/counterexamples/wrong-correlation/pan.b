	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM choreography_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Choreography */

	case 5: // STATE 1
		;
		((P0 *)_this)->i = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 4
		;
		((P0 *)_this)->i = trpt->bup.ovals[1];
		now.state[ Index(((P0 *)_this)->i, 8) ] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 7: // STATE 25
		;
		now.recipient[7] = trpt->bup.ovals[15];
		now.sender[7] = trpt->bup.ovals[14];
		now.recipient[6] = trpt->bup.ovals[13];
		now.sender[6] = trpt->bup.ovals[12];
		now.recipient[5] = trpt->bup.ovals[11];
		now.sender[5] = trpt->bup.ovals[10];
		now.recipient[4] = trpt->bup.ovals[9];
		now.sender[4] = trpt->bup.ovals[8];
		now.recipient[3] = trpt->bup.ovals[7];
		now.sender[3] = trpt->bup.ovals[6];
		now.recipient[2] = trpt->bup.ovals[5];
		now.sender[2] = trpt->bup.ovals[4];
		now.recipient[1] = trpt->bup.ovals[3];
		now.sender[1] = trpt->bup.ovals[2];
		now.recipient[0] = trpt->bup.ovals[1];
		now.sender[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 16);
		goto R999;
;
		
	case 8: // STATE 26
		goto R999;

	case 9: // STATE 35
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 10: // STATE 35
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 11: // STATE 35
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 12: // STATE 40
		;
		now.state[0] = trpt->bup.oval;
		;
		goto R999;

	case 13: // STATE 43
		;
		now.state[1] = trpt->bup.oval;
		;
		goto R999;

	case 14: // STATE 46
		;
		now.state[2] = trpt->bup.oval;
		;
		goto R999;

	case 15: // STATE 49
		;
		now.state[3] = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 52
		;
		now.state[4] = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 55
		;
		now.state[5] = trpt->bup.oval;
		;
		goto R999;

	case 18: // STATE 58
		;
		now.state[6] = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 61
		;
		now.state[7] = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		
	case 21: // STATE 64
		goto R999;

	case 22: // STATE 73
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 23: // STATE 73
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 24: // STATE 73
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		
	case 26: // STATE 78
		goto R999;

	case 27: // STATE 87
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 28: // STATE 87
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 29: // STATE 87
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		
	case 31: // STATE 92
		goto R999;

	case 32: // STATE 101
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 33: // STATE 101
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 34: // STATE 101
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 36: // STATE 107
		;
		now.reply_to[1] = trpt->bup.oval;
		;
		goto R999;

	case 37: // STATE 116
		;
		now.state[1] = trpt->bup.ovals[1];
		now.reply_to[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 38: // STATE 116
		;
		now.state[1] = trpt->bup.oval;
		;
		goto R999;

	case 39: // STATE 116
		;
		now.state[1] = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		
	case 41: // STATE 120
		goto R999;

	case 42: // STATE 129
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 43: // STATE 129
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 44: // STATE 129
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 47: // STATE 136
		;
		now.reply_to[1] = trpt->bup.oval;
		;
		goto R999;

	case 48: // STATE 145
		;
		now.state[1] = trpt->bup.ovals[1];
		now.reply_to[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 49: // STATE 145
		;
		now.state[1] = trpt->bup.oval;
		;
		goto R999;

	case 50: // STATE 145
		;
		now.state[1] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 51: // STATE 161
		goto R999;
;
		;
		
	case 53: // STATE 149
		;
		now.reply_to[1] = trpt->bup.oval;
		;
		goto R999;

	case 54: // STATE 158
		;
		now.state[1] = trpt->bup.ovals[1];
		now.reply_to[1] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 55: // STATE 158
		;
		now.state[1] = trpt->bup.oval;
		;
		goto R999;

	case 56: // STATE 158
		;
		now.state[1] = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		
	case 58: // STATE 165
		goto R999;

	case 59: // STATE 174
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 60: // STATE 174
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 61: // STATE 174
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 64: // STATE 181
		;
		now.reply_to[2] = trpt->bup.oval;
		;
		goto R999;

	case 65: // STATE 190
		;
		now.state[2] = trpt->bup.ovals[1];
		now.reply_to[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 66: // STATE 190
		;
		now.state[2] = trpt->bup.oval;
		;
		goto R999;

	case 67: // STATE 190
		;
		now.state[2] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 68: // STATE 206
		goto R999;
;
		;
		
	case 70: // STATE 194
		;
		now.reply_to[2] = trpt->bup.oval;
		;
		goto R999;

	case 71: // STATE 203
		;
		now.state[2] = trpt->bup.ovals[1];
		now.reply_to[2] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 72: // STATE 203
		;
		now.state[2] = trpt->bup.oval;
		;
		goto R999;

	case 73: // STATE 203
		;
		now.state[2] = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		
	case 75: // STATE 210
		goto R999;

	case 76: // STATE 219
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 77: // STATE 219
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 78: // STATE 219
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		;
		;
		
	case 81: // STATE 226
		;
		now.reply_to[4] = trpt->bup.oval;
		;
		goto R999;

	case 82: // STATE 235
		;
		now.state[4] = trpt->bup.ovals[1];
		now.reply_to[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 83: // STATE 235
		;
		now.state[4] = trpt->bup.oval;
		;
		goto R999;

	case 84: // STATE 235
		;
		now.state[4] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 85: // STATE 251
		goto R999;
;
		;
		
	case 87: // STATE 239
		;
		now.reply_to[4] = trpt->bup.oval;
		;
		goto R999;

	case 88: // STATE 248
		;
		now.state[4] = trpt->bup.ovals[1];
		now.reply_to[4] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 89: // STATE 248
		;
		now.state[4] = trpt->bup.oval;
		;
		goto R999;

	case 90: // STATE 248
		;
		now.state[4] = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 92: // STATE 256
		;
		now.reply_to[3] = trpt->bup.oval;
		;
		goto R999;

	case 93: // STATE 265
		;
		now.state[3] = trpt->bup.ovals[1];
		now.reply_to[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 94: // STATE 265
		;
		now.state[3] = trpt->bup.oval;
		;
		goto R999;

	case 95: // STATE 265
		;
		now.state[3] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 96: // STATE 280
		goto R999;

	case 97: // STATE 268
		;
		now.reply_to[3] = trpt->bup.oval;
		;
		goto R999;

	case 98: // STATE 277
		;
		now.state[3] = trpt->bup.ovals[1];
		now.reply_to[3] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 99: // STATE 277
		;
		now.state[3] = trpt->bup.oval;
		;
		goto R999;

	case 100: // STATE 277
		;
		now.state[3] = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 102: // STATE 284
		;
		now.reply_to[5] = trpt->bup.oval;
		;
		goto R999;

	case 103: // STATE 293
		;
		now.state[5] = trpt->bup.ovals[1];
		now.reply_to[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 104: // STATE 293
		;
		now.state[5] = trpt->bup.oval;
		;
		goto R999;

	case 105: // STATE 293
		;
		now.state[5] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 106: // STATE 308
		goto R999;

	case 107: // STATE 296
		;
		now.reply_to[5] = trpt->bup.oval;
		;
		goto R999;

	case 108: // STATE 305
		;
		now.state[5] = trpt->bup.ovals[1];
		now.reply_to[5] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 109: // STATE 305
		;
		now.state[5] = trpt->bup.oval;
		;
		goto R999;

	case 110: // STATE 305
		;
		now.state[5] = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 112: // STATE 312
		;
		now.reply_to[6] = trpt->bup.oval;
		;
		goto R999;

	case 113: // STATE 321
		;
		now.state[6] = trpt->bup.ovals[1];
		now.reply_to[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 114: // STATE 321
		;
		now.state[6] = trpt->bup.oval;
		;
		goto R999;

	case 115: // STATE 321
		;
		now.state[6] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 116: // STATE 336
		goto R999;

	case 117: // STATE 324
		;
		now.reply_to[6] = trpt->bup.oval;
		;
		goto R999;

	case 118: // STATE 333
		;
		now.state[6] = trpt->bup.ovals[1];
		now.reply_to[6] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 119: // STATE 333
		;
		now.state[6] = trpt->bup.oval;
		;
		goto R999;

	case 120: // STATE 333
		;
		now.state[6] = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 122: // STATE 340
		;
		now.reply_to[7] = trpt->bup.oval;
		;
		goto R999;

	case 123: // STATE 349
		;
		now.state[7] = trpt->bup.ovals[1];
		now.reply_to[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 124: // STATE 349
		;
		now.state[7] = trpt->bup.oval;
		;
		goto R999;

	case 125: // STATE 349
		;
		now.state[7] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 126: // STATE 364
		goto R999;

	case 127: // STATE 352
		;
		now.reply_to[7] = trpt->bup.oval;
		;
		goto R999;

	case 128: // STATE 361
		;
		now.state[7] = trpt->bup.ovals[1];
		now.reply_to[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 129: // STATE 361
		;
		now.state[7] = trpt->bup.oval;
		;
		goto R999;

	case 130: // STATE 361
		;
		now.state[7] = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		
	case 132: // STATE 367
		goto R999;

	case 133: // STATE 376
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 134: // STATE 376
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 135: // STATE 376
		;
		now.dispatches = trpt->bup.ovals[1];
		now.state[7] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		;
		
	case 137: // STATE 382
		;
		now.reply_to[0] = trpt->bup.oval;
		;
		goto R999;

	case 138: // STATE 391
		;
		now.state[0] = trpt->bup.ovals[1];
		now.reply_to[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 139: // STATE 391
		;
		now.state[0] = trpt->bup.oval;
		;
		goto R999;

	case 140: // STATE 391
		;
		now.state[0] = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 143: // STATE 397
		;
		now.reply_to[0] = trpt->bup.oval;
		;
		goto R999;

	case 144: // STATE 406
		;
		now.state[0] = trpt->bup.ovals[1];
		now.reply_to[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 145: // STATE 406
		;
		now.state[0] = trpt->bup.oval;
		;
		goto R999;

	case 146: // STATE 406
		;
		now.state[0] = trpt->bup.oval;
		;
		goto R999;
;
		
	case 147: // STATE 422
		goto R999;
;
		;
		
	case 149: // STATE 410
		;
		now.reply_to[0] = trpt->bup.oval;
		;
		goto R999;

	case 150: // STATE 419
		;
		now.state[0] = trpt->bup.ovals[1];
		now.reply_to[0] = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 151: // STATE 419
		;
		now.state[0] = trpt->bup.oval;
		;
		goto R999;

	case 152: // STATE 419
		;
		now.state[0] = trpt->bup.oval;
		;
		goto R999;

	case 153: // STATE 427
		;
		now.observer_reads = trpt->bup.ovals[1];
		now.observed_dispatches = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;

	case 154: // STATE 432
		;
		now.done = trpt->bup.oval;
		;
		goto R999;

	case 155: // STATE 438
		;
		p_restor(II);
		;
		;
		goto R999;
	}

