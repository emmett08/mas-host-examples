	switch (t->back) {
	default: Uerror("bad return move");
	case  0: goto R999; /* nothing to undo */

		 /* CLAIM remediation_settles */
;
		;
		
	case 4: // STATE 6
		;
		p_restor(II);
		;
		;
		goto R999;

		 /* PROC Remediation */

	case 5: // STATE 1
		;
		now.remediation_enabled = trpt->bup.oval;
		;
		goto R999;

	case 6: // STATE 2
		;
		now.remediation_enabled = trpt->bup.oval;
		;
		goto R999;

	case 7: // STATE 6
		;
		now.evidence_valid = trpt->bup.oval;
		;
		goto R999;

	case 8: // STATE 7
		;
		now.evidence_valid = trpt->bup.oval;
		;
		goto R999;

	case 9: // STATE 11
		;
		now.proposal_allowed = trpt->bup.oval;
		;
		goto R999;

	case 10: // STATE 12
		;
		now.proposal_allowed = trpt->bup.oval;
		;
		goto R999;

	case 11: // STATE 16
		;
		now.namespace_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 12: // STATE 17
		;
		now.namespace_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 13: // STATE 21
		;
		now.observed_target_present = trpt->bup.oval;
		;
		goto R999;

	case 14: // STATE 22
		;
		now.observed_target_present = trpt->bup.oval;
		;
		goto R999;

	case 15: // STATE 26
		;
		now.observed_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 16: // STATE 27
		;
		now.observed_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 17: // STATE 31
		;
		now.template_matches = trpt->bup.oval;
		;
		goto R999;

	case 18: // STATE 32
		;
		now.template_matches = trpt->bup.oval;
		;
		goto R999;

	case 19: // STATE 36
		;
		now.probe_matches = trpt->bup.oval;
		;
		goto R999;

	case 20: // STATE 37
		;
		now.probe_matches = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 22: // STATE 42
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 24: // STATE 44
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 26: // STATE 46
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 29: // STATE 49
		;
		now.patch_target_present = trpt->bup.oval;
		;
		goto R999;

	case 30: // STATE 50
		;
		now.patch_target_present = trpt->bup.oval;
		;
		goto R999;

	case 31: // STATE 54
		;
		now.patch_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 32: // STATE 55
		;
		now.patch_uid_matches = trpt->bup.oval;
		;
		goto R999;

	case 33: // STATE 59
		;
		now.resource_version_matches = trpt->bup.oval;
		;
		goto R999;

	case 34: // STATE 60
		;
		now.resource_version_matches = trpt->bup.oval;
		;
		goto R999;

	case 35: // STATE 64
		;
		now.api_accepts = trpt->bup.oval;
		;
		goto R999;

	case 36: // STATE 65
		;
		now.api_accepts = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 38: // STATE 75
		;
		now.effect_outcome = trpt->bup.oval;
		;
		goto R999;

	case 39: // STATE 82
		;
		now.patch_applied = trpt->bup.ovals[1];
		now.effects = trpt->bup.ovals[0];
		;
		ungrab_ints(trpt->bup.ovals, 2);
		goto R999;
;
		
	case 40: // STATE 86
		goto R999;

	case 41: // STATE 84
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;

	case 42: // STATE 88
		;
		now.response_received = trpt->bup.oval;
		;
		goto R999;

	case 43: // STATE 89
		;
		now.response_received = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 45: // STATE 94
		;
		now.patch_acknowledged = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 47: // STATE 96
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 49: // STATE 98
		;
		now.effect_outcome = trpt->bup.oval;
		;
		goto R999;

	case 50: // STATE 99
		;
		now.recovery_identity_matches = trpt->bup.oval;
		;
		goto R999;

	case 51: // STATE 100
		;
		now.recovery_identity_matches = trpt->bup.oval;
		;
		goto R999;

	case 52: // STATE 104
		;
		now.generation_observed = trpt->bup.oval;
		;
		goto R999;

	case 53: // STATE 105
		;
		now.generation_observed = trpt->bup.oval;
		;
		goto R999;

	case 54: // STATE 109
		;
		now.rollout_ready = trpt->bup.oval;
		;
		goto R999;

	case 55: // STATE 110
		;
		now.rollout_ready = trpt->bup.oval;
		;
		goto R999;

	case 56: // STATE 114
		;
		now.replacement_pod_ready = trpt->bup.oval;
		;
		goto R999;

	case 57: // STATE 115
		;
		now.replacement_pod_ready = trpt->bup.oval;
		;
		goto R999;

	case 58: // STATE 119
		;
		now.endpoint_200_body = trpt->bup.oval;
		;
		goto R999;

	case 59: // STATE 120
		;
		now.endpoint_200_body = trpt->bup.oval;
		;
		goto R999;

	case 60: // STATE 124
		;
		now.fresh_metrics = trpt->bup.oval;
		;
		goto R999;

	case 61: // STATE 125
		;
		now.fresh_metrics = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 63: // STATE 130
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 65: // STATE 132
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		
	case 69: // STATE 138
		;
		now.verification_outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 71: // STATE 140
		;
		now.observed_postcondition_failure = trpt->bup.oval;
		;
		goto R999;

	case 72: // STATE 141
		;
		now.observed_postcondition_failure = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 74: // STATE 146
		;
		now.verification_outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 76: // STATE 148
		;
		now.verification_outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 79: // STATE 157
		;
		now.effect_outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 81: // STATE 159
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 83: // STATE 165
		;
		now.outcome = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		
	case 91: // STATE 177
		;
		now.report_authenticated = trpt->bup.oval;
		;
		goto R999;

	case 92: // STATE 178
		;
		now.report_authenticated = trpt->bup.oval;
		;
		goto R999;
;
		;
		
	case 94: // STATE 183
		;
		now.report_published = trpt->bup.oval;
		;
		goto R999;
;
		;
		;
		;
		
	case 97: // STATE 189
		;
		now.done = trpt->bup.oval;
		;
		goto R999;

	case 98: // STATE 190
		;
		p_restor(II);
		;
		;
		goto R999;
	}

