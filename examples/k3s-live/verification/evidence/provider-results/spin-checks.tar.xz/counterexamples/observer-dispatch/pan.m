#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM choreography_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(done))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][1] = 1;
		if (!( !(((int)now.done))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[1][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Choreography */
	case 5: // STATE 1 - hybrid.pml:68 - [i = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->i);
		((P0 *)_this)->i = 0;
#ifdef VAR_RANGES
		logval("Choreography:i", ((int)((P0 *)_this)->i));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - hybrid.pml:69 - [((i<8))] (7:0:2 - 1)
		IfNotBlocked
		reached[0][2] = 1;
		if (!((((int)((P0 *)_this)->i)<8)))
			continue;
		/* merge: state[i] = Absent(7, 3, 7) */
		reached[0][3] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[ Index(((int)((P0 *)_this)->i), 8) ];
		now.state[ Index(((P0 *)_this)->i, 8) ] = 5;
#ifdef VAR_RANGES
		logval("state[Choreography:i]", now.state[ Index(((int)((P0 *)_this)->i), 8) ]);
#endif
		;
		/* merge: i = (i+1)(7, 4, 7) */
		reached[0][4] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->i);
		((P0 *)_this)->i = (((int)((P0 *)_this)->i)+1);
#ifdef VAR_RANGES
		logval("Choreography:i", ((int)((P0 *)_this)->i));
#endif
		;
		/* merge: .(goto)(0, 8, 7) */
		reached[0][8] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 7: // STATE 10 - hybrid.pml:70 - [sender[0] = 0] (0:37:16 - 3)
		IfNotBlocked
		reached[0][10] = 1;
		(trpt+1)->bup.ovals = grab_ints(16);
		(trpt+1)->bup.ovals[0] = ((int)now.sender[0]);
		now.sender[0] = 0;
#ifdef VAR_RANGES
		logval("sender[0]", ((int)now.sender[0]));
#endif
		;
		/* merge: recipient[0] = 1(37, 11, 37) */
		reached[0][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.recipient[0]);
		now.recipient[0] = 1;
#ifdef VAR_RANGES
		logval("recipient[0]", ((int)now.recipient[0]));
#endif
		;
		/* merge: sender[1] = 1(37, 12, 37) */
		reached[0][12] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.sender[1]);
		now.sender[1] = 1;
#ifdef VAR_RANGES
		logval("sender[1]", ((int)now.sender[1]));
#endif
		;
		/* merge: recipient[1] = 2(37, 13, 37) */
		reached[0][13] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.recipient[1]);
		now.recipient[1] = 2;
#ifdef VAR_RANGES
		logval("recipient[1]", ((int)now.recipient[1]));
#endif
		;
		/* merge: sender[2] = 1(37, 14, 37) */
		reached[0][14] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.sender[2]);
		now.sender[2] = 1;
#ifdef VAR_RANGES
		logval("sender[2]", ((int)now.sender[2]));
#endif
		;
		/* merge: recipient[2] = 4(37, 15, 37) */
		reached[0][15] = 1;
		(trpt+1)->bup.ovals[5] = ((int)now.recipient[2]);
		now.recipient[2] = 4;
#ifdef VAR_RANGES
		logval("recipient[2]", ((int)now.recipient[2]));
#endif
		;
		/* merge: sender[3] = 2(37, 16, 37) */
		reached[0][16] = 1;
		(trpt+1)->bup.ovals[6] = ((int)now.sender[3]);
		now.sender[3] = 2;
#ifdef VAR_RANGES
		logval("sender[3]", ((int)now.sender[3]));
#endif
		;
		/* merge: recipient[3] = 3(37, 17, 37) */
		reached[0][17] = 1;
		(trpt+1)->bup.ovals[7] = ((int)now.recipient[3]);
		now.recipient[3] = 3;
#ifdef VAR_RANGES
		logval("recipient[3]", ((int)now.recipient[3]));
#endif
		;
		/* merge: sender[4] = 2(37, 18, 37) */
		reached[0][18] = 1;
		(trpt+1)->bup.ovals[8] = ((int)now.sender[4]);
		now.sender[4] = 2;
#ifdef VAR_RANGES
		logval("sender[4]", ((int)now.sender[4]));
#endif
		;
		/* merge: recipient[4] = 4(37, 19, 37) */
		reached[0][19] = 1;
		(trpt+1)->bup.ovals[9] = ((int)now.recipient[4]);
		now.recipient[4] = 4;
#ifdef VAR_RANGES
		logval("recipient[4]", ((int)now.recipient[4]));
#endif
		;
		/* merge: sender[5] = 4(37, 20, 37) */
		reached[0][20] = 1;
		(trpt+1)->bup.ovals[10] = ((int)now.sender[5]);
		now.sender[5] = 4;
#ifdef VAR_RANGES
		logval("sender[5]", ((int)now.sender[5]));
#endif
		;
		/* merge: recipient[5] = 5(37, 21, 37) */
		reached[0][21] = 1;
		(trpt+1)->bup.ovals[11] = ((int)now.recipient[5]);
		now.recipient[5] = 5;
#ifdef VAR_RANGES
		logval("recipient[5]", ((int)now.recipient[5]));
#endif
		;
		/* merge: sender[6] = 4(37, 22, 37) */
		reached[0][22] = 1;
		(trpt+1)->bup.ovals[12] = ((int)now.sender[6]);
		now.sender[6] = 4;
#ifdef VAR_RANGES
		logval("sender[6]", ((int)now.sender[6]));
#endif
		;
		/* merge: recipient[6] = 5(37, 23, 37) */
		reached[0][23] = 1;
		(trpt+1)->bup.ovals[13] = ((int)now.recipient[6]);
		now.recipient[6] = 5;
#ifdef VAR_RANGES
		logval("recipient[6]", ((int)now.recipient[6]));
#endif
		;
		/* merge: sender[7] = 1(37, 24, 37) */
		reached[0][24] = 1;
		(trpt+1)->bup.ovals[14] = ((int)now.sender[7]);
		now.sender[7] = 1;
#ifdef VAR_RANGES
		logval("sender[7]", ((int)now.sender[7]));
#endif
		;
		/* merge: recipient[7] = 6(37, 25, 37) */
		reached[0][25] = 1;
		(trpt+1)->bup.ovals[15] = ((int)now.recipient[7]);
		now.recipient[7] = 6;
#ifdef VAR_RANGES
		logval("recipient[7]", ((int)now.recipient[7]));
#endif
		;
		_m = 3; goto P999; /* 15 */
	case 8: // STATE 26 - hybrid.pml:33 - [assert((state[0]==Absent))] (0:32:0 - 1)
		IfNotBlocked
		reached[0][26] = 1;
		spin_assert((now.state[0]==5), "(state[0]==5)", II, tt, t);
		/* merge: assert((((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1))))(32, 27, 32) */
		reached[0][27] = 1;
		spin_assert((((((((((((((((((int)now.sender[0])==0)&&(((int)now.recipient[0])==1))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==0)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==1)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==1)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==3)))||((((int)now.sender[0])==3)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==2)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==2)))||((((int)now.sender[0])==4)&&(((int)now.recipient[0])==5)))||((((int)now.sender[0])==5)&&(((int)now.recipient[0])==4)))||((((int)now.sender[0])==1)&&(((int)now.recipient[0])==6)))||((((int)now.sender[0])==6)&&(((int)now.recipient[0])==1))), "(((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 9: // STATE 28 - hybrid.pml:39 - [((0==7))] (328:0:2 - 1)
		IfNotBlocked
		reached[0][28] = 1;
		if (!((0==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(328, 29, 328) */
		reached[0][29] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(328, 33, 328) */
		reached[0][33] = 1;
		;
		/* merge: state[0] = Sent(328, 34, 328) */
		reached[0][34] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[0];
		now.state[0] = 4;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 35, 328) */
		reached[0][35] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 36, 328) */
		reached[0][36] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 10: // STATE 31 - hybrid.pml:40 - [(1)] (328:0:2 - 1)
		IfNotBlocked
		reached[0][31] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(328, 33, 328) */
		reached[0][33] = 1;
		;
		/* merge: state[0] = Sent(328, 34, 328) */
		reached[0][34] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[0];
		now.state[0] = 4;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 35, 328) */
		reached[0][35] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 36, 328) */
		reached[0][36] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 11: // STATE 34 - hybrid.pml:42 - [state[0] = Sent] (0:328:2 - 3)
		IfNotBlocked
		reached[0][34] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[0];
		now.state[0] = 4;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 35, 328) */
		reached[0][35] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 36, 328) */
		reached[0][36] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 12: // STATE 39 - hybrid.pml:83 - [((state[0]==Sent))] (328:0:1 - 1)
		IfNotBlocked
		reached[0][39] = 1;
		if (!((now.state[0]==4)))
			continue;
		/* merge: state[0] = Received(0, 40, 328) */
		reached[0][40] = 1;
		(trpt+1)->bup.oval = now.state[0];
		now.state[0] = 3;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 13: // STATE 42 - hybrid.pml:85 - [((state[1]==Sent))] (328:0:1 - 1)
		IfNotBlocked
		reached[0][42] = 1;
		if (!((now.state[1]==4)))
			continue;
		/* merge: state[1] = Received(0, 43, 328) */
		reached[0][43] = 1;
		(trpt+1)->bup.oval = now.state[1];
		now.state[1] = 3;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 14: // STATE 45 - hybrid.pml:86 - [((state[2]==Sent))] (328:0:1 - 1)
		IfNotBlocked
		reached[0][45] = 1;
		if (!((now.state[2]==4)))
			continue;
		/* merge: state[2] = Received(0, 46, 328) */
		reached[0][46] = 1;
		(trpt+1)->bup.oval = now.state[2];
		now.state[2] = 3;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 15: // STATE 48 - hybrid.pml:87 - [((state[3]==Sent))] (328:0:1 - 1)
		IfNotBlocked
		reached[0][48] = 1;
		if (!((now.state[3]==4)))
			continue;
		/* merge: state[3] = Received(0, 49, 328) */
		reached[0][49] = 1;
		(trpt+1)->bup.oval = now.state[3];
		now.state[3] = 3;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 16: // STATE 51 - hybrid.pml:88 - [((state[4]==Sent))] (328:0:1 - 1)
		IfNotBlocked
		reached[0][51] = 1;
		if (!((now.state[4]==4)))
			continue;
		/* merge: state[4] = Received(0, 52, 328) */
		reached[0][52] = 1;
		(trpt+1)->bup.oval = now.state[4];
		now.state[4] = 3;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 17: // STATE 54 - hybrid.pml:89 - [((state[5]==Sent))] (328:0:1 - 1)
		IfNotBlocked
		reached[0][54] = 1;
		if (!((now.state[5]==4)))
			continue;
		/* merge: state[5] = Received(0, 55, 328) */
		reached[0][55] = 1;
		(trpt+1)->bup.oval = now.state[5];
		now.state[5] = 3;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 18: // STATE 57 - hybrid.pml:90 - [((state[6]==Sent))] (328:0:1 - 1)
		IfNotBlocked
		reached[0][57] = 1;
		if (!((now.state[6]==4)))
			continue;
		/* merge: state[6] = Received(0, 58, 328) */
		reached[0][58] = 1;
		(trpt+1)->bup.oval = now.state[6];
		now.state[6] = 3;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 19: // STATE 60 - hybrid.pml:91 - [((state[7]==Sent))] (328:0:1 - 1)
		IfNotBlocked
		reached[0][60] = 1;
		if (!((now.state[7]==4)))
			continue;
		/* merge: state[7] = Received(0, 61, 328) */
		reached[0][61] = 1;
		(trpt+1)->bup.oval = now.state[7];
		now.state[7] = 3;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 20: // STATE 63 - hybrid.pml:94 - [(((state[0]==Received)&&(state[1]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][63] = 1;
		if (!(((now.state[0]==3)&&(now.state[1]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 64 - hybrid.pml:33 - [assert((state[1]==Absent))] (0:70:0 - 1)
		IfNotBlocked
		reached[0][64] = 1;
		spin_assert((now.state[1]==5), "(state[1]==5)", II, tt, t);
		/* merge: assert((((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1))))(70, 65, 70) */
		reached[0][65] = 1;
		spin_assert((((((((((((((((((int)now.sender[1])==0)&&(((int)now.recipient[1])==1))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==0)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==1)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==1)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==3)))||((((int)now.sender[1])==3)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==2)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==2)))||((((int)now.sender[1])==4)&&(((int)now.recipient[1])==5)))||((((int)now.sender[1])==5)&&(((int)now.recipient[1])==4)))||((((int)now.sender[1])==1)&&(((int)now.recipient[1])==6)))||((((int)now.sender[1])==6)&&(((int)now.recipient[1])==1))), "(((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 22: // STATE 66 - hybrid.pml:39 - [((1==7))] (328:0:2 - 1)
		IfNotBlocked
		reached[0][66] = 1;
		if (!((1==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(328, 67, 328) */
		reached[0][67] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(328, 71, 328) */
		reached[0][71] = 1;
		;
		/* merge: state[1] = Sent(328, 72, 328) */
		reached[0][72] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[1];
		now.state[1] = 4;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 73, 328) */
		reached[0][73] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 74, 328) */
		reached[0][74] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 23: // STATE 69 - hybrid.pml:40 - [(1)] (328:0:2 - 1)
		IfNotBlocked
		reached[0][69] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(328, 71, 328) */
		reached[0][71] = 1;
		;
		/* merge: state[1] = Sent(328, 72, 328) */
		reached[0][72] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[1];
		now.state[1] = 4;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 73, 328) */
		reached[0][73] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 74, 328) */
		reached[0][74] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 24: // STATE 72 - hybrid.pml:42 - [state[1] = Sent] (0:328:2 - 3)
		IfNotBlocked
		reached[0][72] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[1];
		now.state[1] = 4;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 73, 328) */
		reached[0][73] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 74, 328) */
		reached[0][74] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 25: // STATE 77 - hybrid.pml:95 - [(((state[0]==Received)&&(state[2]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][77] = 1;
		if (!(((now.state[0]==3)&&(now.state[2]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 26: // STATE 78 - hybrid.pml:33 - [assert((state[2]==Absent))] (0:84:0 - 1)
		IfNotBlocked
		reached[0][78] = 1;
		spin_assert((now.state[2]==5), "(state[2]==5)", II, tt, t);
		/* merge: assert((((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1))))(84, 79, 84) */
		reached[0][79] = 1;
		spin_assert((((((((((((((((((int)now.sender[2])==0)&&(((int)now.recipient[2])==1))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==0)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==1)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==1)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==3)))||((((int)now.sender[2])==3)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==2)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==2)))||((((int)now.sender[2])==4)&&(((int)now.recipient[2])==5)))||((((int)now.sender[2])==5)&&(((int)now.recipient[2])==4)))||((((int)now.sender[2])==1)&&(((int)now.recipient[2])==6)))||((((int)now.sender[2])==6)&&(((int)now.recipient[2])==1))), "(((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 27: // STATE 80 - hybrid.pml:39 - [((2==7))] (328:0:2 - 1)
		IfNotBlocked
		reached[0][80] = 1;
		if (!((2==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(328, 81, 328) */
		reached[0][81] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(328, 85, 328) */
		reached[0][85] = 1;
		;
		/* merge: state[2] = Sent(328, 86, 328) */
		reached[0][86] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[2];
		now.state[2] = 4;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 87, 328) */
		reached[0][87] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 88, 328) */
		reached[0][88] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 28: // STATE 83 - hybrid.pml:40 - [(1)] (328:0:2 - 1)
		IfNotBlocked
		reached[0][83] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(328, 85, 328) */
		reached[0][85] = 1;
		;
		/* merge: state[2] = Sent(328, 86, 328) */
		reached[0][86] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[2];
		now.state[2] = 4;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 87, 328) */
		reached[0][87] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 88, 328) */
		reached[0][88] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 29: // STATE 86 - hybrid.pml:42 - [state[2] = Sent] (0:328:2 - 3)
		IfNotBlocked
		reached[0][86] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[2];
		now.state[2] = 4;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 87, 328) */
		reached[0][87] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 88, 328) */
		reached[0][88] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 30: // STATE 91 - hybrid.pml:96 - [(((state[1]==Received)&&(state[3]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][91] = 1;
		if (!(((now.state[1]==3)&&(now.state[3]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 92 - hybrid.pml:33 - [assert((state[3]==Absent))] (0:98:0 - 1)
		IfNotBlocked
		reached[0][92] = 1;
		spin_assert((now.state[3]==5), "(state[3]==5)", II, tt, t);
		/* merge: assert((((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1))))(98, 93, 98) */
		reached[0][93] = 1;
		spin_assert((((((((((((((((((int)now.sender[3])==0)&&(((int)now.recipient[3])==1))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==0)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==1)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==1)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==3)))||((((int)now.sender[3])==3)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==2)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==2)))||((((int)now.sender[3])==4)&&(((int)now.recipient[3])==5)))||((((int)now.sender[3])==5)&&(((int)now.recipient[3])==4)))||((((int)now.sender[3])==1)&&(((int)now.recipient[3])==6)))||((((int)now.sender[3])==6)&&(((int)now.recipient[3])==1))), "(((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 32: // STATE 94 - hybrid.pml:39 - [((3==7))] (328:0:2 - 1)
		IfNotBlocked
		reached[0][94] = 1;
		if (!((3==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(328, 95, 328) */
		reached[0][95] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(328, 99, 328) */
		reached[0][99] = 1;
		;
		/* merge: state[3] = Sent(328, 100, 328) */
		reached[0][100] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[3];
		now.state[3] = 4;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 101, 328) */
		reached[0][101] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 102, 328) */
		reached[0][102] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 33: // STATE 97 - hybrid.pml:40 - [(1)] (328:0:2 - 1)
		IfNotBlocked
		reached[0][97] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(328, 99, 328) */
		reached[0][99] = 1;
		;
		/* merge: state[3] = Sent(328, 100, 328) */
		reached[0][100] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[3];
		now.state[3] = 4;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 101, 328) */
		reached[0][101] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 102, 328) */
		reached[0][102] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 34: // STATE 100 - hybrid.pml:42 - [state[3] = Sent] (0:328:2 - 3)
		IfNotBlocked
		reached[0][100] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[3];
		now.state[3] = 4;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 101, 328) */
		reached[0][101] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 102, 328) */
		reached[0][102] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 35: // STATE 105 - hybrid.pml:97 - [(((state[1]==Received)&&(state[3]==Failed)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][105] = 1;
		if (!(((now.state[1]==3)&&(now.state[3]==1))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 36: // STATE 106 - hybrid.pml:48 - [assert((state[1]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][106] = 1;
		spin_assert((now.state[1]==3), "(state[1]==3)", II, tt, t);
		/* merge: reply_to[1] = 1(328, 107, 328) */
		reached[0][107] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[1]);
		now.reply_to[1] = 1;
#ifdef VAR_RANGES
		logval("reply_to[1]", ((int)now.reply_to[1]));
#endif
		;
		/* merge: assert((reply_to[1]==1))(328, 108, 328) */
		reached[0][108] = 1;
		spin_assert((((int)now.reply_to[1])==1), "(reply_to[1]==1)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))(328, 109, 328) */
		reached[0][109] = 1;
		spin_assert((((((((((((((((((int)now.recipient[1])==0)&&(((int)now.sender[1])==1))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==0)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==3)))||((((int)now.recipient[1])==3)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==5)))||((((int)now.recipient[1])==5)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==6)))||((((int)now.recipient[1])==6)&&(((int)now.sender[1])==1))), "(((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1)))", II, tt, t);
		/* merge: state[1] = 1(328, 110, 328) */
		reached[0][110] = 1;
		(trpt+1)->bup.ovals[1] = now.state[1];
		now.state[1] = 1;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 37: // STATE 113 - hybrid.pml:98 - [((((state[1]==Received)&&(state[3]==Succeeded))&&(state[4]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][113] = 1;
		if (!((((now.state[1]==3)&&(now.state[3]==2))&&(now.state[4]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 38: // STATE 114 - hybrid.pml:33 - [assert((state[4]==Absent))] (0:120:0 - 1)
		IfNotBlocked
		reached[0][114] = 1;
		spin_assert((now.state[4]==5), "(state[4]==5)", II, tt, t);
		/* merge: assert((((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1))))(120, 115, 120) */
		reached[0][115] = 1;
		spin_assert((((((((((((((((((int)now.sender[4])==0)&&(((int)now.recipient[4])==1))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==0)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==1)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==1)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==3)))||((((int)now.sender[4])==3)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==2)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==2)))||((((int)now.sender[4])==4)&&(((int)now.recipient[4])==5)))||((((int)now.sender[4])==5)&&(((int)now.recipient[4])==4)))||((((int)now.sender[4])==1)&&(((int)now.recipient[4])==6)))||((((int)now.sender[4])==6)&&(((int)now.recipient[4])==1))), "(((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 39: // STATE 116 - hybrid.pml:39 - [((4==7))] (328:0:2 - 1)
		IfNotBlocked
		reached[0][116] = 1;
		if (!((4==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(328, 117, 328) */
		reached[0][117] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(328, 121, 328) */
		reached[0][121] = 1;
		;
		/* merge: state[4] = Sent(328, 122, 328) */
		reached[0][122] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[4];
		now.state[4] = 4;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 123, 328) */
		reached[0][123] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 124, 328) */
		reached[0][124] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 40: // STATE 119 - hybrid.pml:40 - [(1)] (328:0:2 - 1)
		IfNotBlocked
		reached[0][119] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(328, 121, 328) */
		reached[0][121] = 1;
		;
		/* merge: state[4] = Sent(328, 122, 328) */
		reached[0][122] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[4];
		now.state[4] = 4;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 123, 328) */
		reached[0][123] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 124, 328) */
		reached[0][124] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 41: // STATE 122 - hybrid.pml:42 - [state[4] = Sent] (0:328:2 - 3)
		IfNotBlocked
		reached[0][122] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[4];
		now.state[4] = 4;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 123, 328) */
		reached[0][123] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 124, 328) */
		reached[0][124] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 42: // STATE 127 - hybrid.pml:99 - [(((state[1]==Received)&&((state[4]==Succeeded)||(state[4]==Failed))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][127] = 1;
		if (!(((now.state[1]==3)&&((now.state[4]==2)||(now.state[4]==1)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 43: // STATE 128 - hybrid.pml:60 - [((state[4]==Succeeded))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][128] = 1;
		if (!((now.state[4]==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 44: // STATE 129 - hybrid.pml:48 - [assert((state[1]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][129] = 1;
		spin_assert((now.state[1]==3), "(state[1]==3)", II, tt, t);
		/* merge: reply_to[1] = 1(328, 130, 328) */
		reached[0][130] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[1]);
		now.reply_to[1] = 1;
#ifdef VAR_RANGES
		logval("reply_to[1]", ((int)now.reply_to[1]));
#endif
		;
		/* merge: assert((reply_to[1]==1))(328, 131, 328) */
		reached[0][131] = 1;
		spin_assert((((int)now.reply_to[1])==1), "(reply_to[1]==1)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))(328, 132, 328) */
		reached[0][132] = 1;
		spin_assert((((((((((((((((((int)now.recipient[1])==0)&&(((int)now.sender[1])==1))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==0)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==3)))||((((int)now.recipient[1])==3)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==5)))||((((int)now.recipient[1])==5)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==6)))||((((int)now.recipient[1])==6)&&(((int)now.sender[1])==1))), "(((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1)))", II, tt, t);
		/* merge: state[1] = 2(328, 133, 328) */
		reached[0][133] = 1;
		(trpt+1)->bup.ovals[1] = now.state[1];
		now.state[1] = 2;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: .(goto)(328, 143, 328) */
		reached[0][143] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 45: // STATE 143 - hybrid.pml:63 - [.(goto)] (0:328:0 - 2)
		IfNotBlocked
		reached[0][143] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 46: // STATE 135 - hybrid.pml:61 - [((state[4]==Failed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][135] = 1;
		if (!((now.state[4]==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 47: // STATE 136 - hybrid.pml:48 - [assert((state[1]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][136] = 1;
		spin_assert((now.state[1]==3), "(state[1]==3)", II, tt, t);
		/* merge: reply_to[1] = 1(328, 137, 328) */
		reached[0][137] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[1]);
		now.reply_to[1] = 1;
#ifdef VAR_RANGES
		logval("reply_to[1]", ((int)now.reply_to[1]));
#endif
		;
		/* merge: assert((reply_to[1]==1))(328, 138, 328) */
		reached[0][138] = 1;
		spin_assert((((int)now.reply_to[1])==1), "(reply_to[1]==1)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))(328, 139, 328) */
		reached[0][139] = 1;
		spin_assert((((((((((((((((((int)now.recipient[1])==0)&&(((int)now.sender[1])==1))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==0)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==1)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==3)))||((((int)now.recipient[1])==3)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==2)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==2)))||((((int)now.recipient[1])==4)&&(((int)now.sender[1])==5)))||((((int)now.recipient[1])==5)&&(((int)now.sender[1])==4)))||((((int)now.recipient[1])==1)&&(((int)now.sender[1])==6)))||((((int)now.recipient[1])==6)&&(((int)now.sender[1])==1))), "(((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1)))", II, tt, t);
		/* merge: state[1] = 1(328, 140, 328) */
		reached[0][140] = 1;
		(trpt+1)->bup.ovals[1] = now.state[1];
		now.state[1] = 1;
#ifdef VAR_RANGES
		logval("state[1]", now.state[1]);
#endif
		;
		/* merge: .(goto)(328, 143, 328) */
		reached[0][143] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 48: // STATE 146 - hybrid.pml:100 - [(((state[2]==Received)&&(state[5]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][146] = 1;
		if (!(((now.state[2]==3)&&(now.state[5]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 49: // STATE 147 - hybrid.pml:33 - [assert((state[5]==Absent))] (0:153:0 - 1)
		IfNotBlocked
		reached[0][147] = 1;
		spin_assert((now.state[5]==5), "(state[5]==5)", II, tt, t);
		/* merge: assert((((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1))))(153, 148, 153) */
		reached[0][148] = 1;
		spin_assert((((((((((((((((((int)now.sender[5])==0)&&(((int)now.recipient[5])==1))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==0)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==1)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==1)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==3)))||((((int)now.sender[5])==3)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==2)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==2)))||((((int)now.sender[5])==4)&&(((int)now.recipient[5])==5)))||((((int)now.sender[5])==5)&&(((int)now.recipient[5])==4)))||((((int)now.sender[5])==1)&&(((int)now.recipient[5])==6)))||((((int)now.sender[5])==6)&&(((int)now.recipient[5])==1))), "(((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 50: // STATE 149 - hybrid.pml:39 - [((5==7))] (328:0:2 - 1)
		IfNotBlocked
		reached[0][149] = 1;
		if (!((5==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(328, 150, 328) */
		reached[0][150] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(328, 154, 328) */
		reached[0][154] = 1;
		;
		/* merge: state[5] = Sent(328, 155, 328) */
		reached[0][155] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[5];
		now.state[5] = 4;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 156, 328) */
		reached[0][156] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 157, 328) */
		reached[0][157] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 51: // STATE 152 - hybrid.pml:40 - [(1)] (328:0:2 - 1)
		IfNotBlocked
		reached[0][152] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(328, 154, 328) */
		reached[0][154] = 1;
		;
		/* merge: state[5] = Sent(328, 155, 328) */
		reached[0][155] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[5];
		now.state[5] = 4;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 156, 328) */
		reached[0][156] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 157, 328) */
		reached[0][157] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 52: // STATE 155 - hybrid.pml:42 - [state[5] = Sent] (0:328:2 - 3)
		IfNotBlocked
		reached[0][155] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[5];
		now.state[5] = 4;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 156, 328) */
		reached[0][156] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 157, 328) */
		reached[0][157] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 53: // STATE 160 - hybrid.pml:101 - [(((state[2]==Received)&&((state[5]==Succeeded)||(state[5]==Failed))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][160] = 1;
		if (!(((now.state[2]==3)&&((now.state[5]==2)||(now.state[5]==1)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 54: // STATE 161 - hybrid.pml:60 - [((state[5]==Succeeded))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][161] = 1;
		if (!((now.state[5]==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 55: // STATE 162 - hybrid.pml:48 - [assert((state[2]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][162] = 1;
		spin_assert((now.state[2]==3), "(state[2]==3)", II, tt, t);
		/* merge: reply_to[2] = 2(328, 163, 328) */
		reached[0][163] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[2]);
		now.reply_to[2] = 2;
#ifdef VAR_RANGES
		logval("reply_to[2]", ((int)now.reply_to[2]));
#endif
		;
		/* merge: assert((reply_to[2]==2))(328, 164, 328) */
		reached[0][164] = 1;
		spin_assert((((int)now.reply_to[2])==2), "(reply_to[2]==2)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1))))(328, 165, 328) */
		reached[0][165] = 1;
		spin_assert((((((((((((((((((int)now.recipient[2])==0)&&(((int)now.sender[2])==1))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==0)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==1)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==1)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==3)))||((((int)now.recipient[2])==3)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==5)))||((((int)now.recipient[2])==5)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==6)))||((((int)now.recipient[2])==6)&&(((int)now.sender[2])==1))), "(((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1)))", II, tt, t);
		/* merge: state[2] = 2(328, 166, 328) */
		reached[0][166] = 1;
		(trpt+1)->bup.ovals[1] = now.state[2];
		now.state[2] = 2;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: .(goto)(328, 176, 328) */
		reached[0][176] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 56: // STATE 176 - hybrid.pml:63 - [.(goto)] (0:328:0 - 2)
		IfNotBlocked
		reached[0][176] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 57: // STATE 168 - hybrid.pml:61 - [((state[5]==Failed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][168] = 1;
		if (!((now.state[5]==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 58: // STATE 169 - hybrid.pml:48 - [assert((state[2]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][169] = 1;
		spin_assert((now.state[2]==3), "(state[2]==3)", II, tt, t);
		/* merge: reply_to[2] = 2(328, 170, 328) */
		reached[0][170] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[2]);
		now.reply_to[2] = 2;
#ifdef VAR_RANGES
		logval("reply_to[2]", ((int)now.reply_to[2]));
#endif
		;
		/* merge: assert((reply_to[2]==2))(328, 171, 328) */
		reached[0][171] = 1;
		spin_assert((((int)now.reply_to[2])==2), "(reply_to[2]==2)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1))))(328, 172, 328) */
		reached[0][172] = 1;
		spin_assert((((((((((((((((((int)now.recipient[2])==0)&&(((int)now.sender[2])==1))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==0)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==1)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==1)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==3)))||((((int)now.recipient[2])==3)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==2)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==2)))||((((int)now.recipient[2])==4)&&(((int)now.sender[2])==5)))||((((int)now.recipient[2])==5)&&(((int)now.sender[2])==4)))||((((int)now.recipient[2])==1)&&(((int)now.sender[2])==6)))||((((int)now.recipient[2])==6)&&(((int)now.sender[2])==1))), "(((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1)))", II, tt, t);
		/* merge: state[2] = 1(328, 173, 328) */
		reached[0][173] = 1;
		(trpt+1)->bup.ovals[1] = now.state[2];
		now.state[2] = 1;
#ifdef VAR_RANGES
		logval("state[2]", now.state[2]);
#endif
		;
		/* merge: .(goto)(328, 176, 328) */
		reached[0][176] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 59: // STATE 179 - hybrid.pml:102 - [(((state[4]==Received)&&(state[6]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][179] = 1;
		if (!(((now.state[4]==3)&&(now.state[6]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 60: // STATE 180 - hybrid.pml:33 - [assert((state[6]==Absent))] (0:186:0 - 1)
		IfNotBlocked
		reached[0][180] = 1;
		spin_assert((now.state[6]==5), "(state[6]==5)", II, tt, t);
		/* merge: assert((((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1))))(186, 181, 186) */
		reached[0][181] = 1;
		spin_assert((((((((((((((((((int)now.sender[6])==0)&&(((int)now.recipient[6])==1))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==0)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==1)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==1)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==3)))||((((int)now.sender[6])==3)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==2)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==2)))||((((int)now.sender[6])==4)&&(((int)now.recipient[6])==5)))||((((int)now.sender[6])==5)&&(((int)now.recipient[6])==4)))||((((int)now.sender[6])==1)&&(((int)now.recipient[6])==6)))||((((int)now.sender[6])==6)&&(((int)now.recipient[6])==1))), "(((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 61: // STATE 182 - hybrid.pml:39 - [((6==7))] (328:0:2 - 1)
		IfNotBlocked
		reached[0][182] = 1;
		if (!((6==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(328, 183, 328) */
		reached[0][183] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(328, 187, 328) */
		reached[0][187] = 1;
		;
		/* merge: state[6] = Sent(328, 188, 328) */
		reached[0][188] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[6];
		now.state[6] = 4;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 189, 328) */
		reached[0][189] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 190, 328) */
		reached[0][190] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 62: // STATE 185 - hybrid.pml:40 - [(1)] (328:0:2 - 1)
		IfNotBlocked
		reached[0][185] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(328, 187, 328) */
		reached[0][187] = 1;
		;
		/* merge: state[6] = Sent(328, 188, 328) */
		reached[0][188] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[6];
		now.state[6] = 4;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 189, 328) */
		reached[0][189] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 190, 328) */
		reached[0][190] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 63: // STATE 188 - hybrid.pml:42 - [state[6] = Sent] (0:328:2 - 3)
		IfNotBlocked
		reached[0][188] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[6];
		now.state[6] = 4;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 189, 328) */
		reached[0][189] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 190, 328) */
		reached[0][190] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 64: // STATE 193 - hybrid.pml:103 - [(((state[4]==Received)&&((state[6]==Succeeded)||(state[6]==Failed))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][193] = 1;
		if (!(((now.state[4]==3)&&((now.state[6]==2)||(now.state[6]==1)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 65: // STATE 194 - hybrid.pml:60 - [((state[6]==Succeeded))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][194] = 1;
		if (!((now.state[6]==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 66: // STATE 195 - hybrid.pml:48 - [assert((state[4]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][195] = 1;
		spin_assert((now.state[4]==3), "(state[4]==3)", II, tt, t);
		/* merge: reply_to[4] = 4(328, 196, 328) */
		reached[0][196] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[4]);
		now.reply_to[4] = 4;
#ifdef VAR_RANGES
		logval("reply_to[4]", ((int)now.reply_to[4]));
#endif
		;
		/* merge: assert((reply_to[4]==4))(328, 197, 328) */
		reached[0][197] = 1;
		spin_assert((((int)now.reply_to[4])==4), "(reply_to[4]==4)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1))))(328, 198, 328) */
		reached[0][198] = 1;
		spin_assert((((((((((((((((((int)now.recipient[4])==0)&&(((int)now.sender[4])==1))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==0)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==1)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==1)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==3)))||((((int)now.recipient[4])==3)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==5)))||((((int)now.recipient[4])==5)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==6)))||((((int)now.recipient[4])==6)&&(((int)now.sender[4])==1))), "(((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1)))", II, tt, t);
		/* merge: state[4] = 2(328, 199, 328) */
		reached[0][199] = 1;
		(trpt+1)->bup.ovals[1] = now.state[4];
		now.state[4] = 2;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: .(goto)(328, 209, 328) */
		reached[0][209] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 67: // STATE 209 - hybrid.pml:63 - [.(goto)] (0:328:0 - 2)
		IfNotBlocked
		reached[0][209] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 68: // STATE 201 - hybrid.pml:61 - [((state[6]==Failed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][201] = 1;
		if (!((now.state[6]==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 69: // STATE 202 - hybrid.pml:48 - [assert((state[4]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][202] = 1;
		spin_assert((now.state[4]==3), "(state[4]==3)", II, tt, t);
		/* merge: reply_to[4] = 4(328, 203, 328) */
		reached[0][203] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[4]);
		now.reply_to[4] = 4;
#ifdef VAR_RANGES
		logval("reply_to[4]", ((int)now.reply_to[4]));
#endif
		;
		/* merge: assert((reply_to[4]==4))(328, 204, 328) */
		reached[0][204] = 1;
		spin_assert((((int)now.reply_to[4])==4), "(reply_to[4]==4)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1))))(328, 205, 328) */
		reached[0][205] = 1;
		spin_assert((((((((((((((((((int)now.recipient[4])==0)&&(((int)now.sender[4])==1))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==0)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==1)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==1)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==3)))||((((int)now.recipient[4])==3)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==2)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==2)))||((((int)now.recipient[4])==4)&&(((int)now.sender[4])==5)))||((((int)now.recipient[4])==5)&&(((int)now.sender[4])==4)))||((((int)now.recipient[4])==1)&&(((int)now.sender[4])==6)))||((((int)now.recipient[4])==6)&&(((int)now.sender[4])==1))), "(((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1)))", II, tt, t);
		/* merge: state[4] = 1(328, 206, 328) */
		reached[0][206] = 1;
		(trpt+1)->bup.ovals[1] = now.state[4];
		now.state[4] = 1;
#ifdef VAR_RANGES
		logval("state[4]", now.state[4]);
#endif
		;
		/* merge: .(goto)(328, 209, 328) */
		reached[0][209] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 70: // STATE 212 - hybrid.pml:106 - [((state[3]==Received))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][212] = 1;
		if (!((now.state[3]==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 71: // STATE 213 - hybrid.pml:48 - [assert((state[3]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][213] = 1;
		spin_assert((now.state[3]==3), "(state[3]==3)", II, tt, t);
		/* merge: reply_to[3] = 3(328, 214, 328) */
		reached[0][214] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[3]);
		now.reply_to[3] = 3;
#ifdef VAR_RANGES
		logval("reply_to[3]", ((int)now.reply_to[3]));
#endif
		;
		/* merge: assert((reply_to[3]==3))(328, 215, 328) */
		reached[0][215] = 1;
		spin_assert((((int)now.reply_to[3])==3), "(reply_to[3]==3)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1))))(328, 216, 328) */
		reached[0][216] = 1;
		spin_assert((((((((((((((((((int)now.recipient[3])==0)&&(((int)now.sender[3])==1))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==0)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==1)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==1)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==3)))||((((int)now.recipient[3])==3)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==5)))||((((int)now.recipient[3])==5)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==6)))||((((int)now.recipient[3])==6)&&(((int)now.sender[3])==1))), "(((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1)))", II, tt, t);
		/* merge: state[3] = 2(328, 217, 328) */
		reached[0][217] = 1;
		(trpt+1)->bup.ovals[1] = now.state[3];
		now.state[3] = 2;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: .(goto)(328, 226, 328) */
		reached[0][226] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 72: // STATE 226 - hybrid.pml:106 - [.(goto)] (0:328:0 - 2)
		IfNotBlocked
		reached[0][226] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 73: // STATE 219 - hybrid.pml:48 - [assert((state[3]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][219] = 1;
		spin_assert((now.state[3]==3), "(state[3]==3)", II, tt, t);
		/* merge: reply_to[3] = 3(328, 220, 328) */
		reached[0][220] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[3]);
		now.reply_to[3] = 3;
#ifdef VAR_RANGES
		logval("reply_to[3]", ((int)now.reply_to[3]));
#endif
		;
		/* merge: assert((reply_to[3]==3))(328, 221, 328) */
		reached[0][221] = 1;
		spin_assert((((int)now.reply_to[3])==3), "(reply_to[3]==3)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1))))(328, 222, 328) */
		reached[0][222] = 1;
		spin_assert((((((((((((((((((int)now.recipient[3])==0)&&(((int)now.sender[3])==1))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==0)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==1)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==1)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==3)))||((((int)now.recipient[3])==3)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==2)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==2)))||((((int)now.recipient[3])==4)&&(((int)now.sender[3])==5)))||((((int)now.recipient[3])==5)&&(((int)now.sender[3])==4)))||((((int)now.recipient[3])==1)&&(((int)now.sender[3])==6)))||((((int)now.recipient[3])==6)&&(((int)now.sender[3])==1))), "(((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1)))", II, tt, t);
		/* merge: state[3] = 1(328, 223, 328) */
		reached[0][223] = 1;
		(trpt+1)->bup.ovals[1] = now.state[3];
		now.state[3] = 1;
#ifdef VAR_RANGES
		logval("state[3]", now.state[3]);
#endif
		;
		/* merge: .(goto)(328, 226, 328) */
		reached[0][226] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 74: // STATE 228 - hybrid.pml:107 - [((state[5]==Received))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][228] = 1;
		if (!((now.state[5]==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 75: // STATE 229 - hybrid.pml:48 - [assert((state[5]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][229] = 1;
		spin_assert((now.state[5]==3), "(state[5]==3)", II, tt, t);
		/* merge: reply_to[5] = 5(328, 230, 328) */
		reached[0][230] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[5]);
		now.reply_to[5] = 5;
#ifdef VAR_RANGES
		logval("reply_to[5]", ((int)now.reply_to[5]));
#endif
		;
		/* merge: assert((reply_to[5]==5))(328, 231, 328) */
		reached[0][231] = 1;
		spin_assert((((int)now.reply_to[5])==5), "(reply_to[5]==5)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1))))(328, 232, 328) */
		reached[0][232] = 1;
		spin_assert((((((((((((((((((int)now.recipient[5])==0)&&(((int)now.sender[5])==1))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==0)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==1)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==1)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==3)))||((((int)now.recipient[5])==3)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==5)))||((((int)now.recipient[5])==5)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==6)))||((((int)now.recipient[5])==6)&&(((int)now.sender[5])==1))), "(((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1)))", II, tt, t);
		/* merge: state[5] = 2(328, 233, 328) */
		reached[0][233] = 1;
		(trpt+1)->bup.ovals[1] = now.state[5];
		now.state[5] = 2;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: .(goto)(328, 242, 328) */
		reached[0][242] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 76: // STATE 242 - hybrid.pml:107 - [.(goto)] (0:328:0 - 2)
		IfNotBlocked
		reached[0][242] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 77: // STATE 235 - hybrid.pml:48 - [assert((state[5]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][235] = 1;
		spin_assert((now.state[5]==3), "(state[5]==3)", II, tt, t);
		/* merge: reply_to[5] = 5(328, 236, 328) */
		reached[0][236] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[5]);
		now.reply_to[5] = 5;
#ifdef VAR_RANGES
		logval("reply_to[5]", ((int)now.reply_to[5]));
#endif
		;
		/* merge: assert((reply_to[5]==5))(328, 237, 328) */
		reached[0][237] = 1;
		spin_assert((((int)now.reply_to[5])==5), "(reply_to[5]==5)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1))))(328, 238, 328) */
		reached[0][238] = 1;
		spin_assert((((((((((((((((((int)now.recipient[5])==0)&&(((int)now.sender[5])==1))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==0)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==1)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==1)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==3)))||((((int)now.recipient[5])==3)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==2)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==2)))||((((int)now.recipient[5])==4)&&(((int)now.sender[5])==5)))||((((int)now.recipient[5])==5)&&(((int)now.sender[5])==4)))||((((int)now.recipient[5])==1)&&(((int)now.sender[5])==6)))||((((int)now.recipient[5])==6)&&(((int)now.sender[5])==1))), "(((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1)))", II, tt, t);
		/* merge: state[5] = 1(328, 239, 328) */
		reached[0][239] = 1;
		(trpt+1)->bup.ovals[1] = now.state[5];
		now.state[5] = 1;
#ifdef VAR_RANGES
		logval("state[5]", now.state[5]);
#endif
		;
		/* merge: .(goto)(328, 242, 328) */
		reached[0][242] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 78: // STATE 244 - hybrid.pml:108 - [((state[6]==Received))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][244] = 1;
		if (!((now.state[6]==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 79: // STATE 245 - hybrid.pml:48 - [assert((state[6]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][245] = 1;
		spin_assert((now.state[6]==3), "(state[6]==3)", II, tt, t);
		/* merge: reply_to[6] = 6(328, 246, 328) */
		reached[0][246] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[6]);
		now.reply_to[6] = 6;
#ifdef VAR_RANGES
		logval("reply_to[6]", ((int)now.reply_to[6]));
#endif
		;
		/* merge: assert((reply_to[6]==6))(328, 247, 328) */
		reached[0][247] = 1;
		spin_assert((((int)now.reply_to[6])==6), "(reply_to[6]==6)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1))))(328, 248, 328) */
		reached[0][248] = 1;
		spin_assert((((((((((((((((((int)now.recipient[6])==0)&&(((int)now.sender[6])==1))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==0)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==1)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==1)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==3)))||((((int)now.recipient[6])==3)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==5)))||((((int)now.recipient[6])==5)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==6)))||((((int)now.recipient[6])==6)&&(((int)now.sender[6])==1))), "(((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1)))", II, tt, t);
		/* merge: state[6] = 2(328, 249, 328) */
		reached[0][249] = 1;
		(trpt+1)->bup.ovals[1] = now.state[6];
		now.state[6] = 2;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: .(goto)(328, 258, 328) */
		reached[0][258] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 80: // STATE 258 - hybrid.pml:108 - [.(goto)] (0:328:0 - 2)
		IfNotBlocked
		reached[0][258] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 81: // STATE 251 - hybrid.pml:48 - [assert((state[6]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][251] = 1;
		spin_assert((now.state[6]==3), "(state[6]==3)", II, tt, t);
		/* merge: reply_to[6] = 6(328, 252, 328) */
		reached[0][252] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[6]);
		now.reply_to[6] = 6;
#ifdef VAR_RANGES
		logval("reply_to[6]", ((int)now.reply_to[6]));
#endif
		;
		/* merge: assert((reply_to[6]==6))(328, 253, 328) */
		reached[0][253] = 1;
		spin_assert((((int)now.reply_to[6])==6), "(reply_to[6]==6)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1))))(328, 254, 328) */
		reached[0][254] = 1;
		spin_assert((((((((((((((((((int)now.recipient[6])==0)&&(((int)now.sender[6])==1))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==0)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==1)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==1)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==3)))||((((int)now.recipient[6])==3)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==2)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==2)))||((((int)now.recipient[6])==4)&&(((int)now.sender[6])==5)))||((((int)now.recipient[6])==5)&&(((int)now.sender[6])==4)))||((((int)now.recipient[6])==1)&&(((int)now.sender[6])==6)))||((((int)now.recipient[6])==6)&&(((int)now.sender[6])==1))), "(((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1)))", II, tt, t);
		/* merge: state[6] = 1(328, 255, 328) */
		reached[0][255] = 1;
		(trpt+1)->bup.ovals[1] = now.state[6];
		now.state[6] = 1;
#ifdef VAR_RANGES
		logval("state[6]", now.state[6]);
#endif
		;
		/* merge: .(goto)(328, 258, 328) */
		reached[0][258] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 82: // STATE 260 - hybrid.pml:109 - [((state[7]==Received))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][260] = 1;
		if (!((now.state[7]==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 83: // STATE 261 - hybrid.pml:48 - [assert((state[7]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][261] = 1;
		spin_assert((now.state[7]==3), "(state[7]==3)", II, tt, t);
		/* merge: reply_to[7] = 7(328, 262, 328) */
		reached[0][262] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[7]);
		now.reply_to[7] = 7;
#ifdef VAR_RANGES
		logval("reply_to[7]", ((int)now.reply_to[7]));
#endif
		;
		/* merge: assert((reply_to[7]==7))(328, 263, 328) */
		reached[0][263] = 1;
		spin_assert((((int)now.reply_to[7])==7), "(reply_to[7]==7)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1))))(328, 264, 328) */
		reached[0][264] = 1;
		spin_assert((((((((((((((((((int)now.recipient[7])==0)&&(((int)now.sender[7])==1))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==0)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==1)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==1)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==3)))||((((int)now.recipient[7])==3)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==5)))||((((int)now.recipient[7])==5)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==6)))||((((int)now.recipient[7])==6)&&(((int)now.sender[7])==1))), "(((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1)))", II, tt, t);
		/* merge: state[7] = 2(328, 265, 328) */
		reached[0][265] = 1;
		(trpt+1)->bup.ovals[1] = now.state[7];
		now.state[7] = 2;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: .(goto)(328, 274, 328) */
		reached[0][274] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 84: // STATE 274 - hybrid.pml:109 - [.(goto)] (0:328:0 - 2)
		IfNotBlocked
		reached[0][274] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 85: // STATE 267 - hybrid.pml:48 - [assert((state[7]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][267] = 1;
		spin_assert((now.state[7]==3), "(state[7]==3)", II, tt, t);
		/* merge: reply_to[7] = 7(328, 268, 328) */
		reached[0][268] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[7]);
		now.reply_to[7] = 7;
#ifdef VAR_RANGES
		logval("reply_to[7]", ((int)now.reply_to[7]));
#endif
		;
		/* merge: assert((reply_to[7]==7))(328, 269, 328) */
		reached[0][269] = 1;
		spin_assert((((int)now.reply_to[7])==7), "(reply_to[7]==7)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1))))(328, 270, 328) */
		reached[0][270] = 1;
		spin_assert((((((((((((((((((int)now.recipient[7])==0)&&(((int)now.sender[7])==1))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==0)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==1)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==1)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==3)))||((((int)now.recipient[7])==3)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==2)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==2)))||((((int)now.recipient[7])==4)&&(((int)now.sender[7])==5)))||((((int)now.recipient[7])==5)&&(((int)now.sender[7])==4)))||((((int)now.recipient[7])==1)&&(((int)now.sender[7])==6)))||((((int)now.recipient[7])==6)&&(((int)now.sender[7])==1))), "(((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1)))", II, tt, t);
		/* merge: state[7] = 1(328, 271, 328) */
		reached[0][271] = 1;
		(trpt+1)->bup.ovals[1] = now.state[7];
		now.state[7] = 1;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: .(goto)(328, 274, 328) */
		reached[0][274] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 86: // STATE 276 - hybrid.pml:114 - [((((state[0]==Received)&&((state[1]==Succeeded)&&(state[2]==Succeeded)))&&(state[7]==Absent)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][276] = 1;
		if (!((((now.state[0]==3)&&((now.state[1]==2)&&(now.state[2]==2)))&&(now.state[7]==5))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 87: // STATE 277 - hybrid.pml:33 - [assert((state[7]==Absent))] (0:283:0 - 1)
		IfNotBlocked
		reached[0][277] = 1;
		spin_assert((now.state[7]==5), "(state[7]==5)", II, tt, t);
		/* merge: assert((((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1))))(283, 278, 283) */
		reached[0][278] = 1;
		spin_assert((((((((((((((((((int)now.sender[7])==0)&&(((int)now.recipient[7])==1))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==0)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==1)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==1)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==3)))||((((int)now.sender[7])==3)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==2)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==2)))||((((int)now.sender[7])==4)&&(((int)now.recipient[7])==5)))||((((int)now.sender[7])==5)&&(((int)now.recipient[7])==4)))||((((int)now.sender[7])==1)&&(((int)now.recipient[7])==6)))||((((int)now.sender[7])==6)&&(((int)now.recipient[7])==1))), "(((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1)))", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 88: // STATE 279 - hybrid.pml:39 - [((7==7))] (328:0:2 - 1)
		IfNotBlocked
		reached[0][279] = 1;
		if (!((7==7)))
			continue;
		/* merge: assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))(328, 280, 328) */
		reached[0][280] = 1;
		spin_assert(((now.state[1]==2)&&(now.state[2]==2)), "((state[1]==2)&&(state[2]==2))", II, tt, t);
		/* merge: .(goto)(328, 284, 328) */
		reached[0][284] = 1;
		;
		/* merge: state[7] = Sent(328, 285, 328) */
		reached[0][285] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[7];
		now.state[7] = 4;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 286, 328) */
		reached[0][286] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 287, 328) */
		reached[0][287] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 89: // STATE 282 - hybrid.pml:40 - [(1)] (328:0:2 - 1)
		IfNotBlocked
		reached[0][282] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(328, 284, 328) */
		reached[0][284] = 1;
		;
		/* merge: state[7] = Sent(328, 285, 328) */
		reached[0][285] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[7];
		now.state[7] = 4;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 286, 328) */
		reached[0][286] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 287, 328) */
		reached[0][287] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 90: // STATE 285 - hybrid.pml:42 - [state[7] = Sent] (0:328:2 - 3)
		IfNotBlocked
		reached[0][285] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = now.state[7];
		now.state[7] = 4;
#ifdef VAR_RANGES
		logval("state[7]", now.state[7]);
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 286, 328) */
		reached[0][286] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: assert((dispatches<=8))(328, 287, 328) */
		reached[0][287] = 1;
		spin_assert((((int)now.dispatches)<=8), "(dispatches<=8)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 91: // STATE 290 - hybrid.pml:115 - [(((((state[0]==Received)&&((state[1]==Succeeded)||(state[1]==Failed)))&&((state[2]==Succeeded)||(state[2]==Failed)))&&!(((state[1]==Succeeded)&&(state[2]==Succeeded)))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][290] = 1;
		if (!(((((now.state[0]==3)&&((now.state[1]==2)||(now.state[1]==1)))&&((now.state[2]==2)||(now.state[2]==1)))&& !(((now.state[1]==2)&&(now.state[2]==2))))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 92: // STATE 291 - hybrid.pml:48 - [assert((state[0]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][291] = 1;
		spin_assert((now.state[0]==3), "(state[0]==3)", II, tt, t);
		/* merge: reply_to[0] = 0(328, 292, 328) */
		reached[0][292] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[0]);
		now.reply_to[0] = 0;
#ifdef VAR_RANGES
		logval("reply_to[0]", ((int)now.reply_to[0]));
#endif
		;
		/* merge: assert((reply_to[0]==0))(328, 293, 328) */
		reached[0][293] = 1;
		spin_assert((((int)now.reply_to[0])==0), "(reply_to[0]==0)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))(328, 294, 328) */
		reached[0][294] = 1;
		spin_assert((((((((((((((((((int)now.recipient[0])==0)&&(((int)now.sender[0])==1))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==0)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==3)))||((((int)now.recipient[0])==3)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==5)))||((((int)now.recipient[0])==5)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==6)))||((((int)now.recipient[0])==6)&&(((int)now.sender[0])==1))), "(((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1)))", II, tt, t);
		/* merge: state[0] = 1(328, 295, 328) */
		reached[0][295] = 1;
		(trpt+1)->bup.ovals[1] = now.state[0];
		now.state[0] = 1;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 93: // STATE 298 - hybrid.pml:116 - [(((state[0]==Received)&&((state[7]==Succeeded)||(state[7]==Failed))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][298] = 1;
		if (!(((now.state[0]==3)&&((now.state[7]==2)||(now.state[7]==1)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 94: // STATE 299 - hybrid.pml:60 - [((state[7]==Succeeded))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][299] = 1;
		if (!((now.state[7]==2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 95: // STATE 300 - hybrid.pml:48 - [assert((state[0]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][300] = 1;
		spin_assert((now.state[0]==3), "(state[0]==3)", II, tt, t);
		/* merge: reply_to[0] = 0(328, 301, 328) */
		reached[0][301] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[0]);
		now.reply_to[0] = 0;
#ifdef VAR_RANGES
		logval("reply_to[0]", ((int)now.reply_to[0]));
#endif
		;
		/* merge: assert((reply_to[0]==0))(328, 302, 328) */
		reached[0][302] = 1;
		spin_assert((((int)now.reply_to[0])==0), "(reply_to[0]==0)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))(328, 303, 328) */
		reached[0][303] = 1;
		spin_assert((((((((((((((((((int)now.recipient[0])==0)&&(((int)now.sender[0])==1))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==0)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==3)))||((((int)now.recipient[0])==3)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==5)))||((((int)now.recipient[0])==5)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==6)))||((((int)now.recipient[0])==6)&&(((int)now.sender[0])==1))), "(((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1)))", II, tt, t);
		/* merge: state[0] = 2(328, 304, 328) */
		reached[0][304] = 1;
		(trpt+1)->bup.ovals[1] = now.state[0];
		now.state[0] = 2;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: .(goto)(328, 314, 328) */
		reached[0][314] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 96: // STATE 314 - hybrid.pml:63 - [.(goto)] (0:328:0 - 2)
		IfNotBlocked
		reached[0][314] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 97: // STATE 306 - hybrid.pml:61 - [((state[7]==Failed))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][306] = 1;
		if (!((now.state[7]==1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 98: // STATE 307 - hybrid.pml:48 - [assert((state[0]==Received))] (0:328:2 - 1)
		IfNotBlocked
		reached[0][307] = 1;
		spin_assert((now.state[0]==3), "(state[0]==3)", II, tt, t);
		/* merge: reply_to[0] = 0(328, 308, 328) */
		reached[0][308] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.reply_to[0]);
		now.reply_to[0] = 0;
#ifdef VAR_RANGES
		logval("reply_to[0]", ((int)now.reply_to[0]));
#endif
		;
		/* merge: assert((reply_to[0]==0))(328, 309, 328) */
		reached[0][309] = 1;
		spin_assert((((int)now.reply_to[0])==0), "(reply_to[0]==0)", II, tt, t);
		/* merge: assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))(328, 310, 328) */
		reached[0][310] = 1;
		spin_assert((((((((((((((((((int)now.recipient[0])==0)&&(((int)now.sender[0])==1))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==0)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==1)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==3)))||((((int)now.recipient[0])==3)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==2)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==2)))||((((int)now.recipient[0])==4)&&(((int)now.sender[0])==5)))||((((int)now.recipient[0])==5)&&(((int)now.sender[0])==4)))||((((int)now.recipient[0])==1)&&(((int)now.sender[0])==6)))||((((int)now.recipient[0])==6)&&(((int)now.sender[0])==1))), "(((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1)))", II, tt, t);
		/* merge: state[0] = 1(328, 311, 328) */
		reached[0][311] = 1;
		(trpt+1)->bup.ovals[1] = now.state[0];
		now.state[0] = 1;
#ifdef VAR_RANGES
		logval("state[0]", now.state[0]);
#endif
		;
		/* merge: .(goto)(328, 314, 328) */
		reached[0][314] = 1;
		;
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 99: // STATE 317 - hybrid.pml:121 - [((observer_reads<2))] (328:0:3 - 1)
		IfNotBlocked
		reached[0][317] = 1;
		if (!((((int)now.observer_reads)<2)))
			continue;
		/* merge: observed_dispatches = dispatches(328, 318, 328) */
		reached[0][318] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)now.observed_dispatches);
		now.observed_dispatches = ((int)now.dispatches);
#ifdef VAR_RANGES
		logval("observed_dispatches", ((int)now.observed_dispatches));
#endif
		;
		/* merge: dispatches = (dispatches+1)(328, 319, 328) */
		reached[0][319] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.dispatches);
		now.dispatches = (((int)now.dispatches)+1);
#ifdef VAR_RANGES
		logval("dispatches", ((int)now.dispatches));
#endif
		;
		/* merge: observer_reads = (observer_reads+1)(328, 320, 328) */
		reached[0][320] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.observer_reads);
		now.observer_reads = (((int)now.observer_reads)+1);
#ifdef VAR_RANGES
		logval("observer_reads", ((int)now.observer_reads));
#endif
		;
		/* merge: assert((observed_dispatches==dispatches))(328, 321, 328) */
		reached[0][321] = 1;
		spin_assert((((int)now.observed_dispatches)==((int)now.dispatches)), "(observed_dispatches==dispatches)", II, tt, t);
		/* merge: .(goto)(0, 329, 328) */
		reached[0][329] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 100: // STATE 323 - hybrid.pml:133 - [(((state[0]==Succeeded)||(state[0]==Failed)))] (331:0:1 - 1)
		IfNotBlocked
		reached[0][323] = 1;
		if (!(((now.state[0]==2)||(now.state[0]==1))))
			continue;
		/* merge: assert(((state[0]!=Succeeded)||(((state[1]==Succeeded)&&(state[2]==Succeeded))&&(state[7]==Succeeded))))(331, 324, 331) */
		reached[0][324] = 1;
		spin_assert(((now.state[0]!=2)||(((now.state[1]==2)&&(now.state[2]==2))&&(now.state[7]==2))), "((state[0]!=2)||(((state[1]==2)&&(state[2]==2))&&(state[7]==2)))", II, tt, t);
		/* merge: done = 1(331, 325, 331) */
		reached[0][325] = 1;
		(trpt+1)->bup.oval = ((int)now.done);
		now.done = 1;
#ifdef VAR_RANGES
		logval("done", ((int)now.done));
#endif
		;
		/* merge: goto :b1(331, 326, 331) */
		reached[0][326] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 101: // STATE 331 - hybrid.pml:142 - [-end-] (0:0:0 - 2)
		IfNotBlocked
		reached[0][331] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

