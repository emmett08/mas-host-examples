#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM controller_settles */
	case 3: // STATE 1 - _spin_nvr.tmp:4 - [(!(((((workers_done==2)&&expiry_done)&&publisher_done)&&(phase!=Applying))))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[4][1] = 1;
		if (!( !(((((((int)now.workers_done)==2)&&((int)now.expiry_done))&&((int)now.publisher_done))&&(now.phase!=6)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 6 - _spin_nvr.tmp:6 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported6 = 0;
			if (verbose && !reported6)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported6 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[4][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - controller.pml:294 - [rejection_class = 0] (0:19:2 - 1)
		IfNotBlocked
		reached[3][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)_this)->rejection_class);
		((P3 *)_this)->rejection_class = 0;
#ifdef VAR_RANGES
		logval(":init::rejection_class", ((int)((P3 *)_this)->rejection_class));
#endif
		;
		/* merge: .(goto)(19, 15, 19) */
		reached[3][15] = 1;
		;
		/* merge: source_uid[0] = 1(19, 16, 19) */
		reached[3][16] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.source_uid[0]);
		now.source_uid[0] = 1;
#ifdef VAR_RANGES
		logval("source_uid[0]", ((int)now.source_uid[0]));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 6: // STATE 2 - controller.pml:295 - [rejection_class = 1] (0:19:4 - 1)
		IfNotBlocked
		reached[3][2] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)_this)->rejection_class);
		((P3 *)_this)->rejection_class = 1;
#ifdef VAR_RANGES
		logval(":init::rejection_class", ((int)((P3 *)_this)->rejection_class));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: rejection_class */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->rejection_class = 0;
		/* merge: controller_enabled = 0(19, 3, 19) */
		reached[3][3] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.controller_enabled);
		now.controller_enabled = 0;
#ifdef VAR_RANGES
		logval("controller_enabled", ((int)now.controller_enabled));
#endif
		;
		/* merge: .(goto)(19, 15, 19) */
		reached[3][15] = 1;
		;
		/* merge: source_uid[0] = 1(19, 16, 19) */
		reached[3][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.source_uid[0]);
		now.source_uid[0] = 1;
#ifdef VAR_RANGES
		logval("source_uid[0]", ((int)now.source_uid[0]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 7: // STATE 4 - controller.pml:296 - [rejection_class = 2] (0:19:4 - 1)
		IfNotBlocked
		reached[3][4] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)_this)->rejection_class);
		((P3 *)_this)->rejection_class = 2;
#ifdef VAR_RANGES
		logval(":init::rejection_class", ((int)((P3 *)_this)->rejection_class));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: rejection_class */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->rejection_class = 0;
		/* merge: source_bound = 0(19, 5, 19) */
		reached[3][5] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.source_bound);
		now.source_bound = 0;
#ifdef VAR_RANGES
		logval("source_bound", ((int)now.source_bound));
#endif
		;
		/* merge: .(goto)(19, 15, 19) */
		reached[3][15] = 1;
		;
		/* merge: source_uid[0] = 1(19, 16, 19) */
		reached[3][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.source_uid[0]);
		now.source_uid[0] = 1;
#ifdef VAR_RANGES
		logval("source_uid[0]", ((int)now.source_uid[0]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 8: // STATE 6 - controller.pml:297 - [rejection_class = 3] (0:19:4 - 1)
		IfNotBlocked
		reached[3][6] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)_this)->rejection_class);
		((P3 *)_this)->rejection_class = 3;
#ifdef VAR_RANGES
		logval(":init::rejection_class", ((int)((P3 *)_this)->rejection_class));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: rejection_class */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->rejection_class = 0;
		/* merge: evidence_fresh = 0(19, 7, 19) */
		reached[3][7] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.evidence_fresh);
		now.evidence_fresh = 0;
#ifdef VAR_RANGES
		logval("evidence_fresh", ((int)now.evidence_fresh));
#endif
		;
		/* merge: .(goto)(19, 15, 19) */
		reached[3][15] = 1;
		;
		/* merge: source_uid[0] = 1(19, 16, 19) */
		reached[3][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.source_uid[0]);
		now.source_uid[0] = 1;
#ifdef VAR_RANGES
		logval("source_uid[0]", ((int)now.source_uid[0]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 9: // STATE 8 - controller.pml:298 - [rejection_class = 4] (0:19:4 - 1)
		IfNotBlocked
		reached[3][8] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)_this)->rejection_class);
		((P3 *)_this)->rejection_class = 4;
#ifdef VAR_RANGES
		logval(":init::rejection_class", ((int)((P3 *)_this)->rejection_class));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: rejection_class */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->rejection_class = 0;
		/* merge: evidence_valid = 0(19, 9, 19) */
		reached[3][9] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.evidence_valid);
		now.evidence_valid = 0;
#ifdef VAR_RANGES
		logval("evidence_valid", ((int)now.evidence_valid));
#endif
		;
		/* merge: .(goto)(19, 15, 19) */
		reached[3][15] = 1;
		;
		/* merge: source_uid[0] = 1(19, 16, 19) */
		reached[3][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.source_uid[0]);
		now.source_uid[0] = 1;
#ifdef VAR_RANGES
		logval("source_uid[0]", ((int)now.source_uid[0]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 10: // STATE 10 - controller.pml:299 - [rejection_class = 5] (0:19:4 - 1)
		IfNotBlocked
		reached[3][10] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)_this)->rejection_class);
		((P3 *)_this)->rejection_class = 5;
#ifdef VAR_RANGES
		logval(":init::rejection_class", ((int)((P3 *)_this)->rejection_class));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: rejection_class */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->rejection_class = 0;
		/* merge: policy_allowed = 0(19, 11, 19) */
		reached[3][11] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.policy_allowed);
		now.policy_allowed = 0;
#ifdef VAR_RANGES
		logval("policy_allowed", ((int)now.policy_allowed));
#endif
		;
		/* merge: .(goto)(19, 15, 19) */
		reached[3][15] = 1;
		;
		/* merge: source_uid[0] = 1(19, 16, 19) */
		reached[3][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.source_uid[0]);
		now.source_uid[0] = 1;
#ifdef VAR_RANGES
		logval("source_uid[0]", ((int)now.source_uid[0]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 11: // STATE 12 - controller.pml:300 - [rejection_class = 6] (0:19:4 - 1)
		IfNotBlocked
		reached[3][12] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)_this)->rejection_class);
		((P3 *)_this)->rejection_class = 6;
#ifdef VAR_RANGES
		logval(":init::rejection_class", ((int)((P3 *)_this)->rejection_class));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: rejection_class */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->rejection_class = 0;
		/* merge: target_identity_matches = 0(19, 13, 19) */
		reached[3][13] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.target_identity_matches);
		now.target_identity_matches = 0;
#ifdef VAR_RANGES
		logval("target_identity_matches", ((int)now.target_identity_matches));
#endif
		;
		/* merge: .(goto)(19, 15, 19) */
		reached[3][15] = 1;
		;
		/* merge: source_uid[0] = 1(19, 16, 19) */
		reached[3][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.source_uid[0]);
		now.source_uid[0] = 1;
#ifdef VAR_RANGES
		logval("source_uid[0]", ((int)now.source_uid[0]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 12: // STATE 16 - controller.pml:302 - [source_uid[0] = 1] (0:19:1 - 8)
		IfNotBlocked
		reached[3][16] = 1;
		(trpt+1)->bup.oval = ((int)now.source_uid[0]);
		now.source_uid[0] = 1;
#ifdef VAR_RANGES
		logval("source_uid[0]", ((int)now.source_uid[0]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 17 - controller.pml:303 - [source_uid[1] = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[3][17] = 1;
		(trpt+1)->bup.oval = ((int)now.source_uid[1]);
		now.source_uid[1] = 1;
#ifdef VAR_RANGES
		logval("source_uid[1]", ((int)now.source_uid[1]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 18 - controller.pml:303 - [source_uid[1] = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[3][18] = 1;
		(trpt+1)->bup.oval = ((int)now.source_uid[1]);
		now.source_uid[1] = 2;
#ifdef VAR_RANGES
		logval("source_uid[1]", ((int)now.source_uid[1]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 15: // STATE 21 - controller.pml:304 - [(run Worker(0))] (0:0:0 - 3)
		IfNotBlocked
		reached[3][21] = 1;
		if (!(addproc(II, 1, 0, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 16: // STATE 22 - controller.pml:304 - [(run Worker(1))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][22] = 1;
		if (!(addproc(II, 1, 0, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 17: // STATE 23 - controller.pml:304 - [(run Expiry())] (0:0:0 - 1)
		IfNotBlocked
		reached[3][23] = 1;
		if (!(addproc(II, 1, 1, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 18: // STATE 24 - controller.pml:304 - [(run Outbox())] (0:0:0 - 1)
		IfNotBlocked
		reached[3][24] = 1;
		if (!(addproc(II, 1, 2, 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 19: // STATE 26 - controller.pml:306 - [((((workers_done==2)&&expiry_done)&&publisher_done))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][26] = 1;
		if (!((((((int)now.workers_done)==2)&&((int)now.expiry_done))&&((int)now.publisher_done))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 20: // STATE 27 - controller.pml:307 - [assert((effects<=1))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][27] = 1;
		spin_assert((((int)now.effects)<=1), "(effects<=1)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 21: // STATE 28 - controller.pml:308 - [assert((phase!=Applying))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][28] = 1;
		spin_assert((now.phase!=6), "(phase!=6)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 22: // STATE 29 - controller.pml:309 - [assert(((durable_report==NoReport)||(durable_report==first_report)))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][29] = 1;
		spin_assert(((now.durable_report==4)||(now.durable_report==now.first_report)), "((durable_report==4)||(durable_report==first_report))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 23: // STATE 30 - controller.pml:316 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[3][30] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Outbox */
	case 24: // STATE 1 - controller.pml:246 - [((phase==Finished))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][1] = 1;
		if (!((now.phase==5)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 25: // STATE 3 - controller.pml:247 - [((((workers_done==2)&&expiry_done)&&(phase!=Applying)))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][3] = 1;
		if (!((((((int)now.workers_done)==2)&&((int)now.expiry_done))&&(now.phase!=6))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 26: // STATE 8 - controller.pml:253 - [((attempt<2))] (14:0:1 - 1)
		IfNotBlocked
		reached[2][8] = 1;
		if (!((((int)((P2 *)_this)->attempt)<2)))
			continue;
		/* merge: attempt = (attempt+1)(0, 9, 14) */
		reached[2][9] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->attempt);
		((P2 *)_this)->attempt = (((int)((P2 *)_this)->attempt)+1);
#ifdef VAR_RANGES
		logval("Outbox:attempt", ((int)((P2 *)_this)->attempt));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 27: // STATE 10 - controller.pml:60 - [authenticated = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[2][10] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->authenticated);
		((P2 *)_this)->authenticated = 1;
#ifdef VAR_RANGES
		logval("Outbox:authenticated", ((int)((P2 *)_this)->authenticated));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 28: // STATE 11 - controller.pml:60 - [authenticated = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[2][11] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->authenticated);
		((P2 *)_this)->authenticated = 0;
#ifdef VAR_RANGES
		logval("Outbox:authenticated", ((int)((P2 *)_this)->authenticated));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 29: // STATE 15 - controller.pml:60 - [response_ack = 1] (0:0:2 - 1)
		IfNotBlocked
		reached[2][15] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P2 *)_this)->response_ack);
		((P2 *)_this)->response_ack = 1;
#ifdef VAR_RANGES
		logval("Outbox:response_ack", ((int)((P2 *)_this)->response_ack));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: response_ack */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->response_ack = 0;
		_m = 3; goto P999; /* 0 */
	case 30: // STATE 16 - controller.pml:60 - [response_ack = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[2][16] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->response_ack);
		((P2 *)_this)->response_ack = 0;
#ifdef VAR_RANGES
		logval("Outbox:response_ack", ((int)((P2 *)_this)->response_ack));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 31: // STATE 20 - controller.pml:258 - [(authenticated)] (0:0:1 - 1)
		IfNotBlocked
		reached[2][20] = 1;
		if (!(((int)((P2 *)_this)->authenticated)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: authenticated */  (trpt+1)->bup.oval = ((P2 *)_this)->authenticated;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->authenticated = 0;
		_m = 3; goto P999; /* 0 */
	case 32: // STATE 21 - controller.pml:260 - [assert(((phase==Finished)&&(durable_report!=NoReport)))] (0:28:0 - 1)
		IfNotBlocked
		reached[2][21] = 1;
		spin_assert(((now.phase==5)&&(now.durable_report!=4)), "((phase==5)&&(durable_report!=4))", II, tt, t);
		/* merge: assert((durable_report==first_report))(28, 22, 28) */
		reached[2][22] = 1;
		spin_assert((now.durable_report==now.first_report), "(durable_report==first_report)", II, tt, t);
		_m = 3; goto P999; /* 1 */
	case 33: // STATE 23 - controller.pml:263 - [((publications==0))] (36:0:3 - 1)
		IfNotBlocked
		reached[2][23] = 1;
		if (!((((int)now.publications)==0)))
			continue;
		/* merge: first_published_report = durable_report(36, 24, 36) */
		reached[2][24] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = now.first_published_report;
		now.first_published_report = now.durable_report;
#ifdef VAR_RANGES
		logval("first_published_report", now.first_published_report);
#endif
		;
		/* merge: first_published_source = journal_source(36, 25, 36) */
		reached[2][25] = 1;
		(trpt+1)->bup.ovals[1] = ((int)now.first_published_source);
		now.first_published_source = ((int)now.journal_source);
#ifdef VAR_RANGES
		logval("first_published_source", ((int)now.first_published_source));
#endif
		;
		/* merge: .(goto)(36, 29, 36) */
		reached[2][29] = 1;
		;
		/* merge: publications = (publications+1)(36, 30, 36) */
		reached[2][30] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.publications);
		now.publications = (((int)now.publications)+1);
#ifdef VAR_RANGES
		logval("publications", ((int)now.publications));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 34: // STATE 27 - controller.pml:267 - [assert(((durable_report==first_published_report)&&(journal_source==first_published_source)))] (0:36:1 - 1)
		IfNotBlocked
		reached[2][27] = 1;
		spin_assert(((now.durable_report==now.first_published_report)&&(((int)now.journal_source)==((int)now.first_published_source))), "((durable_report==first_published_report)&&(journal_source==first_published_source))", II, tt, t);
		/* merge: .(goto)(36, 29, 36) */
		reached[2][29] = 1;
		;
		/* merge: publications = (publications+1)(36, 30, 36) */
		reached[2][30] = 1;
		(trpt+1)->bup.oval = ((int)now.publications);
		now.publications = (((int)now.publications)+1);
#ifdef VAR_RANGES
		logval("publications", ((int)now.publications));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 35: // STATE 30 - controller.pml:269 - [publications = (publications+1)] (0:36:1 - 3)
		IfNotBlocked
		reached[2][30] = 1;
		(trpt+1)->bup.oval = ((int)now.publications);
		now.publications = (((int)now.publications)+1);
#ifdef VAR_RANGES
		logval("publications", ((int)now.publications));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 36: // STATE 31 - controller.pml:271 - [((durable_report==Verified))] (45:0:0 - 1)
		IfNotBlocked
		reached[2][31] = 1;
		if (!((now.durable_report==3)))
			continue;
		/* merge: assert((!(expired)&&(effects==1)))(45, 32, 45) */
		reached[2][32] = 1;
		spin_assert(( !(((int)now.expired))&&(((int)now.effects)==1)), "( !(expired)&&(effects==1))", II, tt, t);
		/* merge: assert(((((effect_by[0]&&original_claim_ack[0])&&patch_ack[0])&&recovery_complete[0])||(((effect_by[1]&&original_claim_ack[1])&&patch_ack[1])&&recovery_complete[1])))(45, 33, 45) */
		reached[2][33] = 1;
		spin_assert(((((((int)now.effect_by[0])&&((int)now.original_claim_ack[0]))&&((int)now.patch_ack[0]))&&((int)now.recovery_complete[0]))||(((((int)now.effect_by[1])&&((int)now.original_claim_ack[1]))&&((int)now.patch_ack[1]))&&((int)now.recovery_complete[1]))), "((((effect_by[0]&&original_claim_ack[0])&&patch_ack[0])&&recovery_complete[0])||(((effect_by[1]&&original_claim_ack[1])&&patch_ack[1])&&recovery_complete[1]))", II, tt, t);
		/* merge: .(goto)(45, 37, 45) */
		reached[2][37] = 1;
		;
		/* merge: .(goto)(0, 42, 45) */
		reached[2][42] = 1;
		;
		/* merge: .(goto)(0, 46, 45) */
		reached[2][46] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 37: // STATE 37 - controller.pml:276 - [.(goto)] (0:45:0 - 2)
		IfNotBlocked
		reached[2][37] = 1;
		;
		/* merge: .(goto)(0, 42, 45) */
		reached[2][42] = 1;
		;
		/* merge: .(goto)(0, 46, 45) */
		reached[2][46] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 38: // STATE 35 - controller.pml:274 - [(1)] (45:0:0 - 1)
		IfNotBlocked
		reached[2][35] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(45, 37, 45) */
		reached[2][37] = 1;
		;
		/* merge: .(goto)(0, 42, 45) */
		reached[2][42] = 1;
		;
		/* merge: .(goto)(0, 46, 45) */
		reached[2][46] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 39: // STATE 39 - controller.pml:277 - [(!(authenticated))] (0:0:1 - 1)
		IfNotBlocked
		reached[2][39] = 1;
		if (!( !(((int)((P2 *)_this)->authenticated))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: authenticated */  (trpt+1)->bup.oval = ((P2 *)_this)->authenticated;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->authenticated = 0;
		_m = 3; goto P999; /* 0 */
	case 40: // STATE 43 - controller.pml:279 - [((attempt==2))] (0:0:1 - 1)
		IfNotBlocked
		reached[2][43] = 1;
		if (!((((int)((P2 *)_this)->attempt)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: attempt */  (trpt+1)->bup.oval = ((P2 *)_this)->attempt;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->attempt = 0;
		_m = 3; goto P999; /* 0 */
	case 41: // STATE 48 - controller.pml:282 - [publisher_done = 1] (0:0:1 - 5)
		IfNotBlocked
		reached[2][48] = 1;
		(trpt+1)->bup.oval = ((int)now.publisher_done);
		now.publisher_done = 1;
#ifdef VAR_RANGES
		logval("publisher_done", ((int)now.publisher_done));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 42: // STATE 49 - controller.pml:283 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[2][49] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Expiry */
	case 43: // STATE 1 - controller.pml:224 - [((phase==Applying))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][1] = 1;
		if (!((now.phase==6)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 44: // STATE 2 - controller.pml:230 - [((phase==Applying))] (9:0:1 - 1)
		IfNotBlocked
		reached[1][2] = 1;
		if (!((now.phase==6)))
			continue;
		/* merge: expired = 1(0, 3, 9) */
		reached[1][3] = 1;
		(trpt+1)->bup.oval = ((int)now.expired);
		now.expired = 1;
#ifdef VAR_RANGES
		logval("expired", ((int)now.expired));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 45: // STATE 4 - controller.pml:67 - [assert((durable_report==NoReport))] (0:23:4 - 1)
		IfNotBlocked
		reached[1][4] = 1;
		spin_assert((now.durable_report==4), "(durable_report==4)", II, tt, t);
		/* merge: durable_report = 1(23, 5, 23) */
		reached[1][5] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.durable_report;
		now.durable_report = 1;
#ifdef VAR_RANGES
		logval("durable_report", now.durable_report);
#endif
		;
		/* merge: first_report = 1(23, 6, 23) */
		reached[1][6] = 1;
		(trpt+1)->bup.ovals[1] = now.first_report;
		now.first_report = 1;
#ifdef VAR_RANGES
		logval("first_report", now.first_report);
#endif
		;
		/* merge: phase = Finished(23, 7, 23) */
		reached[1][7] = 1;
		(trpt+1)->bup.ovals[2] = now.phase;
		now.phase = 5;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: resource_version = (resource_version+1)(23, 8, 23) */
		reached[1][8] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.resource_version);
		now.resource_version = (((int)now.resource_version)+1);
#ifdef VAR_RANGES
		logval("resource_version", ((int)now.resource_version));
#endif
		;
		/* merge: .(goto)(23, 13, 23) */
		reached[1][13] = 1;
		;
		/* merge: goto :b0(0, 15, 23) */
		reached[1][15] = 1;
		;
		_m = 3; goto P999; /* 6 */
	case 46: // STATE 13 - controller.pml:233 - [.(goto)] (0:23:0 - 2)
		IfNotBlocked
		reached[1][13] = 1;
		;
		/* merge: goto :b0(0, 15, 23) */
		reached[1][15] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 47: // STATE 11 - controller.pml:231 - [(1)] (23:0:0 - 1)
		IfNotBlocked
		reached[1][11] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(23, 13, 23) */
		reached[1][13] = 1;
		;
		/* merge: goto :b0(0, 15, 23) */
		reached[1][15] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 48: // STATE 16 - controller.pml:235 - [((phase==Finished))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][16] = 1;
		if (!((now.phase==5)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 49: // STATE 18 - controller.pml:236 - [(((workers_done==2)&&(phase!=Applying)))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][18] = 1;
		if (!(((((int)now.workers_done)==2)&&(now.phase!=6))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 50: // STATE 23 - controller.pml:238 - [expiry_done = 1] (0:0:1 - 7)
		IfNotBlocked
		reached[1][23] = 1;
		(trpt+1)->bup.oval = ((int)now.expiry_done);
		now.expiry_done = 1;
#ifdef VAR_RANGES
		logval("expiry_done", ((int)now.expiry_done));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 51: // STATE 24 - controller.pml:239 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[1][24] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Worker */
	case 52: // STATE 1 - controller.pml:89 - [((((((controller_enabled&&source_bound)&&1)&&evidence_valid)&&policy_allowed)&&target_identity_matches))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		if (!((((((((int)now.controller_enabled)&&((int)now.source_bound))&&1)&&((int)now.evidence_valid))&&((int)now.policy_allowed))&&((int)now.target_identity_matches))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 53: // STATE 3 - controller.pml:90 - [(!((((((controller_enabled&&source_bound)&&1)&&evidence_valid)&&policy_allowed)&&target_identity_matches)))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][3] = 1;
		if (!( !((((((((int)now.controller_enabled)&&((int)now.source_bound))&&1)&&((int)now.evidence_valid))&&((int)now.policy_allowed))&&((int)now.target_identity_matches)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 54: // STATE 7 - controller.pml:95 - [seen_phase = phase] (0:42:2 - 1)
		IfNotBlocked
		reached[0][7] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->seen_phase;
		((P0 *)_this)->seen_phase = now.phase;
#ifdef VAR_RANGES
		logval("Worker:seen_phase", ((P0 *)_this)->seen_phase);
#endif
		;
		/* merge: seen_version = resource_version(42, 8, 42) */
		reached[0][8] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->seen_version);
		((P0 *)_this)->seen_version = ((int)now.resource_version);
#ifdef VAR_RANGES
		logval("Worker:seen_version", ((int)((P0 *)_this)->seen_version));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 55: // STATE 10 - controller.pml:97 - [((seen_phase==Missing))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][10] = 1;
		if (!((((P0 *)_this)->seen_phase==8)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: seen_phase */  (trpt+1)->bup.oval = ((P0 *)_this)->seen_phase;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->seen_phase = 0;
		_m = 3; goto P999; /* 0 */
	case 56: // STATE 11 - controller.pml:100 - [(((phase==Missing)&&(resource_version==seen_version)))] (38:0:5 - 1)
		IfNotBlocked
		reached[0][11] = 1;
		if (!(((now.phase==8)&&(((int)now.resource_version)==((int)((P0 *)_this)->seen_version)))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: seen_version */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->seen_version;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->seen_version = 0;
		/* merge: phase = Pending(38, 12, 38) */
		reached[0][12] = 1;
		(trpt+1)->bup.ovals[1] = now.phase;
		now.phase = 7;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: journal_source = source_uid[id](38, 13, 38) */
		reached[0][13] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.journal_source);
		now.journal_source = ((int)now.source_uid[ Index(((int)((P0 *)_this)->id), 2) ]);
#ifdef VAR_RANGES
		logval("journal_source", ((int)now.journal_source));
#endif
		;
		/* merge: resource_version = (resource_version+1)(38, 14, 38) */
		reached[0][14] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.resource_version);
		now.resource_version = (((int)now.resource_version)+1);
#ifdef VAR_RANGES
		logval("resource_version", ((int)now.resource_version));
#endif
		;
		/* merge: create_ok = 1(38, 15, 38) */
		reached[0][15] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P0 *)_this)->create_ok);
		((P0 *)_this)->create_ok = 1;
#ifdef VAR_RANGES
		logval("Worker:create_ok", ((int)((P0 *)_this)->create_ok));
#endif
		;
		/* merge: .(goto)(38, 19, 38) */
		reached[0][19] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 57: // STATE 19 - controller.pml:105 - [.(goto)] (0:38:0 - 2)
		IfNotBlocked
		reached[0][19] = 1;
		;
		_m = 3; goto P999; /* 0 */
	case 58: // STATE 17 - controller.pml:103 - [create_ok = 0] (0:38:1 - 1)
		IfNotBlocked
		reached[0][17] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->create_ok);
		((P0 *)_this)->create_ok = 0;
#ifdef VAR_RANGES
		logval("Worker:create_ok", ((int)((P0 *)_this)->create_ok));
#endif
		;
		/* merge: .(goto)(38, 19, 38) */
		reached[0][19] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 59: // STATE 21 - controller.pml:107 - [(!(create_ok))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][21] = 1;
		if (!( !(((int)((P0 *)_this)->create_ok))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: create_ok */  (trpt+1)->bup.oval = ((P0 *)_this)->create_ok;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->create_ok = 0;
		_m = 3; goto P999; /* 0 */
	case 60: // STATE 23 - controller.pml:108 - [(create_ok)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][23] = 1;
		if (!(((int)((P0 *)_this)->create_ok)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: create_ok */  (trpt+1)->bup.oval = ((P0 *)_this)->create_ok;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->create_ok = 0;
		_m = 3; goto P999; /* 0 */
	case 61: // STATE 24 - controller.pml:60 - [create_ack = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][24] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->create_ack);
		((P0 *)_this)->create_ack = 1;
#ifdef VAR_RANGES
		logval("Worker:create_ack", ((int)((P0 *)_this)->create_ack));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 62: // STATE 25 - controller.pml:60 - [create_ack = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][25] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->create_ack);
		((P0 *)_this)->create_ack = 0;
#ifdef VAR_RANGES
		logval("Worker:create_ack", ((int)((P0 *)_this)->create_ack));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 63: // STATE 29 - controller.pml:113 - [lost_create_ack[id] = !(create_ack)] (0:0:1 - 3)
		IfNotBlocked
		reached[0][29] = 1;
		(trpt+1)->bup.oval = ((int)now.lost_create_ack[ Index(((int)((P0 *)_this)->id), 2) ]);
		now.lost_create_ack[ Index(((P0 *)_this)->id, 2) ] =  !(((int)((P0 *)_this)->create_ack));
#ifdef VAR_RANGES
		logval("lost_create_ack[Worker:id]", ((int)now.lost_create_ack[ Index(((int)((P0 *)_this)->id), 2) ]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 64: // STATE 30 - controller.pml:118 - [(create_ack)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][30] = 1;
		if (!(((int)((P0 *)_this)->create_ack)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: create_ack */  (trpt+1)->bup.oval = ((P0 *)_this)->create_ack;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->create_ack = 0;
		_m = 3; goto P999; /* 0 */
	case 65: // STATE 31 - controller.pml:118 - [seen_phase = phase] (0:48:2 - 1)
		IfNotBlocked
		reached[0][31] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->seen_phase;
		((P0 *)_this)->seen_phase = now.phase;
#ifdef VAR_RANGES
		logval("Worker:seen_phase", ((P0 *)_this)->seen_phase);
#endif
		;
		/* merge: seen_version = resource_version(48, 32, 48) */
		reached[0][32] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->seen_version);
		((P0 *)_this)->seen_version = ((int)now.resource_version);
#ifdef VAR_RANGES
		logval("Worker:seen_version", ((int)((P0 *)_this)->seen_version));
#endif
		;
		/* merge: .(goto)(0, 37, 48) */
		reached[0][37] = 1;
		;
		/* merge: .(goto)(0, 39, 48) */
		reached[0][39] = 1;
		;
		/* merge: .(goto)(0, 43, 48) */
		reached[0][43] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 66: // STATE 34 - controller.pml:119 - [(!(create_ack))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][34] = 1;
		if (!( !(((int)((P0 *)_this)->create_ack))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: create_ack */  (trpt+1)->bup.oval = ((P0 *)_this)->create_ack;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->create_ack = 0;
		_m = 3; goto P999; /* 0 */
	case 67: // STATE 40 - controller.pml:123 - [((seen_phase!=Missing))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][40] = 1;
		if (!((((P0 *)_this)->seen_phase!=8)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 68: // STATE 44 - controller.pml:126 - [((journal_source!=source_uid[id]))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][44] = 1;
		if (!((((int)now.journal_source)!=((int)now.source_uid[ Index(((int)((P0 *)_this)->id), 2) ]))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: id */  (trpt+1)->bup.oval = ((P0 *)_this)->id;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->id = 0;
		_m = 3; goto P999; /* 0 */
	case 69: // STATE 46 - controller.pml:127 - [((journal_source==source_uid[id]))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][46] = 1;
		if (!((((int)now.journal_source)==((int)now.source_uid[ Index(((int)((P0 *)_this)->id), 2) ]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 70: // STATE 50 - controller.pml:130 - [((seen_phase==Pending))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][50] = 1;
		if (!((((P0 *)_this)->seen_phase==7)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: seen_phase */  (trpt+1)->bup.oval = ((P0 *)_this)->seen_phase;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->seen_phase = 0;
		_m = 3; goto P999; /* 0 */
	case 71: // STATE 51 - controller.pml:136 - [(((phase==Pending)&&(resource_version==seen_version)))] (59:0:4 - 1)
		IfNotBlocked
		reached[0][51] = 1;
		if (!(((now.phase==7)&&(((int)now.resource_version)==((int)((P0 *)_this)->seen_version)))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: seen_version */  (trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->seen_version;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->seen_version = 0;
		/* merge: phase = Applying(59, 52, 59) */
		reached[0][52] = 1;
		(trpt+1)->bup.ovals[1] = now.phase;
		now.phase = 6;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: owner = (id+1)(59, 53, 59) */
		reached[0][53] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.owner);
		now.owner = (((int)((P0 *)_this)->id)+1);
#ifdef VAR_RANGES
		logval("owner", ((int)now.owner));
#endif
		;
		/* merge: resource_version = (resource_version+1)(59, 54, 59) */
		reached[0][54] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.resource_version);
		now.resource_version = (((int)now.resource_version)+1);
#ifdef VAR_RANGES
		logval("resource_version", ((int)now.resource_version));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 72: // STATE 55 - controller.pml:60 - [original_claim_ack[id] = 1] (0:76:2 - 1)
		IfNotBlocked
		reached[0][55] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ]);
		now.original_claim_ack[ Index(((P0 *)_this)->id, 2) ] = 1;
#ifdef VAR_RANGES
		logval("original_claim_ack[Worker:id]", ((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ]));
#endif
		;
		/* merge: .(goto)(76, 58, 76) */
		reached[0][58] = 1;
		;
		/* merge: reserved = original_claim_ack[id](76, 60, 76) */
		reached[0][60] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->reserved);
		((P0 *)_this)->reserved = ((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ]);
#ifdef VAR_RANGES
		logval("Worker:reserved", ((int)((P0 *)_this)->reserved));
#endif
		;
		/* merge: .(goto)(76, 64, 76) */
		reached[0][64] = 1;
		;
		/* merge: .(goto)(0, 71, 76) */
		reached[0][71] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 73: // STATE 56 - controller.pml:60 - [original_claim_ack[id] = 0] (0:76:2 - 1)
		IfNotBlocked
		reached[0][56] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ]);
		now.original_claim_ack[ Index(((P0 *)_this)->id, 2) ] = 0;
#ifdef VAR_RANGES
		logval("original_claim_ack[Worker:id]", ((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ]));
#endif
		;
		/* merge: .(goto)(76, 58, 76) */
		reached[0][58] = 1;
		;
		/* merge: reserved = original_claim_ack[id](76, 60, 76) */
		reached[0][60] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->reserved);
		((P0 *)_this)->reserved = ((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ]);
#ifdef VAR_RANGES
		logval("Worker:reserved", ((int)((P0 *)_this)->reserved));
#endif
		;
		/* merge: .(goto)(76, 64, 76) */
		reached[0][64] = 1;
		;
		/* merge: .(goto)(0, 71, 76) */
		reached[0][71] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 74: // STATE 60 - controller.pml:143 - [reserved = original_claim_ack[id]] (0:76:1 - 3)
		IfNotBlocked
		reached[0][60] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->reserved);
		((P0 *)_this)->reserved = ((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ]);
#ifdef VAR_RANGES
		logval("Worker:reserved", ((int)((P0 *)_this)->reserved));
#endif
		;
		/* merge: .(goto)(76, 64, 76) */
		reached[0][64] = 1;
		;
		/* merge: .(goto)(0, 71, 76) */
		reached[0][71] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 75: // STATE 64 - controller.pml:146 - [.(goto)] (0:76:0 - 2)
		IfNotBlocked
		reached[0][64] = 1;
		;
		/* merge: .(goto)(0, 71, 76) */
		reached[0][71] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 76: // STATE 62 - controller.pml:144 - [reserved = 0] (0:76:1 - 1)
		IfNotBlocked
		reached[0][62] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->reserved);
		((P0 *)_this)->reserved = 0;
#ifdef VAR_RANGES
		logval("Worker:reserved", ((int)((P0 *)_this)->reserved));
#endif
		;
		/* merge: .(goto)(76, 64, 76) */
		reached[0][64] = 1;
		;
		/* merge: .(goto)(0, 71, 76) */
		reached[0][71] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 77: // STATE 66 - controller.pml:147 - [((seen_phase==Applying))] (76:0:2 - 1)
		IfNotBlocked
		reached[0][66] = 1;
		if (!((((P0 *)_this)->seen_phase==6)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: seen_phase */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->seen_phase;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->seen_phase = 0;
		/* merge: reserved = 0(0, 67, 76) */
		reached[0][67] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->reserved);
		((P0 *)_this)->reserved = 0;
#ifdef VAR_RANGES
		logval("Worker:reserved", ((int)((P0 *)_this)->reserved));
#endif
		;
		/* merge: .(goto)(0, 71, 76) */
		reached[0][71] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 78: // STATE 69 - controller.pml:153 - [reserved = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][69] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->reserved);
		((P0 *)_this)->reserved = 0;
#ifdef VAR_RANGES
		logval("Worker:reserved", ((int)((P0 *)_this)->reserved));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 79: // STATE 72 - controller.pml:156 - [(!(reserved))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][72] = 1;
		if (!( !(((int)((P0 *)_this)->reserved))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: reserved */  (trpt+1)->bup.oval = ((P0 *)_this)->reserved;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->reserved = 0;
		_m = 3; goto P999; /* 0 */
	case 80: // STATE 74 - controller.pml:157 - [(reserved)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][74] = 1;
		if (!(((int)((P0 *)_this)->reserved)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: reserved */  (trpt+1)->bup.oval = ((P0 *)_this)->reserved;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->reserved = 0;
		_m = 3; goto P999; /* 0 */
	case 81: // STATE 78 - controller.pml:60 - [fresh_after_claim = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][78] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->fresh_after_claim);
		((P0 *)_this)->fresh_after_claim = 1;
#ifdef VAR_RANGES
		logval("Worker:fresh_after_claim", ((int)((P0 *)_this)->fresh_after_claim));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 82: // STATE 79 - controller.pml:60 - [fresh_after_claim = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][79] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->fresh_after_claim);
		((P0 *)_this)->fresh_after_claim = 0;
#ifdef VAR_RANGES
		logval("Worker:fresh_after_claim", ((int)((P0 *)_this)->fresh_after_claim));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 83: // STATE 83 - controller.pml:163 - [(!(fresh_after_claim))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][83] = 1;
		if (!( !(((int)((P0 *)_this)->fresh_after_claim))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: fresh_after_claim */  (trpt+1)->bup.oval = ((P0 *)_this)->fresh_after_claim;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->fresh_after_claim = 0;
		_m = 3; goto P999; /* 0 */
	case 84: // STATE 85 - controller.pml:163 - [(fresh_after_claim)] (0:0:0 - 1)
		IfNotBlocked
		reached[0][85] = 1;
		if (!(((int)((P0 *)_this)->fresh_after_claim)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 85: // STATE 89 - controller.pml:60 - [crashed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][89] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->crashed);
		((P0 *)_this)->crashed = 1;
#ifdef VAR_RANGES
		logval("Worker:crashed", ((int)((P0 *)_this)->crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 86: // STATE 90 - controller.pml:60 - [crashed = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][90] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->crashed);
		((P0 *)_this)->crashed = 0;
#ifdef VAR_RANGES
		logval("Worker:crashed", ((int)((P0 *)_this)->crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 87: // STATE 94 - controller.pml:169 - [(crashed)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][94] = 1;
		if (!(((int)((P0 *)_this)->crashed)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: crashed */  (trpt+1)->bup.oval = ((P0 *)_this)->crashed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->crashed = 0;
		_m = 3; goto P999; /* 0 */
	case 88: // STATE 96 - controller.pml:169 - [(!(crashed))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][96] = 1;
		if (!( !(((int)((P0 *)_this)->crashed))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: crashed */  (trpt+1)->bup.oval = ((P0 *)_this)->crashed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->crashed = 0;
		_m = 3; goto P999; /* 0 */
	case 89: // STATE 100 - controller.pml:60 - [api_accepts = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][100] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->api_accepts);
		((P0 *)_this)->api_accepts = 1;
#ifdef VAR_RANGES
		logval("Worker:api_accepts", ((int)((P0 *)_this)->api_accepts));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 90: // STATE 101 - controller.pml:60 - [api_accepts = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][101] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->api_accepts);
		((P0 *)_this)->api_accepts = 0;
#ifdef VAR_RANGES
		logval("Worker:api_accepts", ((int)((P0 *)_this)->api_accepts));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 91: // STATE 105 - controller.pml:60 - [patch_tests = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][105] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->patch_tests);
		((P0 *)_this)->patch_tests = 1;
#ifdef VAR_RANGES
		logval("Worker:patch_tests", ((int)((P0 *)_this)->patch_tests));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 92: // STATE 106 - controller.pml:60 - [patch_tests = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][106] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->patch_tests);
		((P0 *)_this)->patch_tests = 0;
#ifdef VAR_RANGES
		logval("Worker:patch_tests", ((int)((P0 *)_this)->patch_tests));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 93: // STATE 110 - controller.pml:173 - [assert(original_claim_ack[id])] (0:122:0 - 1)
		IfNotBlocked
		reached[0][110] = 1;
		spin_assert(((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ]), "original_claim_ack[id]", II, tt, t);
		/* merge: assert(!(lost_create_ack[id]))(122, 111, 122) */
		reached[0][111] = 1;
		spin_assert( !(((int)now.lost_create_ack[ Index(((int)((P0 *)_this)->id), 2) ])), " !(lost_create_ack[id])", II, tt, t);
		/* merge: assert((journal_source==source_uid[id]))(122, 112, 122) */
		reached[0][112] = 1;
		spin_assert((((int)now.journal_source)==((int)now.source_uid[ Index(((int)((P0 *)_this)->id), 2) ])), "(journal_source==source_uid[id])", II, tt, t);
		/* merge: assert((controller_enabled&&source_bound))(122, 113, 122) */
		reached[0][113] = 1;
		spin_assert((((int)now.controller_enabled)&&((int)now.source_bound)), "(controller_enabled&&source_bound)", II, tt, t);
		/* merge: assert((evidence_fresh&&fresh_after_claim))(122, 114, 122) */
		reached[0][114] = 1;
		spin_assert((((int)now.evidence_fresh)&&((int)((P0 *)_this)->fresh_after_claim)), "(evidence_fresh&&fresh_after_claim)", II, tt, t);
		/* merge: assert((((((controller_enabled&&source_bound)&&evidence_fresh)&&evidence_valid)&&policy_allowed)&&target_identity_matches))(122, 115, 122) */
		reached[0][115] = 1;
		spin_assert((((((((int)now.controller_enabled)&&((int)now.source_bound))&&((int)now.evidence_fresh))&&((int)now.evidence_valid))&&((int)now.policy_allowed))&&((int)now.target_identity_matches)), "(((((controller_enabled&&source_bound)&&evidence_fresh)&&evidence_valid)&&policy_allowed)&&target_identity_matches)", II, tt, t);
		_m = 3; goto P999; /* 5 */
	case 94: // STATE 116 - controller.pml:180 - [((api_accepts&&patch_tests))] (129:0:4 - 1)
		IfNotBlocked
		reached[0][116] = 1;
		if (!((((int)((P0 *)_this)->api_accepts)&&((int)((P0 *)_this)->patch_tests))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: api_accepts */  (trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->api_accepts;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->api_accepts = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: patch_tests */  (trpt+1)->bup.ovals[1] = ((P0 *)_this)->patch_tests;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->patch_tests = 0;
		/* merge: effects = (effects+1)(129, 117, 129) */
		reached[0][117] = 1;
		(trpt+1)->bup.ovals[2] = ((int)now.effects);
		now.effects = (((int)now.effects)+1);
#ifdef VAR_RANGES
		logval("effects", ((int)now.effects));
#endif
		;
		/* merge: effect_by[id] = 1(129, 118, 129) */
		reached[0][118] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.effect_by[ Index(((int)((P0 *)_this)->id), 2) ]);
		now.effect_by[ Index(((P0 *)_this)->id, 2) ] = 1;
#ifdef VAR_RANGES
		logval("effect_by[Worker:id]", ((int)now.effect_by[ Index(((int)((P0 *)_this)->id), 2) ]));
#endif
		;
		/* merge: assert((effects<=1))(129, 119, 129) */
		reached[0][119] = 1;
		spin_assert((((int)now.effects)<=1), "(effects<=1)", II, tt, t);
		/* merge: .(goto)(129, 123, 129) */
		reached[0][123] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 95: // STATE 123 - controller.pml:185 - [.(goto)] (0:129:0 - 2)
		IfNotBlocked
		reached[0][123] = 1;
		;
		_m = 3; goto P999; /* 0 */
	case 96: // STATE 120 - controller.pml:183 - [(!((api_accepts&&patch_tests)))] (0:0:2 - 1)
		IfNotBlocked
		reached[0][120] = 1;
		if (!( !((((int)((P0 *)_this)->api_accepts)&&((int)((P0 *)_this)->patch_tests)))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: api_accepts */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->api_accepts;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->api_accepts = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: patch_tests */  (trpt+1)->bup.ovals[1] = ((P0 *)_this)->patch_tests;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->patch_tests = 0;
		_m = 3; goto P999; /* 0 */
	case 97: // STATE 121 - controller.pml:183 - [(1)] (129:0:0 - 1)
		IfNotBlocked
		reached[0][121] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(129, 123, 129) */
		reached[0][123] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 98: // STATE 125 - controller.pml:60 - [crashed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][125] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->crashed);
		((P0 *)_this)->crashed = 1;
#ifdef VAR_RANGES
		logval("Worker:crashed", ((int)((P0 *)_this)->crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 99: // STATE 126 - controller.pml:60 - [crashed = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][126] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->crashed);
		((P0 *)_this)->crashed = 0;
#ifdef VAR_RANGES
		logval("Worker:crashed", ((int)((P0 *)_this)->crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 100: // STATE 130 - controller.pml:187 - [(crashed)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][130] = 1;
		if (!(((int)((P0 *)_this)->crashed)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: crashed */  (trpt+1)->bup.oval = ((P0 *)_this)->crashed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->crashed = 0;
		_m = 3; goto P999; /* 0 */
	case 101: // STATE 132 - controller.pml:187 - [(!(crashed))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][132] = 1;
		if (!( !(((int)((P0 *)_this)->crashed))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: crashed */  (trpt+1)->bup.oval = ((P0 *)_this)->crashed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->crashed = 0;
		_m = 3; goto P999; /* 0 */
	case 102: // STATE 136 - controller.pml:60 - [patch_response = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][136] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->patch_response);
		((P0 *)_this)->patch_response = 1;
#ifdef VAR_RANGES
		logval("Worker:patch_response", ((int)((P0 *)_this)->patch_response));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 103: // STATE 137 - controller.pml:60 - [patch_response = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][137] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->patch_response);
		((P0 *)_this)->patch_response = 0;
#ifdef VAR_RANGES
		logval("Worker:patch_response", ((int)((P0 *)_this)->patch_response));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 104: // STATE 141 - controller.pml:190 - [patch_ack[id] = (effect_by[id]&&patch_response)] (0:0:1 - 3)
		IfNotBlocked
		reached[0][141] = 1;
		(trpt+1)->bup.oval = ((int)now.patch_ack[ Index(((int)((P0 *)_this)->id), 2) ]);
		now.patch_ack[ Index(((P0 *)_this)->id, 2) ] = (((int)now.effect_by[ Index(((int)((P0 *)_this)->id), 2) ])&&((int)((P0 *)_this)->patch_response));
#ifdef VAR_RANGES
		logval("patch_ack[Worker:id]", ((int)now.patch_ack[ Index(((int)((P0 *)_this)->id), 2) ]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 105: // STATE 142 - controller.pml:60 - [crashed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][142] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->crashed);
		((P0 *)_this)->crashed = 1;
#ifdef VAR_RANGES
		logval("Worker:crashed", ((int)((P0 *)_this)->crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 106: // STATE 143 - controller.pml:60 - [crashed = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][143] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->crashed);
		((P0 *)_this)->crashed = 0;
#ifdef VAR_RANGES
		logval("Worker:crashed", ((int)((P0 *)_this)->crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 107: // STATE 147 - controller.pml:192 - [(crashed)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][147] = 1;
		if (!(((int)((P0 *)_this)->crashed)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: crashed */  (trpt+1)->bup.oval = ((P0 *)_this)->crashed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->crashed = 0;
		_m = 3; goto P999; /* 0 */
	case 108: // STATE 149 - controller.pml:192 - [(!(crashed))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][149] = 1;
		if (!( !(((int)((P0 *)_this)->crashed))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: crashed */  (trpt+1)->bup.oval = ((P0 *)_this)->crashed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->crashed = 0;
		_m = 3; goto P999; /* 0 */
	case 109: // STATE 153 - controller.pml:60 - [all_recovery = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][153] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->all_recovery);
		((P0 *)_this)->all_recovery = 1;
#ifdef VAR_RANGES
		logval("Worker:all_recovery", ((int)((P0 *)_this)->all_recovery));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 110: // STATE 154 - controller.pml:60 - [all_recovery = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][154] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->all_recovery);
		((P0 *)_this)->all_recovery = 0;
#ifdef VAR_RANGES
		logval("Worker:all_recovery", ((int)((P0 *)_this)->all_recovery));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 111: // STATE 158 - controller.pml:199 - [recovery_complete[id] = (patch_ack[id]&&all_recovery)] (0:0:1 - 3)
		IfNotBlocked
		reached[0][158] = 1;
		(trpt+1)->bup.oval = ((int)now.recovery_complete[ Index(((int)((P0 *)_this)->id), 2) ]);
		now.recovery_complete[ Index(((P0 *)_this)->id, 2) ] = (((int)now.patch_ack[ Index(((int)((P0 *)_this)->id), 2) ])&&((int)((P0 *)_this)->all_recovery));
#ifdef VAR_RANGES
		logval("recovery_complete[Worker:id]", ((int)now.recovery_complete[ Index(((int)((P0 *)_this)->id), 2) ]));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 112: // STATE 159 - controller.pml:60 - [crashed = 1] (0:0:1 - 1)
		IfNotBlocked
		reached[0][159] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->crashed);
		((P0 *)_this)->crashed = 1;
#ifdef VAR_RANGES
		logval("Worker:crashed", ((int)((P0 *)_this)->crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 113: // STATE 160 - controller.pml:60 - [crashed = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[0][160] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->crashed);
		((P0 *)_this)->crashed = 0;
#ifdef VAR_RANGES
		logval("Worker:crashed", ((int)((P0 *)_this)->crashed));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 114: // STATE 164 - controller.pml:201 - [(crashed)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][164] = 1;
		if (!(((int)((P0 *)_this)->crashed)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: crashed */  (trpt+1)->bup.oval = ((P0 *)_this)->crashed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->crashed = 0;
		_m = 3; goto P999; /* 0 */
	case 115: // STATE 166 - controller.pml:201 - [(!(crashed))] (0:0:1 - 1)
		IfNotBlocked
		reached[0][166] = 1;
		if (!( !(((int)((P0 *)_this)->crashed))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: crashed */  (trpt+1)->bup.oval = ((P0 *)_this)->crashed;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->crashed = 0;
		_m = 3; goto P999; /* 0 */
	case 116: // STATE 170 - controller.pml:207 - [(((phase==Applying)&&(owner==(id+1))))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][170] = 1;
		if (!(((now.phase==6)&&(((int)now.owner)==(((int)((P0 *)_this)->id)+1)))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 117: // STATE 171 - controller.pml:209 - [((patch_ack[id]&&recovery_complete[id]))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][171] = 1;
		if (!((((int)now.patch_ack[ Index(((int)((P0 *)_this)->id), 2) ])&&((int)now.recovery_complete[ Index(((int)((P0 *)_this)->id), 2) ]))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 118: // STATE 172 - controller.pml:67 - [assert((durable_report==NoReport))] (0:192:4 - 1)
		IfNotBlocked
		reached[0][172] = 1;
		spin_assert((now.durable_report==4), "(durable_report==4)", II, tt, t);
		/* merge: durable_report = 3(192, 173, 192) */
		reached[0][173] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.durable_report;
		now.durable_report = 3;
#ifdef VAR_RANGES
		logval("durable_report", now.durable_report);
#endif
		;
		/* merge: first_report = 3(192, 174, 192) */
		reached[0][174] = 1;
		(trpt+1)->bup.ovals[1] = now.first_report;
		now.first_report = 3;
#ifdef VAR_RANGES
		logval("first_report", now.first_report);
#endif
		;
		/* merge: phase = Finished(192, 175, 192) */
		reached[0][175] = 1;
		(trpt+1)->bup.ovals[2] = now.phase;
		now.phase = 5;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: resource_version = (resource_version+1)(192, 176, 192) */
		reached[0][176] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.resource_version);
		now.resource_version = (((int)now.resource_version)+1);
#ifdef VAR_RANGES
		logval("resource_version", ((int)now.resource_version));
#endif
		;
		/* merge: .(goto)(192, 186, 192) */
		reached[0][186] = 1;
		;
		/* merge: assert(((durable_report!=Verified)||(((original_claim_ack[id]&&effect_by[id])&&patch_ack[id])&&recovery_complete[id])))(192, 187, 192) */
		reached[0][187] = 1;
		spin_assert(((now.durable_report!=3)||(((((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ])&&((int)now.effect_by[ Index(((int)((P0 *)_this)->id), 2) ]))&&((int)now.patch_ack[ Index(((int)((P0 *)_this)->id), 2) ]))&&((int)now.recovery_complete[ Index(((int)((P0 *)_this)->id), 2) ]))), "((durable_report!=3)||(((original_claim_ack[id]&&effect_by[id])&&patch_ack[id])&&recovery_complete[id]))", II, tt, t);
		_m = 3; goto P999; /* 6 */
	case 119: // STATE 178 - controller.pml:210 - [(!((patch_ack[id]&&recovery_complete[id])))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][178] = 1;
		if (!( !((((int)now.patch_ack[ Index(((int)((P0 *)_this)->id), 2) ])&&((int)now.recovery_complete[ Index(((int)((P0 *)_this)->id), 2) ])))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 120: // STATE 179 - controller.pml:67 - [assert((durable_report==NoReport))] (0:192:4 - 1)
		IfNotBlocked
		reached[0][179] = 1;
		spin_assert((now.durable_report==4), "(durable_report==4)", II, tt, t);
		/* merge: durable_report = 2(192, 180, 192) */
		reached[0][180] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = now.durable_report;
		now.durable_report = 2;
#ifdef VAR_RANGES
		logval("durable_report", now.durable_report);
#endif
		;
		/* merge: first_report = 2(192, 181, 192) */
		reached[0][181] = 1;
		(trpt+1)->bup.ovals[1] = now.first_report;
		now.first_report = 2;
#ifdef VAR_RANGES
		logval("first_report", now.first_report);
#endif
		;
		/* merge: phase = Finished(192, 182, 192) */
		reached[0][182] = 1;
		(trpt+1)->bup.ovals[2] = now.phase;
		now.phase = 5;
#ifdef VAR_RANGES
		logval("phase", now.phase);
#endif
		;
		/* merge: resource_version = (resource_version+1)(192, 183, 192) */
		reached[0][183] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.resource_version);
		now.resource_version = (((int)now.resource_version)+1);
#ifdef VAR_RANGES
		logval("resource_version", ((int)now.resource_version));
#endif
		;
		/* merge: .(goto)(192, 186, 192) */
		reached[0][186] = 1;
		;
		/* merge: assert(((durable_report!=Verified)||(((original_claim_ack[id]&&effect_by[id])&&patch_ack[id])&&recovery_complete[id])))(192, 187, 192) */
		reached[0][187] = 1;
		spin_assert(((now.durable_report!=3)||(((((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ])&&((int)now.effect_by[ Index(((int)((P0 *)_this)->id), 2) ]))&&((int)now.patch_ack[ Index(((int)((P0 *)_this)->id), 2) ]))&&((int)now.recovery_complete[ Index(((int)((P0 *)_this)->id), 2) ]))), "((durable_report!=3)||(((original_claim_ack[id]&&effect_by[id])&&patch_ack[id])&&recovery_complete[id]))", II, tt, t);
		_m = 3; goto P999; /* 6 */
	case 121: // STATE 187 - controller.pml:212 - [assert(((durable_report!=Verified)||(((original_claim_ack[id]&&effect_by[id])&&patch_ack[id])&&recovery_complete[id])))] (0:192:0 - 3)
		IfNotBlocked
		reached[0][187] = 1;
		spin_assert(((now.durable_report!=3)||(((((int)now.original_claim_ack[ Index(((int)((P0 *)_this)->id), 2) ])&&((int)now.effect_by[ Index(((int)((P0 *)_this)->id), 2) ]))&&((int)now.patch_ack[ Index(((int)((P0 *)_this)->id), 2) ]))&&((int)now.recovery_complete[ Index(((int)((P0 *)_this)->id), 2) ]))), "((durable_report!=3)||(((original_claim_ack[id]&&effect_by[id])&&patch_ack[id])&&recovery_complete[id]))", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 122: // STATE 188 - controller.pml:60 - [finish_ack = 1] (0:199:2 - 1)
		IfNotBlocked
		reached[0][188] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P0 *)_this)->finish_ack);
		((P0 *)_this)->finish_ack = 1;
#ifdef VAR_RANGES
		logval("Worker:finish_ack", ((int)((P0 *)_this)->finish_ack));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: finish_ack */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->finish_ack = 0;
		/* merge: .(goto)(199, 191, 199) */
		reached[0][191] = 1;
		;
		/* merge: .(goto)(199, 196, 199) */
		reached[0][196] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 123: // STATE 191 - controller.pml:60 - [.(goto)] (0:199:0 - 2)
		IfNotBlocked
		reached[0][191] = 1;
		;
		/* merge: .(goto)(199, 196, 199) */
		reached[0][196] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 124: // STATE 189 - controller.pml:60 - [finish_ack = 0] (0:199:1 - 1)
		IfNotBlocked
		reached[0][189] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->finish_ack);
		((P0 *)_this)->finish_ack = 0;
#ifdef VAR_RANGES
		logval("Worker:finish_ack", ((int)((P0 *)_this)->finish_ack));
#endif
		;
		/* merge: .(goto)(199, 191, 199) */
		reached[0][191] = 1;
		;
		/* merge: .(goto)(199, 196, 199) */
		reached[0][196] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 125: // STATE 196 - controller.pml:217 - [.(goto)] (0:199:0 - 2)
		IfNotBlocked
		reached[0][196] = 1;
		;
		_m = 3; goto P999; /* 0 */
	case 126: // STATE 194 - controller.pml:215 - [(1)] (199:0:0 - 1)
		IfNotBlocked
		reached[0][194] = 1;
		if (!(1))
			continue;
		/* merge: .(goto)(199, 196, 199) */
		reached[0][196] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 127: // STATE 198 - controller.pml:219 - [workers_done = (workers_done+1)] (0:0:1 - 1)
		IfNotBlocked
		reached[0][198] = 1;
		(trpt+1)->bup.oval = ((int)now.workers_done);
		now.workers_done = (((int)now.workers_done)+1);
#ifdef VAR_RANGES
		logval("workers_done", ((int)now.workers_done));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 128: // STATE 200 - controller.pml:220 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][200] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

