#ifdef PEG
struct T_SRC {
	char *fl; int ln;
} T_SRC[NTRANS];

void
tr_2_src(int m, char *file, int ln)
{	T_SRC[m].fl = file;
	T_SRC[m].ln = ln;
}

void
putpeg(int n, int m)
{	printf("%5d	trans %4d ", m, n);
	printf("%s:%d\n",
		T_SRC[n].fl, T_SRC[n].ln);
}
#endif

void
settable(void)
{	Trans *T;
	Trans *settr(int, int, int, int, int, char *, int, int, int);

	trans = (Trans ***) emalloc(3*sizeof(Trans **));

	/* proctype 1: choreography_settles */

	trans[1] = (Trans **) emalloc(7*sizeof(Trans *));

	trans[1][4]	= settr(347,0,3,1,0,".(goto)", 0, 2, 0);
	T = trans[1][3] = settr(346,0,0,0,0,"DO", 0, 2, 0);
	    T->nxt	= settr(346,0,1,0,0,"DO", 0, 2, 0);
	trans[1][1]	= settr(344,0,3,3,0,"(!(done))", 1, 2, 0);
	trans[1][2]	= settr(345,0,3,1,0,"goto T0_init", 0, 2, 0);
	trans[1][5]	= settr(348,0,6,1,0,"break", 0, 2, 0);
	trans[1][6]	= settr(349,0,0,4,4,"-end-", 0, 3500, 0);

	/* proctype 0: Choreography */

	trans[0] = (Trans **) emalloc(345*sizeof(Trans *));

	T = trans[ 0][38] = settr(37,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(37,2,1,0,0,"ATOMIC", 1, 2, 0);
	trans[0][1]	= settr(0,2,7,5,5,"i = 0", 1, 2, 0);
	trans[0][8]	= settr(7,2,7,1,0,".(goto)", 1, 2, 0);
	T = trans[0][7] = settr(6,2,0,0,0,"DO", 1, 2, 0);
	T = T->nxt	= settr(6,2,2,0,0,"DO", 1, 2, 0);
	    T->nxt	= settr(6,2,5,0,0,"DO", 1, 2, 0);
	trans[0][2]	= settr(1,2,7,6,6,"((i<8))", 1, 2, 0); /* m: 3 -> 7,0 */
	reached0[3] = 1;
	trans[0][3]	= settr(0,0,0,0,0,"state[i] = Absent",0,0,0);
	trans[0][4]	= settr(0,0,0,0,0,"i = (i+1)",0,0,0);
	trans[0][5]	= settr(4,2,10,2,0,"else", 1, 2, 0);
	trans[0][6]	= settr(5,2,10,1,0,"goto :b0", 1, 2, 0); /* m: 10 -> 0,37 */
	reached0[10] = 1;
	trans[0][9]	= settr(8,2,10,1,0,"break", 1, 2, 0);
	trans[0][10]	= settr(9,2,37,7,7,"sender[0] = 0", 1, 2, 0); /* m: 11 -> 0,37 */
	reached0[11] = 1;
	trans[0][11]	= settr(0,0,0,0,0,"recipient[0] = 1",0,0,0);
	trans[0][12]	= settr(0,0,0,0,0,"sender[1] = 1",0,0,0);
	trans[0][13]	= settr(0,0,0,0,0,"recipient[1] = 2",0,0,0);
	trans[0][14]	= settr(0,0,0,0,0,"sender[2] = 1",0,0,0);
	trans[0][15]	= settr(0,0,0,0,0,"recipient[2] = 4",0,0,0);
	trans[0][16]	= settr(0,0,0,0,0,"sender[3] = 2",0,0,0);
	trans[0][17]	= settr(0,0,0,0,0,"recipient[3] = 3",0,0,0);
	trans[0][18]	= settr(0,0,0,0,0,"sender[4] = 2",0,0,0);
	trans[0][19]	= settr(0,0,0,0,0,"recipient[4] = 4",0,0,0);
	trans[0][20]	= settr(0,0,0,0,0,"sender[5] = 4",0,0,0);
	trans[0][21]	= settr(0,0,0,0,0,"recipient[5] = 5",0,0,0);
	trans[0][22]	= settr(0,0,0,0,0,"sender[6] = 4",0,0,0);
	trans[0][23]	= settr(0,0,0,0,0,"recipient[6] = 5",0,0,0);
	trans[0][24]	= settr(0,0,0,0,0,"sender[7] = 1",0,0,0);
	trans[0][25]	= settr(0,0,0,0,0,"recipient[7] = 6",0,0,0);
	T = trans[ 0][37] = settr(36,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(36,0,26,0,0,"sub-sequence", 1, 2, 0);
	trans[0][26]	= settr(25,2,32,8,8,"assert((state[0]==Absent))", 1, 2, 0); /* m: 27 -> 0,32 */
	reached0[27] = 1;
	trans[0][27]	= settr(0,0,0,0,0,"assert((((((((((((((((sender[0]==0)&&(recipient[0]==1))||((sender[0]==1)&&(recipient[0]==0)))||((sender[0]==1)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==1)))||((sender[0]==1)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==1)))||((sender[0]==2)&&(recipient[0]==3)))||((sender[0]==3)&&(recipient[0]==2)))||((sender[0]==2)&&(recipient[0]==4)))||((sender[0]==4)&&(recipient[0]==2)))||((sender[0]==4)&&(recipient[0]==5)))||((sender[0]==5)&&(recipient[0]==4)))||((sender[0]==1)&&(recipient[0]==6)))||((sender[0]==6)&&(recipient[0]==1))))",0,0,0);
	T = trans[0][32] = settr(31,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(31,2,28,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(31,2,30,0,0,"IF", 1, 2, 0);
	trans[0][28]	= settr(27,0,341,9,9,"((0==7))", 1, 2, 0); /* m: 29 -> 341,0 */
	reached0[29] = 1;
	trans[0][29]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][33]	= settr(32,2,34,1,0,".(goto)", 1, 2, 0); /* m: 34 -> 0,341 */
	reached0[34] = 1;
	trans[0][30]	= settr(29,2,31,2,0,"else", 1, 2, 0);
	trans[0][31]	= settr(30,0,341,10,10,"(1)", 1, 2, 0); /* m: 34 -> 341,0 */
	reached0[34] = 1;
	trans[0][34]	= settr(33,0,341,11,11,"state[0] = Sent", 1, 2, 0); /* m: 35 -> 0,341 */
	reached0[35] = 1;
	trans[0][35]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][36]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	trans[0][342]	= settr(341,0,341,1,0,".(goto)", 0, 2, 0);
	T = trans[0][341] = settr(340,0,0,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,41,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,44,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,47,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,50,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,53,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,56,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,59,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,62,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,76,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,90,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,104,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,112,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,126,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,145,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,159,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,178,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,192,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,211,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,227,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,243,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,259,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,275,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,289,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,303,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,311,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,330,0,0,"DO", 0, 2, 0);
	T = T->nxt	= settr(340,0,335,0,0,"DO", 0, 2, 0);
	    T->nxt	= settr(340,0,340,0,0,"DO", 0, 2, 0);
	T = trans[ 0][41] = settr(40,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(40,2,39,0,0,"ATOMIC", 1, 2, 0);
	trans[0][39]	= settr(38,0,341,12,12,"((state[0]==Sent))", 1, 2, 0); /* m: 40 -> 341,0 */
	reached0[40] = 1;
	trans[0][40]	= settr(0,0,0,0,0,"state[0] = Received",0,0,0);
	T = trans[ 0][44] = settr(43,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(43,2,42,0,0,"ATOMIC", 1, 2, 0);
	trans[0][42]	= settr(41,0,341,13,13,"((state[1]==Sent))", 1, 2, 0); /* m: 43 -> 341,0 */
	reached0[43] = 1;
	trans[0][43]	= settr(0,0,0,0,0,"state[1] = Received",0,0,0);
	T = trans[ 0][47] = settr(46,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(46,2,45,0,0,"ATOMIC", 1, 2, 0);
	trans[0][45]	= settr(44,0,341,14,14,"((state[2]==Sent))", 1, 2, 0); /* m: 46 -> 341,0 */
	reached0[46] = 1;
	trans[0][46]	= settr(0,0,0,0,0,"state[2] = Received",0,0,0);
	T = trans[ 0][50] = settr(49,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(49,2,48,0,0,"ATOMIC", 1, 2, 0);
	trans[0][48]	= settr(47,0,341,15,15,"((state[3]==Sent))", 1, 2, 0); /* m: 49 -> 341,0 */
	reached0[49] = 1;
	trans[0][49]	= settr(0,0,0,0,0,"state[3] = Received",0,0,0);
	T = trans[ 0][53] = settr(52,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(52,2,51,0,0,"ATOMIC", 1, 2, 0);
	trans[0][51]	= settr(50,0,341,16,16,"((state[4]==Sent))", 1, 2, 0); /* m: 52 -> 341,0 */
	reached0[52] = 1;
	trans[0][52]	= settr(0,0,0,0,0,"state[4] = Received",0,0,0);
	T = trans[ 0][56] = settr(55,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(55,2,54,0,0,"ATOMIC", 1, 2, 0);
	trans[0][54]	= settr(53,0,341,17,17,"((state[5]==Sent))", 1, 2, 0); /* m: 55 -> 341,0 */
	reached0[55] = 1;
	trans[0][55]	= settr(0,0,0,0,0,"state[5] = Received",0,0,0);
	T = trans[ 0][59] = settr(58,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(58,2,57,0,0,"ATOMIC", 1, 2, 0);
	trans[0][57]	= settr(56,0,341,18,18,"((state[6]==Sent))", 1, 2, 0); /* m: 58 -> 341,0 */
	reached0[58] = 1;
	trans[0][58]	= settr(0,0,0,0,0,"state[6] = Received",0,0,0);
	T = trans[ 0][62] = settr(61,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(61,2,60,0,0,"ATOMIC", 1, 2, 0);
	trans[0][60]	= settr(59,0,341,19,19,"((state[7]==Sent))", 1, 2, 0); /* m: 61 -> 341,0 */
	reached0[61] = 1;
	trans[0][61]	= settr(0,0,0,0,0,"state[7] = Received",0,0,0);
	T = trans[ 0][76] = settr(75,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(75,2,63,0,0,"ATOMIC", 1, 2, 0);
	trans[0][63]	= settr(62,2,75,20,0,"(((state[0]==Received)&&(state[1]==Absent)))", 1, 2, 0);
	T = trans[ 0][75] = settr(74,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(74,0,64,0,0,"sub-sequence", 1, 2, 0);
	trans[0][64]	= settr(63,2,70,21,21,"assert((state[1]==Absent))", 1, 2, 0); /* m: 65 -> 0,70 */
	reached0[65] = 1;
	trans[0][65]	= settr(0,0,0,0,0,"assert((((((((((((((((sender[1]==0)&&(recipient[1]==1))||((sender[1]==1)&&(recipient[1]==0)))||((sender[1]==1)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==1)))||((sender[1]==1)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==1)))||((sender[1]==2)&&(recipient[1]==3)))||((sender[1]==3)&&(recipient[1]==2)))||((sender[1]==2)&&(recipient[1]==4)))||((sender[1]==4)&&(recipient[1]==2)))||((sender[1]==4)&&(recipient[1]==5)))||((sender[1]==5)&&(recipient[1]==4)))||((sender[1]==1)&&(recipient[1]==6)))||((sender[1]==6)&&(recipient[1]==1))))",0,0,0);
	T = trans[0][70] = settr(69,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(69,2,66,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(69,2,68,0,0,"IF", 1, 2, 0);
	trans[0][66]	= settr(65,0,341,22,22,"((1==7))", 1, 2, 0); /* m: 67 -> 341,0 */
	reached0[67] = 1;
	trans[0][67]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][71]	= settr(70,2,72,1,0,".(goto)", 1, 2, 0); /* m: 72 -> 0,341 */
	reached0[72] = 1;
	trans[0][68]	= settr(67,2,69,2,0,"else", 1, 2, 0);
	trans[0][69]	= settr(68,0,341,23,23,"(1)", 1, 2, 0); /* m: 72 -> 341,0 */
	reached0[72] = 1;
	trans[0][72]	= settr(71,0,341,24,24,"state[1] = Sent", 1, 2, 0); /* m: 73 -> 0,341 */
	reached0[73] = 1;
	trans[0][73]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][74]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][90] = settr(89,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(89,2,77,0,0,"ATOMIC", 1, 2, 0);
	trans[0][77]	= settr(76,2,89,25,0,"(((state[0]==Received)&&(state[2]==Absent)))", 1, 2, 0);
	T = trans[ 0][89] = settr(88,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(88,0,78,0,0,"sub-sequence", 1, 2, 0);
	trans[0][78]	= settr(77,2,84,26,26,"assert((state[2]==Absent))", 1, 2, 0); /* m: 79 -> 0,84 */
	reached0[79] = 1;
	trans[0][79]	= settr(0,0,0,0,0,"assert((((((((((((((((sender[2]==0)&&(recipient[2]==1))||((sender[2]==1)&&(recipient[2]==0)))||((sender[2]==1)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==1)))||((sender[2]==1)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==1)))||((sender[2]==2)&&(recipient[2]==3)))||((sender[2]==3)&&(recipient[2]==2)))||((sender[2]==2)&&(recipient[2]==4)))||((sender[2]==4)&&(recipient[2]==2)))||((sender[2]==4)&&(recipient[2]==5)))||((sender[2]==5)&&(recipient[2]==4)))||((sender[2]==1)&&(recipient[2]==6)))||((sender[2]==6)&&(recipient[2]==1))))",0,0,0);
	T = trans[0][84] = settr(83,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(83,2,80,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(83,2,82,0,0,"IF", 1, 2, 0);
	trans[0][80]	= settr(79,0,341,27,27,"((2==7))", 1, 2, 0); /* m: 81 -> 341,0 */
	reached0[81] = 1;
	trans[0][81]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][85]	= settr(84,2,86,1,0,".(goto)", 1, 2, 0); /* m: 86 -> 0,341 */
	reached0[86] = 1;
	trans[0][82]	= settr(81,2,83,2,0,"else", 1, 2, 0);
	trans[0][83]	= settr(82,0,341,28,28,"(1)", 1, 2, 0); /* m: 86 -> 341,0 */
	reached0[86] = 1;
	trans[0][86]	= settr(85,0,341,29,29,"state[2] = Sent", 1, 2, 0); /* m: 87 -> 0,341 */
	reached0[87] = 1;
	trans[0][87]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][88]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][104] = settr(103,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(103,2,91,0,0,"ATOMIC", 1, 2, 0);
	trans[0][91]	= settr(90,2,103,30,0,"(((state[1]==Received)&&(state[3]==Absent)))", 1, 2, 0);
	T = trans[ 0][103] = settr(102,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(102,0,92,0,0,"sub-sequence", 1, 2, 0);
	trans[0][92]	= settr(91,2,98,31,31,"assert((state[3]==Absent))", 1, 2, 0); /* m: 93 -> 0,98 */
	reached0[93] = 1;
	trans[0][93]	= settr(0,0,0,0,0,"assert((((((((((((((((sender[3]==0)&&(recipient[3]==1))||((sender[3]==1)&&(recipient[3]==0)))||((sender[3]==1)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==1)))||((sender[3]==1)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==1)))||((sender[3]==2)&&(recipient[3]==3)))||((sender[3]==3)&&(recipient[3]==2)))||((sender[3]==2)&&(recipient[3]==4)))||((sender[3]==4)&&(recipient[3]==2)))||((sender[3]==4)&&(recipient[3]==5)))||((sender[3]==5)&&(recipient[3]==4)))||((sender[3]==1)&&(recipient[3]==6)))||((sender[3]==6)&&(recipient[3]==1))))",0,0,0);
	T = trans[0][98] = settr(97,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(97,2,94,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(97,2,96,0,0,"IF", 1, 2, 0);
	trans[0][94]	= settr(93,0,341,32,32,"((3==7))", 1, 2, 0); /* m: 95 -> 341,0 */
	reached0[95] = 1;
	trans[0][95]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][99]	= settr(98,2,100,1,0,".(goto)", 1, 2, 0); /* m: 100 -> 0,341 */
	reached0[100] = 1;
	trans[0][96]	= settr(95,2,97,2,0,"else", 1, 2, 0);
	trans[0][97]	= settr(96,0,341,33,33,"(1)", 1, 2, 0); /* m: 100 -> 341,0 */
	reached0[100] = 1;
	trans[0][100]	= settr(99,0,341,34,34,"state[3] = Sent", 1, 2, 0); /* m: 101 -> 0,341 */
	reached0[101] = 1;
	trans[0][101]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][102]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][112] = settr(111,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(111,2,105,0,0,"ATOMIC", 1, 2, 0);
	trans[0][105]	= settr(104,2,111,35,0,"(((state[1]==Received)&&(state[3]==Failed)))", 1, 2, 0);
	T = trans[ 0][111] = settr(110,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(110,0,106,0,0,"sub-sequence", 1, 2, 0);
	trans[0][106]	= settr(105,0,341,36,36,"assert((state[1]==Received))", 1, 2, 0); /* m: 107 -> 0,341 */
	reached0[107] = 1;
	trans[0][107]	= settr(0,0,0,0,0,"reply_to[1] = 1",0,0,0);
	trans[0][108]	= settr(0,0,0,0,0,"assert((reply_to[1]==1))",0,0,0);
	trans[0][109]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))",0,0,0);
	trans[0][110]	= settr(0,0,0,0,0,"state[1] = 1",0,0,0);
	T = trans[ 0][126] = settr(125,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(125,2,113,0,0,"ATOMIC", 1, 2, 0);
	trans[0][113]	= settr(112,2,125,37,0,"((((state[1]==Received)&&(state[3]==Succeeded))&&(state[4]==Absent)))", 1, 2, 0);
	T = trans[ 0][125] = settr(124,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(124,0,114,0,0,"sub-sequence", 1, 2, 0);
	trans[0][114]	= settr(113,2,120,38,38,"assert((state[4]==Absent))", 1, 2, 0); /* m: 115 -> 0,120 */
	reached0[115] = 1;
	trans[0][115]	= settr(0,0,0,0,0,"assert((((((((((((((((sender[4]==0)&&(recipient[4]==1))||((sender[4]==1)&&(recipient[4]==0)))||((sender[4]==1)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==1)))||((sender[4]==1)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==1)))||((sender[4]==2)&&(recipient[4]==3)))||((sender[4]==3)&&(recipient[4]==2)))||((sender[4]==2)&&(recipient[4]==4)))||((sender[4]==4)&&(recipient[4]==2)))||((sender[4]==4)&&(recipient[4]==5)))||((sender[4]==5)&&(recipient[4]==4)))||((sender[4]==1)&&(recipient[4]==6)))||((sender[4]==6)&&(recipient[4]==1))))",0,0,0);
	T = trans[0][120] = settr(119,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(119,2,116,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(119,2,118,0,0,"IF", 1, 2, 0);
	trans[0][116]	= settr(115,0,341,39,39,"((4==7))", 1, 2, 0); /* m: 117 -> 341,0 */
	reached0[117] = 1;
	trans[0][117]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][121]	= settr(120,2,122,1,0,".(goto)", 1, 2, 0); /* m: 122 -> 0,341 */
	reached0[122] = 1;
	trans[0][118]	= settr(117,2,119,2,0,"else", 1, 2, 0);
	trans[0][119]	= settr(118,0,341,40,40,"(1)", 1, 2, 0); /* m: 122 -> 341,0 */
	reached0[122] = 1;
	trans[0][122]	= settr(121,0,341,41,41,"state[4] = Sent", 1, 2, 0); /* m: 123 -> 0,341 */
	reached0[123] = 1;
	trans[0][123]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][124]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][145] = settr(144,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(144,2,127,0,0,"ATOMIC", 1, 2, 0);
	trans[0][127]	= settr(126,2,144,42,0,"(((state[1]==Received)&&((state[4]==Succeeded)||(state[4]==Failed))))", 1, 2, 0);
	T = trans[ 0][144] = settr(143,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(143,0,142,0,0,"sub-sequence", 1, 2, 0);
	T = trans[0][142] = settr(141,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(141,2,128,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(141,2,135,0,0,"IF", 1, 2, 0);
	trans[0][128]	= settr(127,2,134,43,0,"((state[4]==Succeeded))", 1, 2, 0);
	T = trans[ 0][134] = settr(133,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(133,0,129,0,0,"sub-sequence", 1, 2, 0);
	trans[0][129]	= settr(128,0,341,44,44,"assert((state[1]==Received))", 1, 2, 0); /* m: 130 -> 0,341 */
	reached0[130] = 1;
	trans[0][130]	= settr(0,0,0,0,0,"reply_to[1] = 1",0,0,0);
	trans[0][131]	= settr(0,0,0,0,0,"assert((reply_to[1]==1))",0,0,0);
	trans[0][132]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))",0,0,0);
	trans[0][133]	= settr(0,0,0,0,0,"state[1] = 2",0,0,0);
	trans[0][143]	= settr(142,0,341,45,45,".(goto)", 1, 2, 0);
	trans[0][135]	= settr(134,2,141,46,0,"((state[4]==Failed))", 1, 2, 0);
	T = trans[ 0][141] = settr(140,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(140,0,136,0,0,"sub-sequence", 1, 2, 0);
	trans[0][136]	= settr(135,0,341,47,47,"assert((state[1]==Received))", 1, 2, 0); /* m: 137 -> 0,341 */
	reached0[137] = 1;
	trans[0][137]	= settr(0,0,0,0,0,"reply_to[1] = 1",0,0,0);
	trans[0][138]	= settr(0,0,0,0,0,"assert((reply_to[1]==1))",0,0,0);
	trans[0][139]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[1]==0)&&(sender[1]==1))||((recipient[1]==1)&&(sender[1]==0)))||((recipient[1]==1)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==1)))||((recipient[1]==1)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==1)))||((recipient[1]==2)&&(sender[1]==3)))||((recipient[1]==3)&&(sender[1]==2)))||((recipient[1]==2)&&(sender[1]==4)))||((recipient[1]==4)&&(sender[1]==2)))||((recipient[1]==4)&&(sender[1]==5)))||((recipient[1]==5)&&(sender[1]==4)))||((recipient[1]==1)&&(sender[1]==6)))||((recipient[1]==6)&&(sender[1]==1))))",0,0,0);
	trans[0][140]	= settr(0,0,0,0,0,"state[1] = 1",0,0,0);
	T = trans[ 0][159] = settr(158,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(158,2,146,0,0,"ATOMIC", 1, 2, 0);
	trans[0][146]	= settr(145,2,158,48,0,"(((state[2]==Received)&&(state[5]==Absent)))", 1, 2, 0);
	T = trans[ 0][158] = settr(157,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(157,0,147,0,0,"sub-sequence", 1, 2, 0);
	trans[0][147]	= settr(146,2,153,49,49,"assert((state[5]==Absent))", 1, 2, 0); /* m: 148 -> 0,153 */
	reached0[148] = 1;
	trans[0][148]	= settr(0,0,0,0,0,"assert((((((((((((((((sender[5]==0)&&(recipient[5]==1))||((sender[5]==1)&&(recipient[5]==0)))||((sender[5]==1)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==1)))||((sender[5]==1)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==1)))||((sender[5]==2)&&(recipient[5]==3)))||((sender[5]==3)&&(recipient[5]==2)))||((sender[5]==2)&&(recipient[5]==4)))||((sender[5]==4)&&(recipient[5]==2)))||((sender[5]==4)&&(recipient[5]==5)))||((sender[5]==5)&&(recipient[5]==4)))||((sender[5]==1)&&(recipient[5]==6)))||((sender[5]==6)&&(recipient[5]==1))))",0,0,0);
	T = trans[0][153] = settr(152,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(152,2,149,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(152,2,151,0,0,"IF", 1, 2, 0);
	trans[0][149]	= settr(148,0,341,50,50,"((5==7))", 1, 2, 0); /* m: 150 -> 341,0 */
	reached0[150] = 1;
	trans[0][150]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][154]	= settr(153,2,155,1,0,".(goto)", 1, 2, 0); /* m: 155 -> 0,341 */
	reached0[155] = 1;
	trans[0][151]	= settr(150,2,152,2,0,"else", 1, 2, 0);
	trans[0][152]	= settr(151,0,341,51,51,"(1)", 1, 2, 0); /* m: 155 -> 341,0 */
	reached0[155] = 1;
	trans[0][155]	= settr(154,0,341,52,52,"state[5] = Sent", 1, 2, 0); /* m: 156 -> 0,341 */
	reached0[156] = 1;
	trans[0][156]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][157]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][178] = settr(177,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(177,2,160,0,0,"ATOMIC", 1, 2, 0);
	trans[0][160]	= settr(159,2,177,53,0,"(((state[2]==Received)&&((state[5]==Succeeded)||(state[5]==Failed))))", 1, 2, 0);
	T = trans[ 0][177] = settr(176,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(176,0,175,0,0,"sub-sequence", 1, 2, 0);
	T = trans[0][175] = settr(174,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(174,2,161,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(174,2,168,0,0,"IF", 1, 2, 0);
	trans[0][161]	= settr(160,2,167,54,0,"((state[5]==Succeeded))", 1, 2, 0);
	T = trans[ 0][167] = settr(166,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(166,0,162,0,0,"sub-sequence", 1, 2, 0);
	trans[0][162]	= settr(161,0,341,55,55,"assert((state[2]==Received))", 1, 2, 0); /* m: 163 -> 0,341 */
	reached0[163] = 1;
	trans[0][163]	= settr(0,0,0,0,0,"reply_to[2] = 2",0,0,0);
	trans[0][164]	= settr(0,0,0,0,0,"assert((reply_to[2]==2))",0,0,0);
	trans[0][165]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1))))",0,0,0);
	trans[0][166]	= settr(0,0,0,0,0,"state[2] = 2",0,0,0);
	trans[0][176]	= settr(175,0,341,56,56,".(goto)", 1, 2, 0);
	trans[0][168]	= settr(167,2,174,57,0,"((state[5]==Failed))", 1, 2, 0);
	T = trans[ 0][174] = settr(173,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(173,0,169,0,0,"sub-sequence", 1, 2, 0);
	trans[0][169]	= settr(168,0,341,58,58,"assert((state[2]==Received))", 1, 2, 0); /* m: 170 -> 0,341 */
	reached0[170] = 1;
	trans[0][170]	= settr(0,0,0,0,0,"reply_to[2] = 2",0,0,0);
	trans[0][171]	= settr(0,0,0,0,0,"assert((reply_to[2]==2))",0,0,0);
	trans[0][172]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[2]==0)&&(sender[2]==1))||((recipient[2]==1)&&(sender[2]==0)))||((recipient[2]==1)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==1)))||((recipient[2]==1)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==1)))||((recipient[2]==2)&&(sender[2]==3)))||((recipient[2]==3)&&(sender[2]==2)))||((recipient[2]==2)&&(sender[2]==4)))||((recipient[2]==4)&&(sender[2]==2)))||((recipient[2]==4)&&(sender[2]==5)))||((recipient[2]==5)&&(sender[2]==4)))||((recipient[2]==1)&&(sender[2]==6)))||((recipient[2]==6)&&(sender[2]==1))))",0,0,0);
	trans[0][173]	= settr(0,0,0,0,0,"state[2] = 1",0,0,0);
	T = trans[ 0][192] = settr(191,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(191,2,179,0,0,"ATOMIC", 1, 2, 0);
	trans[0][179]	= settr(178,2,191,59,0,"(((state[4]==Received)&&(state[6]==Absent)))", 1, 2, 0);
	T = trans[ 0][191] = settr(190,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(190,0,180,0,0,"sub-sequence", 1, 2, 0);
	trans[0][180]	= settr(179,2,186,60,60,"assert((state[6]==Absent))", 1, 2, 0); /* m: 181 -> 0,186 */
	reached0[181] = 1;
	trans[0][181]	= settr(0,0,0,0,0,"assert((((((((((((((((sender[6]==0)&&(recipient[6]==1))||((sender[6]==1)&&(recipient[6]==0)))||((sender[6]==1)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==1)))||((sender[6]==1)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==1)))||((sender[6]==2)&&(recipient[6]==3)))||((sender[6]==3)&&(recipient[6]==2)))||((sender[6]==2)&&(recipient[6]==4)))||((sender[6]==4)&&(recipient[6]==2)))||((sender[6]==4)&&(recipient[6]==5)))||((sender[6]==5)&&(recipient[6]==4)))||((sender[6]==1)&&(recipient[6]==6)))||((sender[6]==6)&&(recipient[6]==1))))",0,0,0);
	T = trans[0][186] = settr(185,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(185,2,182,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(185,2,184,0,0,"IF", 1, 2, 0);
	trans[0][182]	= settr(181,0,341,61,61,"((6==7))", 1, 2, 0); /* m: 183 -> 341,0 */
	reached0[183] = 1;
	trans[0][183]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][187]	= settr(186,2,188,1,0,".(goto)", 1, 2, 0); /* m: 188 -> 0,341 */
	reached0[188] = 1;
	trans[0][184]	= settr(183,2,185,2,0,"else", 1, 2, 0);
	trans[0][185]	= settr(184,0,341,62,62,"(1)", 1, 2, 0); /* m: 188 -> 341,0 */
	reached0[188] = 1;
	trans[0][188]	= settr(187,0,341,63,63,"state[6] = Sent", 1, 2, 0); /* m: 189 -> 0,341 */
	reached0[189] = 1;
	trans[0][189]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][190]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][211] = settr(210,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(210,2,193,0,0,"ATOMIC", 1, 2, 0);
	trans[0][193]	= settr(192,2,210,64,0,"(((state[4]==Received)&&((state[6]==Succeeded)||(state[6]==Failed))))", 1, 2, 0);
	T = trans[ 0][210] = settr(209,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(209,0,208,0,0,"sub-sequence", 1, 2, 0);
	T = trans[0][208] = settr(207,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(207,2,194,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(207,2,201,0,0,"IF", 1, 2, 0);
	trans[0][194]	= settr(193,2,200,65,0,"((state[6]==Succeeded))", 1, 2, 0);
	T = trans[ 0][200] = settr(199,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(199,0,195,0,0,"sub-sequence", 1, 2, 0);
	trans[0][195]	= settr(194,0,341,66,66,"assert((state[4]==Received))", 1, 2, 0); /* m: 196 -> 0,341 */
	reached0[196] = 1;
	trans[0][196]	= settr(0,0,0,0,0,"reply_to[4] = 4",0,0,0);
	trans[0][197]	= settr(0,0,0,0,0,"assert((reply_to[4]==4))",0,0,0);
	trans[0][198]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1))))",0,0,0);
	trans[0][199]	= settr(0,0,0,0,0,"state[4] = 2",0,0,0);
	trans[0][209]	= settr(208,0,341,67,67,".(goto)", 1, 2, 0);
	trans[0][201]	= settr(200,2,207,68,0,"((state[6]==Failed))", 1, 2, 0);
	T = trans[ 0][207] = settr(206,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(206,0,202,0,0,"sub-sequence", 1, 2, 0);
	trans[0][202]	= settr(201,0,341,69,69,"assert((state[4]==Received))", 1, 2, 0); /* m: 203 -> 0,341 */
	reached0[203] = 1;
	trans[0][203]	= settr(0,0,0,0,0,"reply_to[4] = 4",0,0,0);
	trans[0][204]	= settr(0,0,0,0,0,"assert((reply_to[4]==4))",0,0,0);
	trans[0][205]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[4]==0)&&(sender[4]==1))||((recipient[4]==1)&&(sender[4]==0)))||((recipient[4]==1)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==1)))||((recipient[4]==1)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==1)))||((recipient[4]==2)&&(sender[4]==3)))||((recipient[4]==3)&&(sender[4]==2)))||((recipient[4]==2)&&(sender[4]==4)))||((recipient[4]==4)&&(sender[4]==2)))||((recipient[4]==4)&&(sender[4]==5)))||((recipient[4]==5)&&(sender[4]==4)))||((recipient[4]==1)&&(sender[4]==6)))||((recipient[4]==6)&&(sender[4]==1))))",0,0,0);
	trans[0][206]	= settr(0,0,0,0,0,"state[4] = 1",0,0,0);
	T = trans[ 0][227] = settr(226,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(226,2,212,0,0,"ATOMIC", 1, 2, 0);
	trans[0][212]	= settr(211,2,225,70,0,"((state[3]==Received))", 1, 2, 0);
	T = trans[0][225] = settr(224,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(224,2,218,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(224,2,224,0,0,"IF", 1, 2, 0);
	T = trans[ 0][218] = settr(217,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(217,0,213,0,0,"sub-sequence", 1, 2, 0);
	trans[0][213]	= settr(212,0,341,71,71,"assert((state[3]==Received))", 1, 2, 0); /* m: 214 -> 0,341 */
	reached0[214] = 1;
	trans[0][214]	= settr(0,0,0,0,0,"reply_to[3] = 3",0,0,0);
	trans[0][215]	= settr(0,0,0,0,0,"assert((reply_to[3]==3))",0,0,0);
	trans[0][216]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1))))",0,0,0);
	trans[0][217]	= settr(0,0,0,0,0,"state[3] = 2",0,0,0);
	trans[0][226]	= settr(225,0,341,72,72,".(goto)", 1, 2, 0);
	T = trans[ 0][224] = settr(223,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(223,0,219,0,0,"sub-sequence", 1, 2, 0);
	trans[0][219]	= settr(218,0,341,73,73,"assert((state[3]==Received))", 1, 2, 0); /* m: 220 -> 0,341 */
	reached0[220] = 1;
	trans[0][220]	= settr(0,0,0,0,0,"reply_to[3] = 3",0,0,0);
	trans[0][221]	= settr(0,0,0,0,0,"assert((reply_to[3]==3))",0,0,0);
	trans[0][222]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[3]==0)&&(sender[3]==1))||((recipient[3]==1)&&(sender[3]==0)))||((recipient[3]==1)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==1)))||((recipient[3]==1)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==1)))||((recipient[3]==2)&&(sender[3]==3)))||((recipient[3]==3)&&(sender[3]==2)))||((recipient[3]==2)&&(sender[3]==4)))||((recipient[3]==4)&&(sender[3]==2)))||((recipient[3]==4)&&(sender[3]==5)))||((recipient[3]==5)&&(sender[3]==4)))||((recipient[3]==1)&&(sender[3]==6)))||((recipient[3]==6)&&(sender[3]==1))))",0,0,0);
	trans[0][223]	= settr(0,0,0,0,0,"state[3] = 1",0,0,0);
	T = trans[ 0][243] = settr(242,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(242,2,228,0,0,"ATOMIC", 1, 2, 0);
	trans[0][228]	= settr(227,2,241,74,0,"((state[5]==Received))", 1, 2, 0);
	T = trans[0][241] = settr(240,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(240,2,234,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(240,2,240,0,0,"IF", 1, 2, 0);
	T = trans[ 0][234] = settr(233,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(233,0,229,0,0,"sub-sequence", 1, 2, 0);
	trans[0][229]	= settr(228,0,341,75,75,"assert((state[5]==Received))", 1, 2, 0); /* m: 230 -> 0,341 */
	reached0[230] = 1;
	trans[0][230]	= settr(0,0,0,0,0,"reply_to[5] = 5",0,0,0);
	trans[0][231]	= settr(0,0,0,0,0,"assert((reply_to[5]==5))",0,0,0);
	trans[0][232]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1))))",0,0,0);
	trans[0][233]	= settr(0,0,0,0,0,"state[5] = 2",0,0,0);
	trans[0][242]	= settr(241,0,341,76,76,".(goto)", 1, 2, 0);
	T = trans[ 0][240] = settr(239,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(239,0,235,0,0,"sub-sequence", 1, 2, 0);
	trans[0][235]	= settr(234,0,341,77,77,"assert((state[5]==Received))", 1, 2, 0); /* m: 236 -> 0,341 */
	reached0[236] = 1;
	trans[0][236]	= settr(0,0,0,0,0,"reply_to[5] = 5",0,0,0);
	trans[0][237]	= settr(0,0,0,0,0,"assert((reply_to[5]==5))",0,0,0);
	trans[0][238]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[5]==0)&&(sender[5]==1))||((recipient[5]==1)&&(sender[5]==0)))||((recipient[5]==1)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==1)))||((recipient[5]==1)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==1)))||((recipient[5]==2)&&(sender[5]==3)))||((recipient[5]==3)&&(sender[5]==2)))||((recipient[5]==2)&&(sender[5]==4)))||((recipient[5]==4)&&(sender[5]==2)))||((recipient[5]==4)&&(sender[5]==5)))||((recipient[5]==5)&&(sender[5]==4)))||((recipient[5]==1)&&(sender[5]==6)))||((recipient[5]==6)&&(sender[5]==1))))",0,0,0);
	trans[0][239]	= settr(0,0,0,0,0,"state[5] = 1",0,0,0);
	T = trans[ 0][259] = settr(258,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(258,2,244,0,0,"ATOMIC", 1, 2, 0);
	trans[0][244]	= settr(243,2,257,78,0,"((state[6]==Received))", 1, 2, 0);
	T = trans[0][257] = settr(256,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(256,2,250,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(256,2,256,0,0,"IF", 1, 2, 0);
	T = trans[ 0][250] = settr(249,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(249,0,245,0,0,"sub-sequence", 1, 2, 0);
	trans[0][245]	= settr(244,0,341,79,79,"assert((state[6]==Received))", 1, 2, 0); /* m: 246 -> 0,341 */
	reached0[246] = 1;
	trans[0][246]	= settr(0,0,0,0,0,"reply_to[6] = 6",0,0,0);
	trans[0][247]	= settr(0,0,0,0,0,"assert((reply_to[6]==6))",0,0,0);
	trans[0][248]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1))))",0,0,0);
	trans[0][249]	= settr(0,0,0,0,0,"state[6] = 2",0,0,0);
	trans[0][258]	= settr(257,0,341,80,80,".(goto)", 1, 2, 0);
	T = trans[ 0][256] = settr(255,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(255,0,251,0,0,"sub-sequence", 1, 2, 0);
	trans[0][251]	= settr(250,0,341,81,81,"assert((state[6]==Received))", 1, 2, 0); /* m: 252 -> 0,341 */
	reached0[252] = 1;
	trans[0][252]	= settr(0,0,0,0,0,"reply_to[6] = 6",0,0,0);
	trans[0][253]	= settr(0,0,0,0,0,"assert((reply_to[6]==6))",0,0,0);
	trans[0][254]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[6]==0)&&(sender[6]==1))||((recipient[6]==1)&&(sender[6]==0)))||((recipient[6]==1)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==1)))||((recipient[6]==1)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==1)))||((recipient[6]==2)&&(sender[6]==3)))||((recipient[6]==3)&&(sender[6]==2)))||((recipient[6]==2)&&(sender[6]==4)))||((recipient[6]==4)&&(sender[6]==2)))||((recipient[6]==4)&&(sender[6]==5)))||((recipient[6]==5)&&(sender[6]==4)))||((recipient[6]==1)&&(sender[6]==6)))||((recipient[6]==6)&&(sender[6]==1))))",0,0,0);
	trans[0][255]	= settr(0,0,0,0,0,"state[6] = 1",0,0,0);
	T = trans[ 0][275] = settr(274,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(274,2,260,0,0,"ATOMIC", 1, 2, 0);
	trans[0][260]	= settr(259,2,273,82,0,"((state[7]==Received))", 1, 2, 0);
	T = trans[0][273] = settr(272,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(272,2,266,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(272,2,272,0,0,"IF", 1, 2, 0);
	T = trans[ 0][266] = settr(265,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(265,0,261,0,0,"sub-sequence", 1, 2, 0);
	trans[0][261]	= settr(260,0,341,83,83,"assert((state[7]==Received))", 1, 2, 0); /* m: 262 -> 0,341 */
	reached0[262] = 1;
	trans[0][262]	= settr(0,0,0,0,0,"reply_to[7] = 7",0,0,0);
	trans[0][263]	= settr(0,0,0,0,0,"assert((reply_to[7]==7))",0,0,0);
	trans[0][264]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1))))",0,0,0);
	trans[0][265]	= settr(0,0,0,0,0,"state[7] = 2",0,0,0);
	trans[0][274]	= settr(273,0,341,84,84,".(goto)", 1, 2, 0);
	T = trans[ 0][272] = settr(271,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(271,0,267,0,0,"sub-sequence", 1, 2, 0);
	trans[0][267]	= settr(266,0,341,85,85,"assert((state[7]==Received))", 1, 2, 0); /* m: 268 -> 0,341 */
	reached0[268] = 1;
	trans[0][268]	= settr(0,0,0,0,0,"reply_to[7] = 7",0,0,0);
	trans[0][269]	= settr(0,0,0,0,0,"assert((reply_to[7]==7))",0,0,0);
	trans[0][270]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[7]==0)&&(sender[7]==1))||((recipient[7]==1)&&(sender[7]==0)))||((recipient[7]==1)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==1)))||((recipient[7]==1)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==1)))||((recipient[7]==2)&&(sender[7]==3)))||((recipient[7]==3)&&(sender[7]==2)))||((recipient[7]==2)&&(sender[7]==4)))||((recipient[7]==4)&&(sender[7]==2)))||((recipient[7]==4)&&(sender[7]==5)))||((recipient[7]==5)&&(sender[7]==4)))||((recipient[7]==1)&&(sender[7]==6)))||((recipient[7]==6)&&(sender[7]==1))))",0,0,0);
	trans[0][271]	= settr(0,0,0,0,0,"state[7] = 1",0,0,0);
	T = trans[ 0][289] = settr(288,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(288,2,276,0,0,"ATOMIC", 1, 2, 0);
	trans[0][276]	= settr(275,2,288,86,0,"(((state[0]==Received)&&(state[7]==Absent)))", 1, 2, 0);
	T = trans[ 0][288] = settr(287,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(287,0,277,0,0,"sub-sequence", 1, 2, 0);
	trans[0][277]	= settr(276,2,283,87,87,"assert((state[7]==Absent))", 1, 2, 0); /* m: 278 -> 0,283 */
	reached0[278] = 1;
	trans[0][278]	= settr(0,0,0,0,0,"assert((((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1))))",0,0,0);
	T = trans[0][283] = settr(282,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(282,2,279,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(282,2,281,0,0,"IF", 1, 2, 0);
	trans[0][279]	= settr(278,0,341,88,88,"((7==7))", 1, 2, 0); /* m: 280 -> 341,0 */
	reached0[280] = 1;
	trans[0][280]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][284]	= settr(283,2,285,1,0,".(goto)", 1, 2, 0); /* m: 285 -> 0,341 */
	reached0[285] = 1;
	trans[0][281]	= settr(280,2,282,2,0,"else", 1, 2, 0);
	trans[0][282]	= settr(281,0,341,89,89,"(1)", 1, 2, 0); /* m: 285 -> 341,0 */
	reached0[285] = 1;
	trans[0][285]	= settr(284,0,341,90,90,"state[7] = Sent", 1, 2, 0); /* m: 286 -> 0,341 */
	reached0[286] = 1;
	trans[0][286]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][287]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][303] = settr(302,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(302,2,290,0,0,"ATOMIC", 1, 2, 0);
	trans[0][290]	= settr(289,2,302,91,0,"((((state[0]==Received)&&((state[1]==Succeeded)&&(state[2]==Succeeded)))&&(state[7]==Absent)))", 1, 2, 0);
	T = trans[ 0][302] = settr(301,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(301,0,291,0,0,"sub-sequence", 1, 2, 0);
	trans[0][291]	= settr(290,2,297,92,92,"assert((state[7]==Absent))", 1, 2, 0); /* m: 292 -> 0,297 */
	reached0[292] = 1;
	trans[0][292]	= settr(0,0,0,0,0,"assert((((((((((((((((sender[7]==0)&&(recipient[7]==1))||((sender[7]==1)&&(recipient[7]==0)))||((sender[7]==1)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==1)))||((sender[7]==1)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==1)))||((sender[7]==2)&&(recipient[7]==3)))||((sender[7]==3)&&(recipient[7]==2)))||((sender[7]==2)&&(recipient[7]==4)))||((sender[7]==4)&&(recipient[7]==2)))||((sender[7]==4)&&(recipient[7]==5)))||((sender[7]==5)&&(recipient[7]==4)))||((sender[7]==1)&&(recipient[7]==6)))||((sender[7]==6)&&(recipient[7]==1))))",0,0,0);
	T = trans[0][297] = settr(296,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(296,2,293,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(296,2,295,0,0,"IF", 1, 2, 0);
	trans[0][293]	= settr(292,0,341,93,93,"((7==7))", 1, 2, 0); /* m: 294 -> 341,0 */
	reached0[294] = 1;
	trans[0][294]	= settr(0,0,0,0,0,"assert(((state[1]==Succeeded)&&(state[2]==Succeeded)))",0,0,0);
	trans[0][298]	= settr(297,2,299,1,0,".(goto)", 1, 2, 0); /* m: 299 -> 0,341 */
	reached0[299] = 1;
	trans[0][295]	= settr(294,2,296,2,0,"else", 1, 2, 0);
	trans[0][296]	= settr(295,0,341,94,94,"(1)", 1, 2, 0); /* m: 299 -> 341,0 */
	reached0[299] = 1;
	trans[0][299]	= settr(298,0,341,95,95,"state[7] = Sent", 1, 2, 0); /* m: 300 -> 0,341 */
	reached0[300] = 1;
	trans[0][300]	= settr(0,0,0,0,0,"dispatches = (dispatches+1)",0,0,0);
	trans[0][301]	= settr(0,0,0,0,0,"assert((dispatches<=8))",0,0,0);
	T = trans[ 0][311] = settr(310,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(310,2,304,0,0,"ATOMIC", 1, 2, 0);
	trans[0][304]	= settr(303,2,310,96,0,"(((((state[0]==Received)&&((state[1]==Succeeded)||(state[1]==Failed)))&&((state[2]==Succeeded)||(state[2]==Failed)))&&!(((state[1]==Succeeded)&&(state[2]==Succeeded)))))", 1, 2, 0);
	T = trans[ 0][310] = settr(309,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(309,0,305,0,0,"sub-sequence", 1, 2, 0);
	trans[0][305]	= settr(304,0,341,97,97,"assert((state[0]==Received))", 1, 2, 0); /* m: 306 -> 0,341 */
	reached0[306] = 1;
	trans[0][306]	= settr(0,0,0,0,0,"reply_to[0] = 0",0,0,0);
	trans[0][307]	= settr(0,0,0,0,0,"assert((reply_to[0]==0))",0,0,0);
	trans[0][308]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))",0,0,0);
	trans[0][309]	= settr(0,0,0,0,0,"state[0] = 1",0,0,0);
	T = trans[ 0][330] = settr(329,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(329,2,312,0,0,"ATOMIC", 1, 2, 0);
	trans[0][312]	= settr(311,2,329,98,0,"(((state[0]==Received)&&((state[7]==Succeeded)||(state[7]==Failed))))", 1, 2, 0);
	T = trans[ 0][329] = settr(328,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(328,0,327,0,0,"sub-sequence", 1, 2, 0);
	T = trans[0][327] = settr(326,2,0,0,0,"IF", 1, 2, 0);
	T = T->nxt	= settr(326,2,313,0,0,"IF", 1, 2, 0);
	    T->nxt	= settr(326,2,320,0,0,"IF", 1, 2, 0);
	trans[0][313]	= settr(312,2,319,99,0,"((state[7]==Succeeded))", 1, 2, 0);
	T = trans[ 0][319] = settr(318,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(318,0,314,0,0,"sub-sequence", 1, 2, 0);
	trans[0][314]	= settr(313,0,341,100,100,"assert((state[0]==Received))", 1, 2, 0); /* m: 315 -> 0,341 */
	reached0[315] = 1;
	trans[0][315]	= settr(0,0,0,0,0,"reply_to[0] = 0",0,0,0);
	trans[0][316]	= settr(0,0,0,0,0,"assert((reply_to[0]==0))",0,0,0);
	trans[0][317]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))",0,0,0);
	trans[0][318]	= settr(0,0,0,0,0,"state[0] = 2",0,0,0);
	trans[0][328]	= settr(327,0,341,101,101,".(goto)", 1, 2, 0);
	trans[0][320]	= settr(319,2,326,102,0,"((state[7]==Failed))", 1, 2, 0);
	T = trans[ 0][326] = settr(325,0,0,0,0,"sub-sequence", 1, 2, 0);
	T->nxt	= settr(325,0,321,0,0,"sub-sequence", 1, 2, 0);
	trans[0][321]	= settr(320,0,341,103,103,"assert((state[0]==Received))", 1, 2, 0); /* m: 322 -> 0,341 */
	reached0[322] = 1;
	trans[0][322]	= settr(0,0,0,0,0,"reply_to[0] = 0",0,0,0);
	trans[0][323]	= settr(0,0,0,0,0,"assert((reply_to[0]==0))",0,0,0);
	trans[0][324]	= settr(0,0,0,0,0,"assert((((((((((((((((recipient[0]==0)&&(sender[0]==1))||((recipient[0]==1)&&(sender[0]==0)))||((recipient[0]==1)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==1)))||((recipient[0]==1)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==1)))||((recipient[0]==2)&&(sender[0]==3)))||((recipient[0]==3)&&(sender[0]==2)))||((recipient[0]==2)&&(sender[0]==4)))||((recipient[0]==4)&&(sender[0]==2)))||((recipient[0]==4)&&(sender[0]==5)))||((recipient[0]==5)&&(sender[0]==4)))||((recipient[0]==1)&&(sender[0]==6)))||((recipient[0]==6)&&(sender[0]==1))))",0,0,0);
	trans[0][325]	= settr(0,0,0,0,0,"state[0] = 1",0,0,0);
	T = trans[ 0][335] = settr(334,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(334,2,331,0,0,"ATOMIC", 1, 2, 0);
	trans[0][331]	= settr(330,0,341,104,104,"((observer_reads<2))", 1, 2, 0); /* m: 332 -> 341,0 */
	reached0[332] = 1;
	trans[0][332]	= settr(0,0,0,0,0,"observed_dispatches = dispatches",0,0,0);
	trans[0][333]	= settr(0,0,0,0,0,"observer_reads = (observer_reads+1)",0,0,0);
	trans[0][334]	= settr(0,0,0,0,0,"assert((observed_dispatches==dispatches))",0,0,0);
	T = trans[ 0][340] = settr(339,2,0,0,0,"ATOMIC", 1, 2, 0);
	T->nxt	= settr(339,2,336,0,0,"ATOMIC", 1, 2, 0);
	trans[0][336]	= settr(335,4,344,105,105,"(((state[0]==Succeeded)||(state[0]==Failed)))", 1, 2, 0); /* m: 337 -> 344,0 */
	reached0[337] = 1;
	trans[0][337]	= settr(0,0,0,0,0,"assert(((state[0]!=Succeeded)||(((state[1]==Succeeded)&&(state[2]==Succeeded))&&(state[7]==Succeeded))))",0,0,0);
	trans[0][338]	= settr(0,0,0,0,0,"done = 1",0,0,0);
	trans[0][339]	= settr(338,0,344,1,0,"goto :b1", 1, 2, 0);
	trans[0][343]	= settr(342,0,344,1,0,"break", 0, 2, 0);
	trans[0][344]	= settr(343,0,0,106,106,"-end-", 0, 3500, 0);
	/* np_ demon: */
	trans[_NP_] = (Trans **) emalloc(3*sizeof(Trans *));
	T = trans[_NP_][0] = settr(9997,0,1,_T5,0,"(np_)", 1,2,0);
	    T->nxt	  = settr(9998,0,0,_T2,0,"(1)",   0,2,0);
	T = trans[_NP_][1] = settr(9999,0,1,_T5,0,"(np_)", 1,2,0);
}

Trans *
settr(	int t_id, int a, int b, int c, int d,
	char *t, int g, int tpe0, int tpe1)
{	Trans *tmp = (Trans *) emalloc(sizeof(Trans));

	tmp->atom  = a&(6|32);	/* only (2|8|32) have meaning */
	if (!g) tmp->atom |= 8;	/* no global references */
	tmp->st    = b;
	tmp->tpe[0] = tpe0;
	tmp->tpe[1] = tpe1;
	tmp->tp    = t;
	tmp->t_id  = t_id;
	tmp->forw  = c;
	tmp->back  = d;
	return tmp;
}

Trans *
cpytr(Trans *a)
{	Trans *tmp = (Trans *) emalloc(sizeof(Trans));

	int i;
	tmp->atom  = a->atom;
	tmp->st    = a->st;
#ifdef HAS_UNLESS
	tmp->e_trans = a->e_trans;
	for (i = 0; i < HAS_UNLESS; i++)
		tmp->escp[i] = a->escp[i];
#endif
	tmp->tpe[0] = a->tpe[0];
	tmp->tpe[1] = a->tpe[1];
	for (i = 0; i < 6; i++)
	{	tmp->qu[i] = a->qu[i];
		tmp->ty[i] = a->ty[i];
	}
	tmp->tp    = (char *) emalloc(strlen(a->tp)+1);
	strcpy(tmp->tp, a->tp);
	tmp->t_id  = a->t_id;
	tmp->forw  = a->forw;
	tmp->back  = a->back;
	return tmp;
}

#ifndef NOREDUCE
int
srinc_set(int n)
{	if (n <= 2) return LOCAL;
	if (n <= 2+  DELTA) return Q_FULL_F; /* 's' or nfull  */
	if (n <= 2+2*DELTA) return Q_EMPT_F; /* 'r' or nempty */
	if (n <= 2+3*DELTA) return Q_EMPT_T; /* empty */
	if (n <= 2+4*DELTA) return Q_FULL_T; /* full  */
	if (n ==   5*DELTA) return GLOBAL;
	if (n ==   6*DELTA) return TIMEOUT_F;
	if (n ==   7*DELTA) return ALPHA_F;
	Uerror("cannot happen srinc_class");
	return BAD;
}
int
srunc(int n, int m)
{	switch(m) {
	case Q_FULL_F: return n-2;
	case Q_EMPT_F: return n-2-DELTA;
	case Q_EMPT_T: return n-2-2*DELTA;
	case Q_FULL_T: return n-2-3*DELTA;
	case ALPHA_F:
	case TIMEOUT_F: return 257; /* non-zero, and > MAXQ */
	}
	Uerror("cannot happen srunc");
	return 0;
}
#endif
int cnt;
#ifdef HAS_UNLESS
int
isthere(Trans *a, int b)
{	Trans *t;
	for (t = a; t; t = t->nxt)
		if (t->t_id == b)
			return 1;
	return 0;
}
#endif
#ifndef NOREDUCE
int
mark_safety(Trans *t) /* for conditional safety */
{	int g = 0, i, j, k;

	if (!t) return 0;
	if (t->qu[0])
		return (t->qu[1])?2:1;	/* marked */

	for (i = 0; i < 2; i++)
	{	j = srinc_set(t->tpe[i]);
		if (j >= GLOBAL && j != ALPHA_F)
			return -1;
		if (j != LOCAL)
		{	k = srunc(t->tpe[i], j);
			if (g == 0
			||  t->qu[0] != k
			||  t->ty[0] != j)
			{	t->qu[g] = k;
				t->ty[g] = j;
				g++;
	}	}	}
	return g;
}
#endif
void
retrans(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
	/* process n, with m states, is=initial state */
{	Trans *T0, *T1, *T2, *T3;
	Trans *T4, *T5; /* t_reverse or has_unless */
	int i;
#if defined(HAS_UNLESS) || !defined(NOREDUCE)
	int k;
#endif
#ifndef NOREDUCE
	int g, h, j, aa;
#endif
#ifdef HAS_UNLESS
	int p;
#endif
	if (state_tables >= 4)
	{	printf("STEP 1 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
	do {
		for (i = 1, cnt = 0; i < m; i++)
		{	T2 = trans[n][i];
			T1 = T2?T2->nxt:(Trans *)0;
/* prescan: */		for (T0 = T1; T0; T0 = T0->nxt)
/* choice in choice */	{	if (T0->st && trans[n][T0->st]
				&&  trans[n][T0->st]->nxt)
					break;
			}
#if 0
		if (T0)
		printf("\tstate %d / %d: choice in choice\n",
		i, T0->st);
#endif
			if (T0)
			for (T0 = T1; T0; T0 = T0->nxt)
			{	T3 = trans[n][T0->st];
				if (!T3->nxt)
				{	T2->nxt = cpytr(T0);
					T2 = T2->nxt;
					imed(T2, T0->st, n, i);
					continue;
				}
				do {	T3 = T3->nxt;
					T2->nxt = cpytr(T3);
					T2 = T2->nxt;
					imed(T2, T0->st, n, i);
				} while (T3->nxt);
				cnt++;
			}
		}
	} while (cnt);
	if (state_tables >= 3)
	{	printf("STEP 2 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
	for (i = 1; i < m; i++)
	{	if (trans[n][i] && trans[n][i]->nxt) /* optimize */
		{	T1 = trans[n][i]->nxt;
#if 0
			printf("\t\tpull %d (%d) to %d\n",
			T1->st, T1->forw, i);
#endif
			srcln[i] = srcln[T1->st];	/* Oyvind Teig, 5.2.0 */

			if (!trans[n][T1->st]) continue;
			T0 = cpytr(trans[n][T1->st]);
			trans[n][i] = T0;
			reach[T1->st] = 1;
			imed(T0, T1->st, n, i);
			for (T1 = T1->nxt; T1; T1 = T1->nxt)
			{
#if 0
			printf("\t\tpull %d (%d) to %d\n",
				T1->st, T1->forw, i);
#endif
		/*		srcln[i] = srcln[T1->st];  gh: not useful */
				if (!trans[n][T1->st]) continue;
				T0->nxt = cpytr(trans[n][T1->st]);
				T0 = T0->nxt;
				reach[T1->st] = 1;
				imed(T0, T1->st, n, i);
	}	}	}
	if (state_tables >= 2)
	{	printf("STEP 3 %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
		return;
	}
#ifdef HAS_UNLESS
	for (i = 1; i < m; i++)
	{	if (!trans[n][i]) continue;
		/* check for each state i if an
		 * escape to some state p is defined
		 * if so, copy and mark p's transitions
		 * and prepend them to the transition-
		 * list of state i
		 */
	 if (!like_java) /* the default */
	 {	for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		for (k = HAS_UNLESS-1; k >= 0; k--)
		{	if (p = T0->escp[k])
			for (T1 = trans[n][p]; T1; T1 = T1->nxt)
			{	if (isthere(trans[n][i], T1->t_id))
					continue;
				T2 = cpytr(T1);
				T2->e_trans = p;
				T2->nxt = trans[n][i];
				trans[n][i] = T2;
		}	}
	 } else /* outermost unless checked first */
	 {	T4 = T3 = (Trans *) 0;
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		for (k = HAS_UNLESS-1; k >= 0; k--)
		{	if (p = T0->escp[k])
			for (T1 = trans[n][p]; T1; T1 = T1->nxt)
			{	if (isthere(trans[n][i], T1->t_id))
					continue;
				T2 = cpytr(T1);
				T2->nxt = (Trans *) 0;
				T2->e_trans = p;
				if (T3)	T3->nxt = T2;
				else	T4 = T2;
				T3 = T2;
		}	}
		if (T4)
		{	T3->nxt = trans[n][i];
			trans[n][i] = T4;
		}
	 }
	}
#endif
#ifndef NOREDUCE
	for (i = 1; i < m; i++)
	{	if (a_cycles)
		{ /* moves through these states are visible */
	#if PROG_LAB>0 && defined(HAS_NP)
			if (progstate[n][i])
				goto degrade;
			for (T1 = trans[n][i]; T1; T1 = T1->nxt)
				if (progstate[n][T1->st])
					goto degrade;
	#endif
			if (accpstate[n][i] || visstate[n][i])
				goto degrade;
			for (T1 = trans[n][i]; T1; T1 = T1->nxt)
				if (accpstate[n][T1->st])
					goto degrade;
		}
		T1 = trans[n][i];
		if (!T1) continue;
		g = mark_safety(T1);	/* V3.3.1 */
		if (g < 0) goto degrade; /* global */
		/* check if mixing of guards preserves reduction */
		if (T1->nxt)
		{	k = 0;
			for (T0 = T1; T0; T0 = T0->nxt)
			{	if (!(T0->atom&8))
					goto degrade;
				for (aa = 0; aa < 2; aa++)
				{	j = srinc_set(T0->tpe[aa]);
					if (j >= GLOBAL && j != ALPHA_F)
						goto degrade;
					if (T0->tpe[aa]
					&&  T0->tpe[aa]
					!=  T1->tpe[0])
						k = 1;
			}	}
			/* g = 0;	V3.3.1 */
			if (k)	/* non-uniform selection */
			for (T0 = T1; T0; T0 = T0->nxt)
			for (aa = 0; aa < 2; aa++)
			{	j = srinc_set(T0->tpe[aa]);
				if (j != LOCAL)
				{	k = srunc(T0->tpe[aa], j);
					for (h = 0; h < 6; h++)
						if (T1->qu[h] == k
						&&  T1->ty[h] == j)
							break;
					if (h >= 6)
					{	T1->qu[g%6] = k;
						T1->ty[g%6] = j;
						g++;
			}	}	}
			if (g > 6)
			{	T1->qu[0] = 0;	/* turn it off */
				printf("pan: warning, line %d, ",
					srcln[i]);
			 	printf("too many stmnt types (%d)",
					g);
			  	printf(" in selection\n");
			  goto degrade;
			}
		}
		/* mark all options global if >=1 is global */
		for (T1 = trans[n][i]; T1; T1 = T1->nxt)
			if (!(T1->atom&8)) break;
		if (T1)
degrade:	for (T1 = trans[n][i]; T1; T1 = T1->nxt)
			T1->atom &= ~8;	/* mark as unsafe */
		/* can only mix 'r's or 's's if on same chan */
		/* and not mixed with other local operations */
		T1 = trans[n][i];
		if (!T1 || T1->qu[0]) continue;
		j = T1->tpe[0];
		if (T1->nxt && T1->atom&8)
		{ if (j == 5*DELTA)
		  {	printf("warning: line %d ", srcln[i]);
			printf("mixed condition ");
			printf("(defeats reduction)\n");
			goto degrade;
		  }
		  for (T0 = T1; T0; T0 = T0->nxt)
		  for (aa = 0; aa < 2; aa++)
		  if  (T0->tpe[aa] && T0->tpe[aa] != j)
		  {	printf("warning: line %d ", srcln[i]);
			printf("[%d-%d] mixed %stion ",
				T0->tpe[aa], j, 
				(j==5*DELTA)?"condi":"selec");
			printf("(defeats reduction)\n");
			printf("	'%s' <-> '%s'\n",
				T1->tp, T0->tp);
			goto degrade;
		} }
	}
#endif
	for (i = 1; i < m; i++)
	{	T2 = trans[n][i];
		if (!T2
		||  T2->nxt
		||  strncmp(T2->tp, ".(goto)", 7)
		||  !stopstate[n][i])
			continue;
		stopstate[n][T2->st] = 1;
	}
	if (state_tables && !verbose)
	{	if (dodot)
		{	char buf[256], *q = buf, *p = procname[n];
			while (*p != '\0')
			{	if (*p != ':')
				{	*q++ = *p;
				}
				p++;
			}
			*q = '\0';
			printf("digraph ");
			switch (Btypes[n]) {
			case I_PROC:  printf("init {\n"); break;
			case N_CLAIM: printf("claim_%s {\n", buf); break;
			case E_TRACE: printf("notrace {\n"); break;
			case N_TRACE: printf("trace {\n"); break;
			default:      printf("p_%s {\n", buf); break;
			}
			printf("size=\"8,10\";\n");
			printf("  GT [shape=box,style=dotted,label=\"%s\"];\n", buf);
			printf("  GT -> S%d;\n", is);
		} else
		{	switch (Btypes[n]) {
			case I_PROC:  printf("init\n"); break;
			case N_CLAIM: printf("claim %s\n", procname[n]); break;
			case E_TRACE: printf("notrace assertion\n"); break;
			case N_TRACE: printf("trace assertion\n"); break;
			default:      printf("proctype %s\n", procname[n]); break;
		}	}
		for (i = 1; i < m; i++)
		{	reach[i] = 1;
		}
		tagtable(n, m, is, srcln, reach);
		if (dodot) printf("}\n");
	} else
	for (i = 1; i < m; i++)
	{	int nrelse;
		if (Btypes[n] != N_CLAIM)
		{	for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			{	if (T0->st == i
				&& strcmp(T0->tp, "(1)") == 0)
				{	printf("error: proctype '%s' ",
						procname[n]);
		  			printf("line %d, state %d: has un",
						srcln[i], i);
					printf("conditional self-loop\n");
					pan_exit(1);
		}	}	}
		nrelse = 0;
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
		{	if (strcmp(T0->tp, "else") == 0)
				nrelse++;
		}
		if (nrelse > 1)
		{	printf("error: proctype '%s' state",
				procname[n]);
		  	printf(" %d, inherits %d", i, nrelse);
		  	printf(" 'else' stmnts\n");
			pan_exit(1);
	}	}
#if !defined(LOOPSTATE) && !defined(BFS_PAR)
	if (state_tables)
#endif
	do_dfs(n, m, is, srcln, reach, lpstate);

	if (!t_reverse)
	{	return;
	}
	/* process n, with m states, is=initial state -- reverse list */
	if (!state_tables && Btypes[n] != N_CLAIM)
	{	for (i = 1; i < m; i++)
		{	Trans *Tx = (Trans *) 0; /* list of escapes */
			Trans *Ty = (Trans *) 0; /* its tail element */
			T1 = (Trans *) 0; /* reversed list */
			T2 = (Trans *) 0; /* its tail */
			T3 = (Trans *) 0; /* remembers possible 'else' */

			/* find unless-escapes, they should go first */
			T4 = T5 = T0 = trans[n][i];
	#ifdef HAS_UNLESS
			while (T4 && T4->e_trans) /* escapes are first in orig list */
			{	T5 = T4;	  /* remember predecessor */
				T4 = T4->nxt;
			}
	#endif
			/* T4 points to first non-escape, T5 to its parent, T0 to original list */
			if (T4 != T0)		 /* there was at least one escape */
			{	T3 = T5->nxt;		 /* start of non-escapes */
				T5->nxt = (Trans *) 0;	 /* separate */
				Tx = T0;		 /* start of the escapes */
				Ty = T5;		 /* its tail */
				T0 = T3;		 /* the rest, to be reversed */
			}
			/* T0 points to first non-escape, Tx to the list of escapes, Ty to its tail */

			/* first tail-add non-escape transitions, reversed */
			T3 = (Trans *) 0;
			for (T5 = T0; T5; T5 = T4)
			{	T4 = T5->nxt;
	#ifdef HAS_UNLESS
				if (T5->e_trans)
				{	printf("error: cannot happen!\n");
					continue;
				}
	#endif
				if (strcmp(T5->tp, "else") == 0)
				{	T3 = T5;
					T5->nxt = (Trans *) 0;
				} else
				{	T5->nxt = T1;
					if (!T1) { T2 = T5; }
					T1 = T5;
			}	}
			/* T3 points to a possible else, which is removed from the list */
			/* T1 points to the reversed list so far (without escapes) */
			/* T2 points to the tail element -- where the else should go */
			if (T2 && T3)
			{	T2->nxt = T3;	/* add else */
			} else
			{	if (T3) /* there was an else, but there's no tail */
				{	if (!T1)	/* and no reversed list */
					{	T1 = T3; /* odd, but possible */
					} else		/* even stranger */
					{	T1->nxt = T3;
			}	}	}

			/* add in the escapes, to that they appear at the front */
			if (Tx && Ty) { Ty->nxt = T1; T1 = Tx; }

			trans[n][i] = T1;
			/* reversed, with escapes first and else last */
	}	}
	if (state_tables && verbose)
	{	printf("FINAL proctype %s\n", 
			procname[n]);
		for (i = 1; i < m; i++)
		for (T0 = trans[n][i]; T0; T0 = T0->nxt)
			crack(n, i, T0, srcln);
	}
}
void
imed(Trans *T, int v, int n, int j)	/* set intermediate state */
{	progstate[n][T->st] |= progstate[n][v];
	accpstate[n][T->st] |= accpstate[n][v];
	stopstate[n][T->st] |= stopstate[n][v];
	mapstate[n][j] = T->st;
}
void
tagtable(int n, int m, int is, short srcln[], uchar reach[])
{	Trans *z;

	if (is >= m || !trans[n][is]
	||  is <= 0 || reach[is] == 0)
		return;
	reach[is] = 0;
	if (state_tables)
	for (z = trans[n][is]; z; z = z->nxt)
	{	if (dodot)
			dot_crack(n, is, z);
		else
			crack(n, is, z, srcln);
	}

	for (z = trans[n][is]; z; z = z->nxt)
	{
#ifdef HAS_UNLESS
		int i, j;
#endif
		tagtable(n, m, z->st, srcln, reach);
#ifdef HAS_UNLESS
		for (i = 0; i < HAS_UNLESS; i++)
		{	j = trans[n][is]->escp[i];
			if (!j) break;
			tagtable(n, m, j, srcln, reach);
		}
#endif
	}
}

extern Trans *t_id_lkup[];

void
dfs_table(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
{	Trans *z;

	if (is >= m || is <= 0 || !trans[n][is])
		return;
	if ((reach[is] & (4|8|16)) != 0)
	{	if ((reach[is] & (8|16)) == 16)	/* on stack, not yet recorded */
		{	lpstate[is] = 1;
			reach[is] |= 8; /* recorded */
			if (state_tables && verbose)
			{	printf("state %d line %d is a loopstate\n", is, srcln[is]);
		}	}
		return;
	}
	reach[is] |= (4|16);	/* visited | onstack */
	for (z = trans[n][is]; z; z = z->nxt)
	{	t_id_lkup[z->t_id] = z;
#ifdef HAS_UNLESS
		int i, j;
#endif
		dfs_table(n, m, z->st, srcln, reach, lpstate);
#ifdef HAS_UNLESS
		for (i = 0; i < HAS_UNLESS; i++)
		{	j = trans[n][is]->escp[i];
			if (!j) break;
			dfs_table(n, m, j, srcln, reach, lpstate);
		}
#endif
	}
	reach[is] &= ~16; /* no longer on stack */
}
void
do_dfs(int n, int m, int is, short srcln[], uchar reach[], uchar lpstate[])
{	int i;
	dfs_table(n, m, is, srcln, reach, lpstate);
	for (i = 0; i < m; i++)
		reach[i] &= ~(4|8|16);
}
void
crack(int n, int j, Trans *z, short srcln[])
{	int i;

	if (!z) return;
	printf("	state %3d -(tr %3d)-> state %3d  ",
		j, z->forw, z->st);
	printf("[id %3d tp %3d", z->t_id, z->tpe[0]);
	if (z->tpe[1]) printf(",%d", z->tpe[1]);
#ifdef HAS_UNLESS
	if (z->e_trans)
		printf(" org %3d", z->e_trans);
	else if (state_tables >= 2)
	for (i = 0; i < HAS_UNLESS; i++)
	{	if (!z->escp[i]) break;
		printf(" esc %d", z->escp[i]);
	}
#endif
	printf("]");
	printf(" [%s%s%s%s%s] %s:%d => ",
		z->atom&6?"A":z->atom&32?"D":"-",
		accpstate[n][j]?"a" :"-",
		stopstate[n][j]?"e" : "-",
		progstate[n][j]?"p" : "-",
		z->atom & 8 ?"L":"G",
		PanSource, srcln[j]);
	for (i = 0; z->tp[i]; i++)
		if (z->tp[i] == '\n')
			printf("\\n");
		else
			putchar(z->tp[i]);
	if (verbose && z->qu[0])
	{	printf("\t[");
		for (i = 0; i < 6; i++)
			if (z->qu[i])
				printf("(%d,%d)",
				z->qu[i], z->ty[i]);
		printf("]");
	}
	printf("\n");
	fflush(stdout);
}
/* spin -a m.pml; cc -o pan pan.c; ./pan -D | dot -Tps > foo.ps; ps2pdf foo.ps */
void
dot_crack(int n, int j, Trans *z)
{	int i;

	if (!z) return;
	printf("	S%d -> S%d  [color=black", j, z->st);

	if (z->atom&6) printf(",style=dashed");
	else if (z->atom&32) printf(",style=dotted");
	else if (z->atom&8) printf(",style=solid");
	else printf(",style=bold");

	printf(",label=\"");
	for (i = 0; z->tp[i]; i++)
	{	if (z->tp[i] == '\\'
		&&  z->tp[i+1] == 'n')
		{	i++; printf(" ");
		} else
		{	putchar(z->tp[i]);
	}	}
	printf("\"];\n");
	if (accpstate[n][j]) printf("  S%d [color=red,style=bold];\n", j);
	else if (progstate[n][j]) printf("  S%d [color=green,style=bold];\n", j);
	if (stopstate[n][j]) printf("  S%d [color=blue,style=bold,shape=box];\n", j);
}

#ifdef VAR_RANGES
#define BYTESIZE	32	/* 2^8 : 2^3 = 256:8 = 32 */

typedef struct Vr_Ptr {
	char	*nm;
	uchar	vals[BYTESIZE];
	struct Vr_Ptr *nxt;
} Vr_Ptr;
Vr_Ptr *ranges = (Vr_Ptr *) 0;

void
logval(char *s, int v)
{	Vr_Ptr *tmp;

	if (v<0 || v > 255) return;
	for (tmp = ranges; tmp; tmp = tmp->nxt)
		if (!strcmp(tmp->nm, s))
			goto found;
	tmp = (Vr_Ptr *) emalloc(sizeof(Vr_Ptr));
	tmp->nxt = ranges;
	ranges = tmp;
	tmp->nm = s;
found:
	tmp->vals[(v)/8] |= 1<<((v)%8);
}

void
dumpval(uchar X[], int range)
{	int w, x, i, j = -1;

	for (w = i = 0; w < range; w++)
	for (x = 0; x < 8; x++, i++)
	{
from:		if ((X[w] & (1<<x)))
		{	printf("%d", i);
			j = i;
			goto upto;
	}	}
	return;
	for (w = 0; w < range; w++)
	for (x = 0; x < 8; x++, i++)
	{
upto:		if (!(X[w] & (1<<x)))
		{	if (i-1 == j)
				printf(", ");
			else
				printf("-%d, ", i-1);
			goto from;
	}	}
	if (j >= 0 && j != 255)
		printf("-255");
}

void
dumpranges(void)
{	Vr_Ptr *tmp;
	printf("\nValues assigned within ");
	printf("interval [0..255]:\n");
	for (tmp = ranges; tmp; tmp = tmp->nxt)
	{	printf("\t%s\t: ", tmp->nm);
		dumpval(tmp->vals, BYTESIZE);
		printf("\n");
	}
}
#endif
